package com.pengrad.telegrambot;

import com.google.gson.Gson;
import com.pengrad.telegrambot.impl.FileApi;
import com.pengrad.telegrambot.impl.TelegramBotClient;
import com.pengrad.telegrambot.impl.UpdatesHandler;
import com.pengrad.telegrambot.model.File;
import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.request.GetUpdates;
import com.pengrad.telegrambot.response.BaseResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

public class TelegramBot {
    private final TelegramBotClient api;
    private final FileApi fileApi;
    private final String token;
    private final UpdatesHandler updatesHandler;

    public TelegramBot(String str) {
        this(new Builder(str));
    }

    TelegramBot(Builder builder) {
        this.token = builder.botToken;
        this.api = builder.api;
        this.fileApi = builder.fileApi;
        this.updatesHandler = builder.updatesHandler;
    }

    public <T extends BaseRequest<T, R>, R extends BaseResponse> R execute(BaseRequest<T, R> baseRequest) {
        return this.api.send(baseRequest);
    }

    public <T extends BaseRequest<T, R>, R extends BaseResponse> void execute(T t, Callback<T, R> callback) {
        this.api.send(t, callback);
    }

    public String getToken() {
        return this.token;
    }

    public String getFullFilePath(File file) {
        return this.fileApi.getFullFilePath(file.filePath());
    }

    public byte[] getFileContent(File file) throws IOException {
        InputStream inputStream = new URL(getFullFilePath(file)).openConnection().getInputStream();
        try {
            byte[] bytesFromInputStream = BotUtils.getBytesFromInputStream(inputStream);
            if (inputStream != null) {
                inputStream.close();
            }
            return bytesFromInputStream;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    public void setUpdatesListener(UpdatesListener updatesListener) {
        setUpdatesListener(updatesListener, new GetUpdates());
    }

    public void setUpdatesListener(UpdatesListener updatesListener, GetUpdates getUpdates) {
        setUpdatesListener(updatesListener, (ExceptionHandler) null, getUpdates);
    }

    public void setUpdatesListener(UpdatesListener updatesListener, ExceptionHandler exceptionHandler) {
        setUpdatesListener(updatesListener, exceptionHandler, new GetUpdates());
    }

    public void setUpdatesListener(UpdatesListener updatesListener, ExceptionHandler exceptionHandler, GetUpdates getUpdates) {
        this.updatesHandler.start(this, updatesListener, exceptionHandler, getUpdates);
    }

    public void removeGetUpdatesListener() {
        this.updatesHandler.stop();
    }

    public void shutdown() {
        this.api.shutdown();
    }

    public static final class Builder {
        static final String API_URL = "https://api.telegram.org/bot";
        /* access modifiers changed from: private */
        public TelegramBotClient api;
        private String apiUrl;
        /* access modifiers changed from: private */
        public final String botToken;
        /* access modifiers changed from: private */
        public FileApi fileApi;
        private String fileApiUrl;
        private OkHttpClient okHttpClient;
        /* access modifiers changed from: private */
        public UpdatesHandler updatesHandler;
        private boolean useTestServer = false;

        public Builder(String str) {
            this.botToken = str;
            this.api = new TelegramBotClient(client((Interceptor) null), gson(), apiUrl(API_URL, str, this.useTestServer));
            this.fileApi = new FileApi(str);
            this.updatesHandler = new UpdatesHandler(100);
        }

        public Builder debug() {
            this.okHttpClient = client(httpLoggingInterceptor());
            return this;
        }

        public Builder okHttpClient(OkHttpClient okHttpClient2) {
            this.okHttpClient = okHttpClient2;
            return this;
        }

        public Builder apiUrl(String str) {
            this.apiUrl = str;
            return this;
        }

        public Builder fileApiUrl(String str) {
            this.fileApiUrl = str;
            return this;
        }

        public Builder updateListenerSleep(long j) {
            this.updatesHandler = new UpdatesHandler(j);
            return this;
        }

        public Builder useTestServer(boolean z) {
            this.useTestServer = z;
            return this;
        }

        public TelegramBot build() {
            OkHttpClient okHttpClient2 = this.okHttpClient;
            if (!(okHttpClient2 == null && this.apiUrl == null)) {
                if (okHttpClient2 == null) {
                    okHttpClient2 = client((Interceptor) null);
                }
                String str = this.apiUrl;
                if (str == null) {
                    str = API_URL;
                }
                this.api = new TelegramBotClient(okHttpClient2, gson(), apiUrl(str, this.botToken, this.useTestServer));
            }
            String str2 = this.fileApiUrl;
            if (str2 != null) {
                this.fileApi = new FileApi(str2, this.botToken);
            }
            return new TelegramBot(this);
        }

        private static OkHttpClient client(Interceptor interceptor) {
            OkHttpClient.Builder readTimeout = new OkHttpClient.Builder().connectTimeout(75, TimeUnit.SECONDS).writeTimeout(75, TimeUnit.SECONDS).readTimeout(75, TimeUnit.SECONDS);
            if (interceptor != null) {
                readTimeout.addInterceptor(interceptor);
            }
            return readTimeout.build();
        }

        private static Interceptor httpLoggingInterceptor() {
            return new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
        }

        private static Gson gson() {
            return new Gson();
        }

        private static String apiUrl(String str, String str2, boolean z) {
            StringBuilder sb = new StringBuilder();
            sb.append(str);
            sb.append(str2);
            sb.append(z ? "/test/" : "/");
            return sb.toString();
        }
    }
}
