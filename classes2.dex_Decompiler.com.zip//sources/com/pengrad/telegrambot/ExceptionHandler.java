package com.pengrad.telegrambot;

public interface ExceptionHandler {
    void onException(TelegramException telegramException);
}
