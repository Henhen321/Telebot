package com.pengrad.telegrambot;

import java.util.concurrent.atomic.AtomicInteger;

public class AttachName {
    private static final AtomicInteger counter = new AtomicInteger();

    private AttachName() {
    }

    public static String next() {
        return "attach" + counter.incrementAndGet();
    }

    public static void reset() {
        counter.set(0);
    }
}
