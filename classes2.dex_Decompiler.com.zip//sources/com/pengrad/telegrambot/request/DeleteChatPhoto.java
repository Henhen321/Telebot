package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteChatPhoto extends BaseRequest<DeleteChatPhoto, BaseResponse> {
    public DeleteChatPhoto(Object obj) {
        super(BaseResponse.class);
        add("chat_id", obj);
    }
}
