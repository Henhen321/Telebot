package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetFileResponse;

public class GetFile extends BaseRequest<GetFile, GetFileResponse> {
    public GetFile(String str) {
        super(GetFileResponse.class);
        add("file_id", str);
    }
}
