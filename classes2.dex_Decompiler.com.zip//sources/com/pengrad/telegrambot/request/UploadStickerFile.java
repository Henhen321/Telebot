package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetFileResponse;

public class UploadStickerFile extends AbstractUploadRequest<UploadStickerFile, GetFileResponse> {
    public UploadStickerFile(Long l, Object obj) {
        super(GetFileResponse.class, "png_sticker", obj);
        add("user_id", l);
    }
}
