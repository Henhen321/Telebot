package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.LabeledPrice;

public class SendInvoice extends AbstractSendRequest<SendInvoice> {
    public SendInvoice(Long l, String str, String str2, String str3, String str4, String str5, LabeledPrice... labeledPriceArr) {
        super(l);
        ((SendInvoice) ((SendInvoice) ((SendInvoice) ((SendInvoice) ((SendInvoice) add("title", str)).add("description", str2)).add("payload", str3)).add("provider_token", str4)).add("currency", str5)).add("prices", labeledPriceArr);
    }

    public SendInvoice(Long l, String str, String str2, String str3, String str4, String str5, String str6, LabeledPrice... labeledPriceArr) {
        this(l, str, str2, str3, str4, str6, labeledPriceArr);
        String str7 = str5;
        add("start_parameter", str5);
    }

    public SendInvoice providerData(String str) {
        return (SendInvoice) add("provider_data", str);
    }

    public SendInvoice photoUrl(String str) {
        return (SendInvoice) add("photo_url", str);
    }

    public SendInvoice photoSize(Integer num) {
        return (SendInvoice) add("photo_size", num);
    }

    public SendInvoice photoWidth(Integer num) {
        return (SendInvoice) add("photo_width", num);
    }

    public SendInvoice photoHeight(Integer num) {
        return (SendInvoice) add("photo_height", num);
    }

    public SendInvoice needName(boolean z) {
        return (SendInvoice) add("need_name", Boolean.valueOf(z));
    }

    public SendInvoice needPhoneNumber(boolean z) {
        return (SendInvoice) add("need_phone_number", Boolean.valueOf(z));
    }

    public SendInvoice needEmail(boolean z) {
        return (SendInvoice) add("need_email", Boolean.valueOf(z));
    }

    public SendInvoice needShippingAddress(boolean z) {
        return (SendInvoice) add("need_shipping_address", Boolean.valueOf(z));
    }

    public SendInvoice isFlexible(boolean z) {
        return (SendInvoice) add("is_flexible", Boolean.valueOf(z));
    }

    public SendInvoice startParameter(String str) {
        return (SendInvoice) add("start_parameter", str);
    }

    public SendInvoice maxTipAmount(int i) {
        return (SendInvoice) add("max_tip_amount", Integer.valueOf(i));
    }

    public SendInvoice suggestedTipAmounts(Integer[] numArr) {
        return (SendInvoice) add("suggested_tip_amounts", numArr);
    }

    public SendInvoice sendEmailToProvider(boolean z) {
        return (SendInvoice) add("send_email_to_provider", Boolean.valueOf(z));
    }

    public SendInvoice sendPhoneNumberToProvider(boolean z) {
        return (SendInvoice) add("send_phone_number_to_provider", Boolean.valueOf(z));
    }
}
