package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.ChatInviteLinkResponse;

public class RevokeChatInviteLink extends BaseRequest<RevokeChatInviteLink, ChatInviteLinkResponse> {
    public RevokeChatInviteLink(Object obj, String str) {
        super(ChatInviteLinkResponse.class);
        add("chat_id", obj);
        add("invite_link", str);
    }
}
