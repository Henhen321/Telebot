package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetGameHighScoresResponse;

public class GetGameHighScores extends BaseRequest<GetGameHighScores, GetGameHighScoresResponse> {
    public GetGameHighScores(long j, Object obj, int i) {
        super(GetGameHighScoresResponse.class);
        ((GetGameHighScores) ((GetGameHighScores) add("user_id", Long.valueOf(j))).add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }

    public GetGameHighScores(long j, String str) {
        super(GetGameHighScoresResponse.class);
        ((GetGameHighScores) add("user_id", Long.valueOf(j))).add("inline_message_id", str);
    }
}
