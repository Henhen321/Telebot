package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.ChatAction;
import com.pengrad.telegrambot.response.BaseResponse;

public class SendChatAction extends BaseRequest<SendChatAction, BaseResponse> {
    public SendChatAction(Object obj, String str) {
        super(BaseResponse.class);
        ((SendChatAction) add("chat_id", obj)).add("action", str);
    }

    public SendChatAction(Object obj, ChatAction chatAction) {
        super(BaseResponse.class);
        ((SendChatAction) add("chat_id", obj)).add("action", chatAction.name());
    }
}
