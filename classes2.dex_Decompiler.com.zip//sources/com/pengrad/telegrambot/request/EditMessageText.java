package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class EditMessageText extends BaseRequest<EditMessageText, BaseResponse> {
    public EditMessageText(Object obj, int i, String str) {
        super(SendResponse.class);
        ((EditMessageText) ((EditMessageText) add("chat_id", obj)).add("message_id", Integer.valueOf(i))).add("text", str);
    }

    public EditMessageText(String str, String str2) {
        super(BaseResponse.class);
        ((EditMessageText) add("inline_message_id", str)).add("text", str2);
    }

    public EditMessageText parseMode(ParseMode parseMode) {
        return (EditMessageText) add("parse_mode", parseMode.name());
    }

    public EditMessageText entities(MessageEntity... messageEntityArr) {
        return (EditMessageText) add("entities", messageEntityArr);
    }

    public EditMessageText disableWebPagePreview(boolean z) {
        return (EditMessageText) add("disable_web_page_preview", Boolean.valueOf(z));
    }

    public EditMessageText replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (EditMessageText) add("reply_markup", inlineKeyboardMarkup);
    }
}
