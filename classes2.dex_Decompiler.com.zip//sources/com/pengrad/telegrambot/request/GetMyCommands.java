package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.botcommandscope.BotCommandScope;
import com.pengrad.telegrambot.response.GetMyCommandsResponse;

public class GetMyCommands extends BaseRequest<GetMyCommands, GetMyCommandsResponse> {
    public GetMyCommands() {
        super(GetMyCommandsResponse.class);
    }

    public GetMyCommands scope(BotCommandScope botCommandScope) {
        add("scope", botCommandScope);
        return this;
    }

    public GetMyCommands languageCode(String str) {
        add("language_code", str);
        return this;
    }
}
