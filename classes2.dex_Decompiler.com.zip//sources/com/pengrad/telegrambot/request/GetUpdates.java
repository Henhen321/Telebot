package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetUpdatesResponse;

public class GetUpdates extends BaseRequest<GetUpdates, GetUpdatesResponse> {
    private int limit = 100;
    private int timeout = 0;

    public GetUpdates() {
        super(GetUpdatesResponse.class);
    }

    public GetUpdates offset(int i) {
        return (GetUpdates) add("offset", Integer.valueOf(i));
    }

    public GetUpdates limit(int i) {
        this.limit = i;
        return (GetUpdates) add("limit", Integer.valueOf(i));
    }

    public GetUpdates timeout(int i) {
        this.timeout = i;
        return (GetUpdates) add("timeout", Integer.valueOf(i));
    }

    public GetUpdates allowedUpdates(String... strArr) {
        return (GetUpdates) add("allowed_updates", strArr);
    }

    public int getTimeoutSeconds() {
        return this.timeout;
    }

    public int getLimit() {
        return this.limit;
    }
}
