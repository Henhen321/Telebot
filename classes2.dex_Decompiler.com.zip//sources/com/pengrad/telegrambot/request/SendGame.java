package com.pengrad.telegrambot.request;

public class SendGame extends AbstractSendRequest<SendGame> {
    public SendGame(Object obj, String str) {
        super(obj);
        add("game_short_name", str);
    }
}
