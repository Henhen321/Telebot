package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatMenuButtonResponse;

public class GetChatMenuButton extends BaseRequest<GetChatMenuButton, GetChatMenuButtonResponse> {
    public GetChatMenuButton() {
        super(GetChatMenuButtonResponse.class);
    }

    public GetChatMenuButton chatId(long j) {
        return (GetChatMenuButton) add("chat_id", Long.valueOf(j));
    }
}
