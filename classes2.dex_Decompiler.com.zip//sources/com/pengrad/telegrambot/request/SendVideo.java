package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendVideo extends AbstractMultipartRequest<SendVideo> {
    public String getContentType() {
        return "video/mp4";
    }

    public String getDefaultFileName() {
        return ContentTypes.VIDEO_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "video";
    }

    public SendVideo(Object obj, String str) {
        super(obj, str);
    }

    public SendVideo(Object obj, File file) {
        super(obj, file);
    }

    public SendVideo(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendVideo duration(int i) {
        return (SendVideo) add("duration", Integer.valueOf(i));
    }

    public SendVideo width(int i) {
        return (SendVideo) add("width", Integer.valueOf(i));
    }

    public SendVideo height(int i) {
        return (SendVideo) add("height", Integer.valueOf(i));
    }

    public SendVideo thumb(byte[] bArr) {
        return (SendVideo) super.thumb(bArr);
    }

    public SendVideo thumb(File file) {
        return (SendVideo) super.thumb(file);
    }

    public SendVideo caption(String str) {
        return (SendVideo) add("caption", str);
    }

    public SendVideo parseMode(ParseMode parseMode) {
        return (SendVideo) add("parse_mode", parseMode.name());
    }

    public SendVideo captionEntities(MessageEntity... messageEntityArr) {
        return (SendVideo) add("caption_entities", messageEntityArr);
    }

    public SendVideo supportsStreaming(boolean z) {
        return (SendVideo) add("supports_streaming", Boolean.valueOf(z));
    }
}
