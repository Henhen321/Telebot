package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class PromoteChatMember extends BaseRequest<PromoteChatMember, BaseResponse> {
    public PromoteChatMember(Object obj, long j) {
        super(BaseResponse.class);
        ((PromoteChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }

    public PromoteChatMember isAnonymous(boolean z) {
        return (PromoteChatMember) add("is_anonymous", Boolean.valueOf(z));
    }

    public PromoteChatMember canManageChat(boolean z) {
        return (PromoteChatMember) add("can_manage_chat", Boolean.valueOf(z));
    }

    public PromoteChatMember canChangeInfo(boolean z) {
        return (PromoteChatMember) add("can_change_info", Boolean.valueOf(z));
    }

    public PromoteChatMember canPostMessages(boolean z) {
        return (PromoteChatMember) add("can_post_messages", Boolean.valueOf(z));
    }

    public PromoteChatMember canEditMessages(boolean z) {
        return (PromoteChatMember) add("can_edit_messages", Boolean.valueOf(z));
    }

    public PromoteChatMember canDeleteMessages(boolean z) {
        return (PromoteChatMember) add("can_delete_messages", Boolean.valueOf(z));
    }

    public PromoteChatMember canManageVoiceChats(boolean z) {
        return (PromoteChatMember) add("can_manage_video_chats", Boolean.valueOf(z));
    }

    public PromoteChatMember canManageVideoChats(boolean z) {
        return (PromoteChatMember) add("can_manage_video_chats", Boolean.valueOf(z));
    }

    public PromoteChatMember canInviteUsers(boolean z) {
        return (PromoteChatMember) add("can_invite_users", Boolean.valueOf(z));
    }

    public PromoteChatMember canRestrictMembers(boolean z) {
        return (PromoteChatMember) add("can_restrict_members", Boolean.valueOf(z));
    }

    public PromoteChatMember canPinMessages(boolean z) {
        return (PromoteChatMember) add("can_pin_messages", Boolean.valueOf(z));
    }

    public PromoteChatMember canPromoteMembers(boolean z) {
        return (PromoteChatMember) add("can_promote_members", Boolean.valueOf(z));
    }
}
