package com.pengrad.telegrambot.request;

import java.io.File;

public class SendVideoNote extends AbstractMultipartRequest<SendVideoNote> {
    public String getContentType() {
        return "video/mp4";
    }

    /* access modifiers changed from: protected */
    public String getDefaultFileName() {
        return ContentTypes.VIDEO_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "video_note";
    }

    public SendVideoNote(Object obj, String str) {
        super(obj, str);
    }

    public SendVideoNote(Object obj, File file) {
        super(obj, file);
    }

    public SendVideoNote(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendVideoNote duration(int i) {
        return (SendVideoNote) add("duration", Integer.valueOf(i));
    }

    public SendVideoNote length(int i) {
        return (SendVideoNote) add("length", Integer.valueOf(i));
    }

    public SendVideoNote thumb(byte[] bArr) {
        return (SendVideoNote) super.thumb(bArr);
    }

    public SendVideoNote thumb(File file) {
        return (SendVideoNote) super.thumb(file);
    }
}
