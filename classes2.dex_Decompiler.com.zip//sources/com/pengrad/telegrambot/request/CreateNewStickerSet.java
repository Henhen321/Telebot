package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MaskPosition;
import com.pengrad.telegrambot.model.Sticker;
import com.pengrad.telegrambot.response.BaseResponse;

public class CreateNewStickerSet extends AbstractUploadRequest<CreateNewStickerSet, BaseResponse> {
    public static CreateNewStickerSet tgsSticker(Long l, String str, String str2, String str3, Object obj) {
        return new CreateNewStickerSet(l, str, str2, str3, "tgs_sticker", obj);
    }

    public static CreateNewStickerSet pngSticker(Long l, String str, String str2, String str3, Object obj) {
        return new CreateNewStickerSet(l, str, str2, str3, "png_sticker", obj);
    }

    public static CreateNewStickerSet webmSticker(Long l, String str, String str2, String str3, Object obj) {
        return new CreateNewStickerSet(l, str, str2, str3, "webm_sticker", obj);
    }

    @Deprecated
    public CreateNewStickerSet(Long l, String str, String str2, Object obj, String str3) {
        this(l, str, str2, str3, "png_sticker", obj);
    }

    private CreateNewStickerSet(Long l, String str, String str2, String str3, String str4, Object obj) {
        super(BaseResponse.class, str4, obj);
        add("user_id", l);
        add("name", str);
        add("title", str2);
        add("emojis", str3);
    }

    @Deprecated
    public CreateNewStickerSet containsMasks(boolean z) {
        return (CreateNewStickerSet) add("contains_masks", Boolean.valueOf(z));
    }

    public CreateNewStickerSet maskPosition(MaskPosition maskPosition) {
        return (CreateNewStickerSet) add("mask_position", maskPosition);
    }

    public CreateNewStickerSet stickerType(Sticker.Type type) {
        return (CreateNewStickerSet) add("sticker_type", type.name());
    }
}
