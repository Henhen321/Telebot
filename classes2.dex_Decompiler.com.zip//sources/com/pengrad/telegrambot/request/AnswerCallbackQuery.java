package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class AnswerCallbackQuery extends BaseRequest<AnswerCallbackQuery, BaseResponse> {
    public AnswerCallbackQuery(String str) {
        super(BaseResponse.class);
        add("callback_query_id", str);
    }

    public AnswerCallbackQuery text(String str) {
        return (AnswerCallbackQuery) add("text", str);
    }

    public AnswerCallbackQuery showAlert(boolean z) {
        return (AnswerCallbackQuery) add("show_alert", Boolean.valueOf(z));
    }

    public AnswerCallbackQuery url(String str) {
        return (AnswerCallbackQuery) add("url", str);
    }

    public AnswerCallbackQuery cacheTime(int i) {
        return (AnswerCallbackQuery) add("cache_time", Integer.valueOf(i));
    }
}
