package com.pengrad.telegrambot.request;

public class SendVenue extends AbstractSendRequest<SendVenue> {
    public SendVenue(Object obj, float f, float f2, String str, String str2) {
        super(obj);
        add("latitude", Float.valueOf(f));
        add("longitude", Float.valueOf(f2));
        add("title", str);
        add("address", str2);
    }

    public SendVenue foursquareId(String str) {
        return (SendVenue) add("foursquare_id", str);
    }

    public SendVenue foursquareType(String str) {
        return (SendVenue) add("foursquare_type", str);
    }

    public SendVenue googlePlaceId(String str) {
        return (SendVenue) add("google_place_id", str);
    }

    public SendVenue googlePlaceType(String str) {
        return (SendVenue) add("google_place_type", str);
    }
}
