package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatResponse;

public class GetChat extends BaseRequest<GetChat, GetChatResponse> {
    public GetChat(Object obj) {
        super(GetChatResponse.class);
        add("chat_id", obj);
    }
}
