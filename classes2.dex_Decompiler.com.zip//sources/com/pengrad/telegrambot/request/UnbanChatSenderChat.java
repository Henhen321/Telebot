package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class UnbanChatSenderChat extends BaseRequest<UnbanChatSenderChat, BaseResponse> {
    public UnbanChatSenderChat(Object obj, long j) {
        super(BaseResponse.class);
        ((UnbanChatSenderChat) add("chat_id", obj)).add("sender_chat_id", Long.valueOf(j));
    }
}
