package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeclineChatJoinRequest extends BaseRequest<DeclineChatJoinRequest, BaseResponse> {
    public DeclineChatJoinRequest(Object obj, Long l) {
        super(BaseResponse.class);
        add("chat_id", obj);
        add("user_id", l);
    }
}
