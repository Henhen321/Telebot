package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.Keyboard;
import com.pengrad.telegrambot.response.PollResponse;

public class StopPoll extends BaseRequest<StopPoll, PollResponse> {
    public StopPoll(Object obj, int i) {
        super(PollResponse.class);
        ((StopPoll) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }

    public StopPoll replyMarkup(Keyboard keyboard) {
        return (StopPoll) add("reply_markup", keyboard);
    }
}
