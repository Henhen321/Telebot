package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatAdministratorCustomTitle extends BaseRequest<SetChatAdministratorCustomTitle, BaseResponse> {
    public SetChatAdministratorCustomTitle(Object obj, long j, String str) {
        super(BaseResponse.class);
        ((SetChatAdministratorCustomTitle) ((SetChatAdministratorCustomTitle) add("chat_id", obj)).add("user_id", Long.valueOf(j))).add("custom_title", str);
    }
}
