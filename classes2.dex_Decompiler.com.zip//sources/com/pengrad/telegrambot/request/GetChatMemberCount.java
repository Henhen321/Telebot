package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatMemberCountResponse;

public class GetChatMemberCount extends BaseRequest<GetChatMemberCount, GetChatMemberCountResponse> {
    public GetChatMemberCount(Object obj) {
        super(GetChatMemberCountResponse.class);
        add("chat_id", obj);
    }
}
