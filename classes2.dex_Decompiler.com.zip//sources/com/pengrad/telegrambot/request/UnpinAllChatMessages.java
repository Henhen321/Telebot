package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class UnpinAllChatMessages extends BaseRequest<UnpinAllChatMessages, BaseResponse> {
    public UnpinAllChatMessages(Object obj) {
        super(BaseResponse.class);
        add("chat_id", obj);
    }
}
