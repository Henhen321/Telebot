package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class UnpinChatMessage extends BaseRequest<UnpinChatMessage, BaseResponse> {
    public UnpinChatMessage(Object obj) {
        super(BaseResponse.class);
        add("chat_id", obj);
    }

    public UnpinChatMessage messageId(Integer num) {
        return (UnpinChatMessage) add("message_id", num);
    }
}
