package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendAudio extends AbstractMultipartRequest<SendAudio> {
    public String getContentType() {
        return ContentTypes.AUDIO_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.AUDIO_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "audio";
    }

    public SendAudio(Object obj, String str) {
        super(obj, str);
    }

    public SendAudio(Object obj, File file) {
        super(obj, file);
    }

    public SendAudio(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendAudio caption(String str) {
        return (SendAudio) add("caption", str);
    }

    public SendAudio parseMode(ParseMode parseMode) {
        return (SendAudio) add("parse_mode", parseMode.name());
    }

    public SendAudio captionEntities(MessageEntity... messageEntityArr) {
        return (SendAudio) add("caption_entities", messageEntityArr);
    }

    public SendAudio duration(int i) {
        return (SendAudio) add("duration", Integer.valueOf(i));
    }

    public SendAudio performer(String str) {
        return (SendAudio) add("performer", str);
    }

    public SendAudio title(String str) {
        return (SendAudio) add("title", str);
    }

    public SendAudio thumb(byte[] bArr) {
        return (SendAudio) super.thumb(bArr);
    }

    public SendAudio thumb(File file) {
        return (SendAudio) super.thumb(file);
    }
}
