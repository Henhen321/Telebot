package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatDescription extends BaseRequest<SetChatDescription, BaseResponse> {
    public SetChatDescription(Object obj, String str) {
        super(BaseResponse.class);
        ((SetChatDescription) add("chat_id", obj)).add("description", str);
    }
}
