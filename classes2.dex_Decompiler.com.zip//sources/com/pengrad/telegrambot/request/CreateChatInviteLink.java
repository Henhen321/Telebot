package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.ChatInviteLinkResponse;

public class CreateChatInviteLink extends BaseRequest<CreateChatInviteLink, ChatInviteLinkResponse> {
    public CreateChatInviteLink(Object obj) {
        super(ChatInviteLinkResponse.class);
        add("chat_id", obj);
    }

    public CreateChatInviteLink name(String str) {
        return (CreateChatInviteLink) add("name", str);
    }

    public CreateChatInviteLink expireDate(Integer num) {
        return (CreateChatInviteLink) add("expire_date", num);
    }

    public CreateChatInviteLink memberLimit(Integer num) {
        return (CreateChatInviteLink) add("member_limit", num);
    }

    public CreateChatInviteLink createsJoinRequest(Boolean bool) {
        return (CreateChatInviteLink) add("creates_join_request", bool);
    }
}
