package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.SendResponse;

public class ForwardMessage extends BaseRequest<ForwardMessage, SendResponse> {
    public ForwardMessage(Object obj, Object obj2, int i) {
        super(SendResponse.class);
        ((ForwardMessage) ((ForwardMessage) add("chat_id", obj)).add("from_chat_id", obj2)).add("message_id", Integer.valueOf(i));
    }

    public ForwardMessage disableNotification(boolean z) {
        return (ForwardMessage) add("disable_notification", Boolean.valueOf(z));
    }
}
