package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.Keyboard;
import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.response.MessageIdResponse;

public class CopyMessage extends BaseRequest<CopyMessage, MessageIdResponse> {
    public CopyMessage(Object obj, Object obj2, int i) {
        super(MessageIdResponse.class);
        ((CopyMessage) ((CopyMessage) add("chat_id", obj)).add("from_chat_id", obj2)).add("message_id", Integer.valueOf(i));
    }

    public CopyMessage caption(String str) {
        return (CopyMessage) add("caption", str);
    }

    public CopyMessage parseMode(ParseMode parseMode) {
        return (CopyMessage) add("parse_mode", parseMode.name());
    }

    public CopyMessage captionEntities(MessageEntity... messageEntityArr) {
        return (CopyMessage) add("caption_entities", messageEntityArr);
    }

    public CopyMessage disableNotification(boolean z) {
        return (CopyMessage) add("disable_notification", Boolean.valueOf(z));
    }

    public CopyMessage allowSendingWithoutReply(boolean z) {
        return (CopyMessage) add("allow_sending_without_reply", Boolean.valueOf(z));
    }

    public CopyMessage replyToMessageId(int i) {
        return (CopyMessage) add("reply_to_message_id", Integer.valueOf(i));
    }

    public CopyMessage replyMarkup(Keyboard keyboard) {
        return (CopyMessage) add("reply_markup", keyboard);
    }
}
