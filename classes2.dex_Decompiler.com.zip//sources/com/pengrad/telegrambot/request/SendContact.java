package com.pengrad.telegrambot.request;

public class SendContact extends AbstractSendRequest<SendContact> {
    public SendContact(Object obj, String str, String str2) {
        super(obj);
        add("phone_number", str);
        add("first_name", str2);
    }

    public SendContact lastName(String str) {
        return (SendContact) add("last_name", str);
    }

    public SendContact vcard(String str) {
        return (SendContact) add("vcard", str);
    }
}
