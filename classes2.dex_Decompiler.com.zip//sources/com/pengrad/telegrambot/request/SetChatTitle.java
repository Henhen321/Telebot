package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatTitle extends BaseRequest<SetChatTitle, BaseResponse> {
    public SetChatTitle(Object obj, String str) {
        super(BaseResponse.class);
        ((SetChatTitle) add("chat_id", obj)).add("title", str);
    }
}
