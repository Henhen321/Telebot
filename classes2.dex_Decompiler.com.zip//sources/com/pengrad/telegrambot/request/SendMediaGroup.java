package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InputMedia;
import com.pengrad.telegrambot.response.MessagesResponse;
import java.util.Map;

public class SendMediaGroup extends BaseRequest<SendMediaGroup, MessagesResponse> {
    private boolean isMultipart = false;

    public SendMediaGroup(Object obj, InputMedia<?>... inputMediaArr) {
        super(MessagesResponse.class);
        ((SendMediaGroup) add("chat_id", obj)).add("media", inputMediaArr);
        for (InputMedia<?> attachments : inputMediaArr) {
            Map<String, Object> attachments2 = attachments.getAttachments();
            if (attachments2 != null && attachments2.size() > 0) {
                addAll(attachments2);
                this.isMultipart = true;
            }
        }
    }

    public SendMediaGroup disableNotification(boolean z) {
        return (SendMediaGroup) add("disable_notification", Boolean.valueOf(z));
    }

    public SendMediaGroup replyToMessageId(int i) {
        return (SendMediaGroup) add("reply_to_message_id", Integer.valueOf(i));
    }

    public SendMediaGroup allowSendingWithoutReply(boolean z) {
        return (SendMediaGroup) add("allow_sending_without_reply", Boolean.valueOf(z));
    }

    public boolean isMultipart() {
        return this.isMultipart;
    }
}
