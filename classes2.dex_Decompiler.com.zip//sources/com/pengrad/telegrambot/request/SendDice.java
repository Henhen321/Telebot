package com.pengrad.telegrambot.request;

public class SendDice extends AbstractSendRequest<SendDice> {
    public SendDice(Object obj) {
        super(obj);
    }

    public SendDice emoji(String str) {
        return (SendDice) add("emoji", str);
    }

    public SendDice darts() {
        return emoji("🎯");
    }

    public SendDice basketball() {
        return emoji("🏀");
    }

    public SendDice football() {
        return emoji("⚽");
    }

    public SendDice slotMachine() {
        return emoji("🎰");
    }

    public SendDice bowling() {
        return emoji("🎳");
    }
}
