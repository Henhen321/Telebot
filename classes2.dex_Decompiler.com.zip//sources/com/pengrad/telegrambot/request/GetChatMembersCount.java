package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatMembersCountResponse;

@Deprecated
public class GetChatMembersCount extends BaseRequest<GetChatMembersCount, GetChatMembersCountResponse> {
    public GetChatMembersCount(Object obj) {
        super(GetChatMembersCountResponse.class);
        add("chat_id", obj);
    }
}
