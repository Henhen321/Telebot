package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class StopMessageLiveLocation extends BaseRequest<StopMessageLiveLocation, BaseResponse> {
    public StopMessageLiveLocation(Object obj, int i) {
        super(SendResponse.class);
        ((StopMessageLiveLocation) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }

    public StopMessageLiveLocation(String str) {
        super(BaseResponse.class);
        add("inline_message_id", str);
    }

    public StopMessageLiveLocation replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (StopMessageLiveLocation) add("reply_markup", inlineKeyboardMarkup);
    }
}
