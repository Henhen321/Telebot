package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class BanChatMember extends BaseRequest<BanChatMember, BaseResponse> {
    public BanChatMember(Object obj, long j) {
        super(BaseResponse.class);
        ((BanChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }

    public BanChatMember untilDate(int i) {
        return (BanChatMember) add("until_date", Integer.valueOf(i));
    }

    public BanChatMember revokeMessages(boolean z) {
        return (BanChatMember) add("revoke_messages", Boolean.valueOf(z));
    }
}
