package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;
import java.io.File;

public class SetChatPhoto extends BaseRequest<SetChatPhoto, BaseResponse> {
    public boolean isMultipart() {
        return true;
    }

    public SetChatPhoto(Object obj, byte[] bArr) {
        super(BaseResponse.class);
        ((SetChatPhoto) add("chat_id", obj)).add("photo", bArr);
    }

    public SetChatPhoto(Object obj, File file) {
        super(BaseResponse.class);
        ((SetChatPhoto) add("chat_id", obj)).add("photo", file);
    }
}
