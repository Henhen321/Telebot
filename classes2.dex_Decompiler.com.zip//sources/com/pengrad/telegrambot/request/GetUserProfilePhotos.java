package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetUserProfilePhotosResponse;

public class GetUserProfilePhotos extends BaseRequest<GetUserProfilePhotos, GetUserProfilePhotosResponse> {
    public GetUserProfilePhotos(long j) {
        super(GetUserProfilePhotosResponse.class);
        add("user_id", Long.valueOf(j));
    }

    public GetUserProfilePhotos offset(int i) {
        return (GetUserProfilePhotos) add("offset", Integer.valueOf(i));
    }

    public GetUserProfilePhotos limit(int i) {
        return (GetUserProfilePhotos) add("limit", Integer.valueOf(i));
    }
}
