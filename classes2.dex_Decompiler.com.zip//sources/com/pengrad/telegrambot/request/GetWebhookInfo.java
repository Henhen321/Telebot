package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetWebhookInfoResponse;

public class GetWebhookInfo extends BaseRequest<GetWebhookInfo, GetWebhookInfoResponse> {
    public GetWebhookInfo() {
        super(GetWebhookInfoResponse.class);
    }
}
