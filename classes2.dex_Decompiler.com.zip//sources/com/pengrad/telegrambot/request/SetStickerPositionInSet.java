package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetStickerPositionInSet extends BaseRequest<SetStickerPositionInSet, BaseResponse> {
    public SetStickerPositionInSet(String str, int i) {
        super(BaseResponse.class);
        ((SetStickerPositionInSet) add("sticker", str)).add("position", Integer.valueOf(i));
    }
}
