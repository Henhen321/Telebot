package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.BotUtils;
import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;
import java.util.LinkedHashMap;
import java.util.Map;

public abstract class BaseRequest<T extends BaseRequest<T, R>, R extends BaseResponse> {
    private final Map<String, Object> parameters;
    private final Class<? extends R> responseClass;
    protected final T thisAsT = this;

    public String getContentType() {
        return ContentTypes.GENERAL_MIME_TYPE;
    }

    public String getFileName() {
        return "file.txt";
    }

    public int getTimeoutSeconds() {
        return 0;
    }

    public boolean isMultipart() {
        return false;
    }

    public BaseRequest(Class<? extends R> cls) {
        this.responseClass = cls;
        this.parameters = new LinkedHashMap();
    }

    /* access modifiers changed from: protected */
    public T add(String str, Object obj) {
        this.parameters.put(str, obj);
        return this.thisAsT;
    }

    /* access modifiers changed from: protected */
    public T addAll(Map<String, Object> map) {
        this.parameters.putAll(map);
        return this.thisAsT;
    }

    public String getMethod() {
        String simpleName = getClass().getSimpleName();
        return Character.toLowerCase(simpleName.charAt(0)) + simpleName.substring(1);
    }

    public Map<String, Object> getParameters() {
        return this.parameters;
    }

    public Class<? extends R> getResponseType() {
        return this.responseClass;
    }

    public String toWebhookResponse() {
        LinkedHashMap linkedHashMap = new LinkedHashMap(this.parameters);
        linkedHashMap.put("method", getMethod());
        return BotUtils.toJson(linkedHashMap);
    }
}
