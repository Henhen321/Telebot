package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetStickerSetThumb extends AbstractUploadRequest<AddStickerToSet, BaseResponse> {
    public SetStickerSetThumb(String str, Long l, Object obj) {
        super(BaseResponse.class, "thumb", obj);
        add("name", str);
        add("user_id", l);
    }

    public SetStickerSetThumb(String str, Long l) {
        super(BaseResponse.class, "name", str);
        add("user_id", l);
    }
}
