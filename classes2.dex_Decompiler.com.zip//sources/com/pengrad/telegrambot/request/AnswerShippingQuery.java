package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.ShippingOption;
import com.pengrad.telegrambot.response.BaseResponse;

public class AnswerShippingQuery extends BaseRequest<AnswerShippingQuery, BaseResponse> {
    public AnswerShippingQuery(String str, ShippingOption... shippingOptionArr) {
        super(BaseResponse.class);
        ((AnswerShippingQuery) ((AnswerShippingQuery) add("shipping_query_id", str)).add("ok", true)).add("shipping_options", shippingOptionArr);
    }

    public AnswerShippingQuery(String str, String str2) {
        super(BaseResponse.class);
        ((AnswerShippingQuery) ((AnswerShippingQuery) add("shipping_query_id", str)).add("ok", false)).add("error_message", str2);
    }
}
