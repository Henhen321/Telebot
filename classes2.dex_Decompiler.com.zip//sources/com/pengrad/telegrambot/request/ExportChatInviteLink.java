package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.StringResponse;

public class ExportChatInviteLink extends BaseRequest<ExportChatInviteLink, StringResponse> {
    public ExportChatInviteLink(Object obj) {
        super(StringResponse.class);
        add("chat_id", obj);
    }
}
