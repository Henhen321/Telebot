package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.LabeledPrice;
import com.pengrad.telegrambot.response.StringResponse;

public class CreateInvoiceLink extends BaseRequest<CreateInvoiceLink, StringResponse> {
    public CreateInvoiceLink(String str, String str2, String str3, String str4, String str5, LabeledPrice... labeledPriceArr) {
        super(StringResponse.class);
        ((CreateInvoiceLink) ((CreateInvoiceLink) ((CreateInvoiceLink) ((CreateInvoiceLink) ((CreateInvoiceLink) add("title", str)).add("description", str2)).add("payload", str3)).add("provider_token", str4)).add("currency", str5)).add("prices", labeledPriceArr);
    }

    public CreateInvoiceLink maxTipAmount(int i) {
        return (CreateInvoiceLink) add("max_tip_amount", Integer.valueOf(i));
    }

    public CreateInvoiceLink suggestedTipAmounts(Integer[] numArr) {
        return (CreateInvoiceLink) add("suggested_tip_amounts", numArr);
    }

    public CreateInvoiceLink providerData(String str) {
        return (CreateInvoiceLink) add("provider_data", str);
    }

    public CreateInvoiceLink photoUrl(String str) {
        return (CreateInvoiceLink) add("photo_url", str);
    }

    public CreateInvoiceLink photoSize(Integer num) {
        return (CreateInvoiceLink) add("photo_size", num);
    }

    public CreateInvoiceLink photoWidth(Integer num) {
        return (CreateInvoiceLink) add("photo_width", num);
    }

    public CreateInvoiceLink photoHeight(Integer num) {
        return (CreateInvoiceLink) add("photo_height", num);
    }

    public CreateInvoiceLink needName(boolean z) {
        return (CreateInvoiceLink) add("need_name", Boolean.valueOf(z));
    }

    public CreateInvoiceLink needPhoneNumber(boolean z) {
        return (CreateInvoiceLink) add("need_phone_number", Boolean.valueOf(z));
    }

    public CreateInvoiceLink needEmail(boolean z) {
        return (CreateInvoiceLink) add("need_email", Boolean.valueOf(z));
    }

    public CreateInvoiceLink needShippingAddress(boolean z) {
        return (CreateInvoiceLink) add("need_shipping_address", Boolean.valueOf(z));
    }

    public CreateInvoiceLink sendEmailToProvider(boolean z) {
        return (CreateInvoiceLink) add("send_email_to_provider", Boolean.valueOf(z));
    }

    public CreateInvoiceLink sendPhoneNumberToProvider(boolean z) {
        return (CreateInvoiceLink) add("send_phone_number_to_provider", Boolean.valueOf(z));
    }

    public CreateInvoiceLink isFlexible(boolean z) {
        return (CreateInvoiceLink) add("is_flexible", Boolean.valueOf(z));
    }
}
