package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteStickerFromSet extends BaseRequest<DeleteStickerFromSet, BaseResponse> {
    public DeleteStickerFromSet(String str) {
        super(BaseResponse.class);
        add("sticker", str);
    }
}
