package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendPhoto extends AbstractMultipartRequest<SendPhoto> {
    public String getContentType() {
        return ContentTypes.PHOTO_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.PHOTO_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "photo";
    }

    public SendPhoto(Object obj, String str) {
        super(obj, str);
    }

    public SendPhoto(Object obj, File file) {
        super(obj, file);
    }

    public SendPhoto(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendPhoto caption(String str) {
        return (SendPhoto) add("caption", str);
    }

    public SendPhoto parseMode(ParseMode parseMode) {
        return (SendPhoto) add("parse_mode", parseMode.name());
    }

    public SendPhoto captionEntities(MessageEntity... messageEntityArr) {
        return (SendPhoto) add("caption_entities", messageEntityArr);
    }
}
