package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.ChatPermissions;
import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatPermissions extends BaseRequest<SetChatPermissions, BaseResponse> {
    public SetChatPermissions(Object obj, ChatPermissions chatPermissions) {
        super(BaseResponse.class);
        ((SetChatPermissions) add("chat_id", obj)).add("permissions", chatPermissions);
    }
}
