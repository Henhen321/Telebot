package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class Close extends BaseRequest<Close, BaseResponse> {
    public Close() {
        super(BaseResponse.class);
    }
}
