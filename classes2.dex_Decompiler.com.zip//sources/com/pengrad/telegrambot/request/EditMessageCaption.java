package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.model.request.ParseMode;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class EditMessageCaption extends BaseRequest<EditMessageCaption, BaseResponse> {
    public EditMessageCaption(Object obj, int i) {
        super(SendResponse.class);
        ((EditMessageCaption) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }

    public EditMessageCaption(String str) {
        super(BaseResponse.class);
        add("inline_message_id", str);
    }

    public EditMessageCaption caption(String str) {
        return (EditMessageCaption) add("caption", str);
    }

    public EditMessageCaption parseMode(ParseMode parseMode) {
        return (EditMessageCaption) add("parse_mode", parseMode.name());
    }

    public EditMessageCaption captionEntities(MessageEntity... messageEntityArr) {
        return (EditMessageCaption) add("caption_entities", messageEntityArr);
    }

    public EditMessageCaption replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (EditMessageCaption) add("reply_markup", inlineKeyboardMarkup);
    }
}
