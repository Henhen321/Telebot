package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.model.request.InputMedia;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;
import java.util.Map;

public class EditMessageMedia extends BaseRequest<EditMessageMedia, BaseResponse> {
    private boolean isMultipart;
    private InputMedia<?> media;

    public EditMessageMedia(Object obj, int i, InputMedia<?> inputMedia) {
        super(SendResponse.class);
        ((EditMessageMedia) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
        addMedia(inputMedia);
    }

    public EditMessageMedia(String str, InputMedia<?> inputMedia) {
        super(BaseResponse.class);
        add("inline_message_id", str);
        addMedia(inputMedia);
    }

    private void addMedia(InputMedia<?> inputMedia) {
        this.media = inputMedia;
        add("media", inputMedia);
        Map<String, Object> attachments = inputMedia.getAttachments();
        if (attachments != null && attachments.size() > 0) {
            addAll(attachments);
            this.isMultipart = true;
        }
    }

    public EditMessageMedia replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (EditMessageMedia) add("reply_markup", inlineKeyboardMarkup);
    }

    public boolean isMultipart() {
        return this.isMultipart;
    }

    public String getFileName() {
        return this.media.getFileName();
    }

    public String getContentType() {
        return this.media.getContentType();
    }
}
