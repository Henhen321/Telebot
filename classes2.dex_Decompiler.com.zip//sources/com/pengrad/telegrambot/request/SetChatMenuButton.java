package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MenuButton;
import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatMenuButton extends BaseRequest<SetChatMenuButton, BaseResponse> {
    public SetChatMenuButton() {
        super(BaseResponse.class);
    }

    public SetChatMenuButton chatId(long j) {
        return (SetChatMenuButton) add("chat_id", Long.valueOf(j));
    }

    public SetChatMenuButton menuButton(MenuButton menuButton) {
        return (SetChatMenuButton) add("menu_button", menuButton);
    }
}
