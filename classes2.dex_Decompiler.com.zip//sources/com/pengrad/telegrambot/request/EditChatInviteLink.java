package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.ChatInviteLinkResponse;

public class EditChatInviteLink extends BaseRequest<EditChatInviteLink, ChatInviteLinkResponse> {
    public EditChatInviteLink(Object obj, String str) {
        super(ChatInviteLinkResponse.class);
        add("chat_id", obj);
        add("invite_link", str);
    }

    public EditChatInviteLink name(String str) {
        return (EditChatInviteLink) add("name", str);
    }

    public EditChatInviteLink expireDate(Integer num) {
        return (EditChatInviteLink) add("expire_date", num);
    }

    public EditChatInviteLink memberLimit(Integer num) {
        return (EditChatInviteLink) add("member_limit", num);
    }

    public EditChatInviteLink createsJoinRequest(Boolean bool) {
        return (EditChatInviteLink) add("creates_join_request", bool);
    }
}
