package com.pengrad.telegrambot.request;

import java.io.File;

public class SendSticker extends AbstractMultipartRequest<SendSticker> {
    public String getContentType() {
        return ContentTypes.PHOTO_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.PHOTO_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "sticker";
    }

    public SendSticker(Object obj, String str) {
        super(obj, str);
    }

    public SendSticker(Object obj, File file) {
        super(obj, file);
    }

    public SendSticker(Object obj, byte[] bArr) {
        super(obj, bArr);
    }
}
