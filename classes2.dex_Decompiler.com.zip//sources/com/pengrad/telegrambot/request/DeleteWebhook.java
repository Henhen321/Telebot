package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteWebhook extends BaseRequest<DeleteWebhook, BaseResponse> {
    public DeleteWebhook() {
        super(BaseResponse.class);
    }

    public DeleteWebhook dropPendingUpdates(boolean z) {
        return (DeleteWebhook) add("drop_pending_updates", Boolean.valueOf(z));
    }
}
