package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.Keyboard;
import com.pengrad.telegrambot.request.AbstractSendRequest;
import com.pengrad.telegrambot.response.SendResponse;

public abstract class AbstractSendRequest<T extends AbstractSendRequest<T>> extends BaseRequest<T, SendResponse> {
    public AbstractSendRequest(Object obj) {
        super(SendResponse.class);
        add("chat_id", obj);
    }

    public T disableNotification(boolean z) {
        return (AbstractSendRequest) add("disable_notification", Boolean.valueOf(z));
    }

    public T replyToMessageId(int i) {
        return (AbstractSendRequest) add("reply_to_message_id", Integer.valueOf(i));
    }

    public T allowSendingWithoutReply(boolean z) {
        return (AbstractSendRequest) add("allow_sending_without_reply", Boolean.valueOf(z));
    }

    public T replyMarkup(Keyboard keyboard) {
        return (AbstractSendRequest) add("reply_markup", keyboard);
    }

    public T protectContent(boolean z) {
        return (AbstractSendRequest) add("protect_content", Boolean.valueOf(z));
    }
}
