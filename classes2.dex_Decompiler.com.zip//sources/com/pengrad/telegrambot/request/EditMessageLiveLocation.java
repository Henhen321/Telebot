package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class EditMessageLiveLocation extends BaseRequest<EditMessageLiveLocation, BaseResponse> {
    public EditMessageLiveLocation(Object obj, int i, float f, float f2) {
        super(SendResponse.class);
        ((EditMessageLiveLocation) ((EditMessageLiveLocation) ((EditMessageLiveLocation) add("chat_id", obj)).add("message_id", Integer.valueOf(i))).add("latitude", Float.valueOf(f))).add("longitude", Float.valueOf(f2));
    }

    public EditMessageLiveLocation(String str, float f, float f2) {
        super(BaseResponse.class);
        ((EditMessageLiveLocation) ((EditMessageLiveLocation) add("inline_message_id", str)).add("latitude", Float.valueOf(f))).add("longitude", Float.valueOf(f2));
    }

    public EditMessageLiveLocation horizontalAccuracy(float f) {
        return (EditMessageLiveLocation) add("horizontal_accuracy", Float.valueOf(f));
    }

    public EditMessageLiveLocation heading(int i) {
        return (EditMessageLiveLocation) add("heading", Integer.valueOf(i));
    }

    public EditMessageLiveLocation proximityAlertRadius(int i) {
        return (EditMessageLiveLocation) add("proximity_alert_radius", Integer.valueOf(i));
    }

    public EditMessageLiveLocation replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (EditMessageLiveLocation) add("reply_markup", inlineKeyboardMarkup);
    }
}
