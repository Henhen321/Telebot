package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class BanChatSenderChat extends BaseRequest<BanChatSenderChat, BaseResponse> {
    public BanChatSenderChat(Object obj, long j) {
        super(BaseResponse.class);
        ((BanChatSenderChat) add("chat_id", obj)).add("sender_chat_id", Long.valueOf(j));
    }
}
