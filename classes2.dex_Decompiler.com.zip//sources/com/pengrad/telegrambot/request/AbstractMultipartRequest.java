package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.request.AbstractMultipartRequest;
import java.io.File;

public abstract class AbstractMultipartRequest<T extends AbstractMultipartRequest<T>> extends AbstractSendRequest<T> {
    private String fileName;
    private boolean isMultipart;

    public abstract String getContentType();

    /* access modifiers changed from: protected */
    public abstract String getDefaultFileName();

    /* access modifiers changed from: protected */
    public abstract String getFileParamName();

    public AbstractMultipartRequest(Object obj, Object obj2) {
        super(obj);
        if (obj2 instanceof String) {
            this.isMultipart = false;
        } else if (obj2 instanceof File) {
            this.isMultipart = true;
            this.fileName = ((File) obj2).getName();
        } else if (obj2 instanceof byte[]) {
            this.isMultipart = true;
        } else {
            throw new IllegalArgumentException("Sending data should be String, File or byte[]");
        }
        add(getFileParamName(), obj2);
    }

    public T fileName(String str) {
        this.fileName = str;
        return (AbstractMultipartRequest) this.thisAsT;
    }

    /* access modifiers changed from: protected */
    public T thumb(Object obj) {
        this.isMultipart = true;
        return (AbstractMultipartRequest) add("thumb", obj);
    }

    public boolean isMultipart() {
        return this.isMultipart;
    }

    public String getFileName() {
        String str = this.fileName;
        if (str == null || str.isEmpty()) {
            return getDefaultFileName();
        }
        return this.fileName;
    }
}
