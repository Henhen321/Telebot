package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetMeResponse;

public class GetMe extends BaseRequest<GetMe, GetMeResponse> {
    public GetMe() {
        super(GetMeResponse.class);
    }
}
