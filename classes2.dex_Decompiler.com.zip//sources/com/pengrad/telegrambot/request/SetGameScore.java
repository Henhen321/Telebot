package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class SetGameScore extends BaseRequest<SetGameScore, BaseResponse> {
    public SetGameScore(long j, int i, Object obj, int i2) {
        super(SendResponse.class);
        ((SetGameScore) ((SetGameScore) ((SetGameScore) add("user_id", Long.valueOf(j))).add("score", Integer.valueOf(i))).add("chat_id", obj)).add("message_id", Integer.valueOf(i2));
    }

    public SetGameScore(long j, int i, String str) {
        super(BaseResponse.class);
        ((SetGameScore) ((SetGameScore) add("user_id", Long.valueOf(j))).add("score", Integer.valueOf(i))).add("inline_message_id", str);
    }

    public SetGameScore force(boolean z) {
        return (SetGameScore) add("force", Boolean.valueOf(z));
    }

    public SetGameScore disableEditMessage(boolean z) {
        return (SetGameScore) add("disable_edit_message", Boolean.valueOf(z));
    }
}
