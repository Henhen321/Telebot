package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.response.BaseResponse;
import com.pengrad.telegrambot.response.SendResponse;

public class EditMessageReplyMarkup extends BaseRequest<EditMessageReplyMarkup, BaseResponse> {
    public EditMessageReplyMarkup(Object obj, int i) {
        super(SendResponse.class);
        ((EditMessageReplyMarkup) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }

    public EditMessageReplyMarkup(String str) {
        super(BaseResponse.class);
        add("inline_message_id", str);
    }

    public EditMessageReplyMarkup replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        return (EditMessageReplyMarkup) add("reply_markup", inlineKeyboardMarkup);
    }
}
