package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class ApproveChatJoinRequest extends BaseRequest<ApproveChatJoinRequest, BaseResponse> {
    public ApproveChatJoinRequest(Object obj, Long l) {
        super(BaseResponse.class);
        add("chat_id", obj);
        add("user_id", l);
    }
}
