package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MaskPosition;
import com.pengrad.telegrambot.response.BaseResponse;

public class AddStickerToSet extends AbstractUploadRequest<AddStickerToSet, BaseResponse> {
    public static AddStickerToSet tgsSticker(Long l, String str, String str2, Object obj) {
        return new AddStickerToSet(l, str, str2, "tgs_sticker", obj);
    }

    public static AddStickerToSet pngSticker(Long l, String str, String str2, Object obj) {
        return new AddStickerToSet(l, str, str2, "png_sticker", obj);
    }

    public static AddStickerToSet webmSticker(Long l, String str, String str2, Object obj) {
        return new AddStickerToSet(l, str, str2, "webm_sticker", obj);
    }

    @Deprecated
    public AddStickerToSet(Long l, String str, Object obj, String str2) {
        this(l, str, str2, "png_sticker", obj);
    }

    private AddStickerToSet(Long l, String str, String str2, String str3, Object obj) {
        super(BaseResponse.class, str3, obj);
        add("user_id", l);
        add("name", str);
        add("emojis", str2);
    }

    public AddStickerToSet maskPosition(MaskPosition maskPosition) {
        return (AddStickerToSet) add("mask_position", maskPosition);
    }
}
