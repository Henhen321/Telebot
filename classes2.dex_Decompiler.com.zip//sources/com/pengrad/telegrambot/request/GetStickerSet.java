package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetStickerSetResponse;

public class GetStickerSet extends BaseRequest<GetStickerSet, GetStickerSetResponse> {
    public GetStickerSet(String str) {
        super(GetStickerSetResponse.class);
        add("name", str);
    }
}
