package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.ChatAdministratorRights;
import com.pengrad.telegrambot.response.BaseResponse;

public class SetMyDefaultAdministratorRights extends BaseRequest<SetMyDefaultAdministratorRights, BaseResponse> {
    public SetMyDefaultAdministratorRights() {
        super(BaseResponse.class);
    }

    public SetMyDefaultAdministratorRights rights(ChatAdministratorRights chatAdministratorRights) {
        return (SetMyDefaultAdministratorRights) add("rights", chatAdministratorRights);
    }

    public SetMyDefaultAdministratorRights forChannels(boolean z) {
        return (SetMyDefaultAdministratorRights) add("for_channels", Boolean.valueOf(z));
    }
}
