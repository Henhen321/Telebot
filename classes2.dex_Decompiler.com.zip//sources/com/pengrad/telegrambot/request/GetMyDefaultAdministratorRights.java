package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetMyDefaultAdministratorRightsResponse;

public class GetMyDefaultAdministratorRights extends BaseRequest<GetMyDefaultAdministratorRights, GetMyDefaultAdministratorRightsResponse> {
    public GetMyDefaultAdministratorRights() {
        super(GetMyDefaultAdministratorRightsResponse.class);
    }

    public GetMyDefaultAdministratorRights forChannels(boolean z) {
        return (GetMyDefaultAdministratorRights) add("for_channels", Boolean.valueOf(z));
    }
}
