package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.Poll;
import com.pengrad.telegrambot.model.request.ParseMode;

public class SendPoll extends AbstractSendRequest<SendPoll> {
    public SendPoll(Object obj, String str, String... strArr) {
        super(obj);
        add("question", str);
        add("options", strArr);
    }

    public SendPoll isAnonymous(boolean z) {
        return (SendPoll) add("is_anonymous", Boolean.valueOf(z));
    }

    public SendPoll type(String str) {
        return (SendPoll) add("type", str);
    }

    public SendPoll type(Poll.Type type) {
        return (SendPoll) add("type", type.name());
    }

    public SendPoll allowsMultipleAnswers(boolean z) {
        return (SendPoll) add("allows_multiple_answers", Boolean.valueOf(z));
    }

    public SendPoll correctOptionId(int i) {
        return (SendPoll) add("correct_option_id", Integer.valueOf(i));
    }

    public SendPoll explanation(String str) {
        return (SendPoll) add("explanation", str);
    }

    public SendPoll explanationParseMode(ParseMode parseMode) {
        return (SendPoll) add("explanation_parse_mode", parseMode.name());
    }

    public SendPoll explanationEntities(MessageEntity... messageEntityArr) {
        return (SendPoll) add("explanation_entities", messageEntityArr);
    }

    public SendPoll openPeriod(int i) {
        return (SendPoll) add("open_period", Integer.valueOf(i));
    }

    public SendPoll closeDate(long j) {
        return (SendPoll) add("close_date", Long.valueOf(j));
    }

    public SendPoll isClosed(boolean z) {
        return (SendPoll) add("is_closed", Boolean.valueOf(z));
    }
}
