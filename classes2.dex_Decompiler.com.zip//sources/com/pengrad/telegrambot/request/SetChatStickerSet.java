package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class SetChatStickerSet extends BaseRequest<SetChatStickerSet, BaseResponse> {
    public SetChatStickerSet(Object obj, String str) {
        super(BaseResponse.class);
        ((SetChatStickerSet) add("chat_id", obj)).add("sticker_set_name", str);
    }
}
