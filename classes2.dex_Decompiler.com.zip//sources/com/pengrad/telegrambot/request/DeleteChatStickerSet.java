package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteChatStickerSet extends BaseRequest<DeleteChatStickerSet, BaseResponse> {
    public DeleteChatStickerSet(Object obj) {
        super(BaseResponse.class);
        add("chat_id", obj);
    }
}
