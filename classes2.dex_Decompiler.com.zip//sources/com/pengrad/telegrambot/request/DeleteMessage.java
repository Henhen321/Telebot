package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteMessage extends BaseRequest<DeleteMessage, BaseResponse> {
    public DeleteMessage(Object obj, int i) {
        super(BaseResponse.class);
        ((DeleteMessage) add("chat_id", obj)).add("message_id", Integer.valueOf(i));
    }
}
