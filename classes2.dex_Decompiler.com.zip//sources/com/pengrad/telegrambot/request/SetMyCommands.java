package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.BotCommand;
import com.pengrad.telegrambot.model.botcommandscope.BotCommandScope;
import com.pengrad.telegrambot.response.BaseResponse;

public class SetMyCommands extends BaseRequest<SetMyCommands, BaseResponse> {
    public SetMyCommands(BotCommand... botCommandArr) {
        super(BaseResponse.class);
        add("commands", botCommandArr);
    }

    public SetMyCommands scope(BotCommandScope botCommandScope) {
        add("scope", botCommandScope);
        return this;
    }

    public SetMyCommands languageCode(String str) {
        add("language_code", str);
        return this;
    }
}
