package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;

public class SendMessage extends AbstractSendRequest<SendMessage> {
    public SendMessage(Object obj, String str) {
        super(obj);
        add("text", str);
    }

    public SendMessage parseMode(ParseMode parseMode) {
        return (SendMessage) add("parse_mode", parseMode.name());
    }

    public SendMessage entities(MessageEntity... messageEntityArr) {
        return (SendMessage) add("entities", messageEntityArr);
    }

    public SendMessage disableWebPagePreview(boolean z) {
        return (SendMessage) add("disable_web_page_preview", Boolean.valueOf(z));
    }
}
