package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatAdministratorsResponse;

public class GetChatAdministrators extends BaseRequest<GetChatAdministrators, GetChatAdministratorsResponse> {
    public GetChatAdministrators(Object obj) {
        super(GetChatAdministratorsResponse.class);
        add("chat_id", obj);
    }
}
