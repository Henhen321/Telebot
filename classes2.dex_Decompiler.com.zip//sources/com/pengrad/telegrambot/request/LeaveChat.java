package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class LeaveChat extends BaseRequest<LeaveChat, BaseResponse> {
    public LeaveChat(Object obj) {
        super(BaseResponse.class);
        add("chat_id", obj);
    }
}
