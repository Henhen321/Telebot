package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;
import java.io.File;

public abstract class AbstractUploadRequest<T extends BaseRequest<T, R>, R extends BaseResponse> extends BaseRequest<T, R> {
    private final boolean isMultipart;

    public AbstractUploadRequest(Class<? extends R> cls, String str, Object obj) {
        super(cls);
        if (obj instanceof String) {
            this.isMultipart = false;
        } else if (obj instanceof File) {
            this.isMultipart = true;
        } else if (obj instanceof byte[]) {
            this.isMultipart = true;
        } else {
            throw new IllegalArgumentException("Sending data should be String, File or byte[]");
        }
        add(str, obj);
    }

    public boolean isMultipart() {
        return this.isMultipart;
    }
}
