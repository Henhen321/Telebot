package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineQueryResult;
import com.pengrad.telegrambot.response.SentWebAppMessageResponse;

public class AnswerWebAppQuery extends BaseRequest<AnswerWebAppQuery, SentWebAppMessageResponse> {
    public AnswerWebAppQuery(String str, InlineQueryResult<?> inlineQueryResult) {
        super(SentWebAppMessageResponse.class);
        ((AnswerWebAppQuery) add("web_app_query_id", str)).add("result", inlineQueryResult);
    }
}
