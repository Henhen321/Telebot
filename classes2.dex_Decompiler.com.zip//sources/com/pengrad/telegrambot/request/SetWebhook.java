package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;
import java.io.File;

public class SetWebhook extends BaseRequest<SetWebhook, BaseResponse> {
    private boolean isMultipart = false;

    public SetWebhook() {
        super(BaseResponse.class);
    }

    public SetWebhook url(String str) {
        return (SetWebhook) add("url", str);
    }

    public SetWebhook certificate(byte[] bArr) {
        this.isMultipart = true;
        return (SetWebhook) add("certificate", bArr);
    }

    public SetWebhook certificate(File file) {
        this.isMultipart = true;
        return (SetWebhook) add("certificate", file);
    }

    public SetWebhook ipAddress(String str) {
        return (SetWebhook) add("ip_address", str);
    }

    public SetWebhook maxConnections(int i) {
        return (SetWebhook) add("max_connections", Integer.valueOf(i));
    }

    public SetWebhook allowedUpdates(String... strArr) {
        return (SetWebhook) add("allowed_updates", strArr);
    }

    public SetWebhook dropPendingUpdates(boolean z) {
        return (SetWebhook) add("drop_pending_updates", Boolean.valueOf(z));
    }

    public SetWebhook secretToken(String str) {
        return (SetWebhook) add("secret_token", str);
    }

    public boolean isMultipart() {
        return this.isMultipart;
    }
}
