package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

@Deprecated
public class KickChatMember extends BaseRequest<KickChatMember, BaseResponse> {
    public KickChatMember(Object obj, long j) {
        super(BaseResponse.class);
        ((KickChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }

    public KickChatMember untilDate(int i) {
        return (KickChatMember) add("until_date", Integer.valueOf(i));
    }

    public KickChatMember revokeMessages(boolean z) {
        return (KickChatMember) add("revoke_messages", Boolean.valueOf(z));
    }
}
