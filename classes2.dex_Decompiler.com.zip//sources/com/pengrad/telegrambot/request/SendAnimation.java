package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendAnimation extends AbstractMultipartRequest<SendAnimation> {
    public String getContentType() {
        return ContentTypes.GIF_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.GIF_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "animation";
    }

    public SendAnimation(Object obj, String str) {
        super(obj, str);
    }

    public SendAnimation(Object obj, File file) {
        super(obj, file);
    }

    public SendAnimation(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendAnimation duration(int i) {
        return (SendAnimation) add("duration", Integer.valueOf(i));
    }

    public SendAnimation width(int i) {
        return (SendAnimation) add("width", Integer.valueOf(i));
    }

    public SendAnimation height(int i) {
        return (SendAnimation) add("height", Integer.valueOf(i));
    }

    public SendAnimation thumb(byte[] bArr) {
        return (SendAnimation) super.thumb(bArr);
    }

    public SendAnimation thumb(File file) {
        return (SendAnimation) super.thumb(file);
    }

    public SendAnimation caption(String str) {
        return (SendAnimation) add("caption", str);
    }

    public SendAnimation parseMode(ParseMode parseMode) {
        return (SendAnimation) add("parse_mode", parseMode.name());
    }

    public SendAnimation captionEntities(MessageEntity... messageEntityArr) {
        return (SendAnimation) add("caption_entities", messageEntityArr);
    }
}
