package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class UnbanChatMember extends BaseRequest<UnbanChatMember, BaseResponse> {
    public UnbanChatMember(Object obj, long j) {
        super(BaseResponse.class);
        ((UnbanChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }

    public UnbanChatMember onlyIfBanned(boolean z) {
        return (UnbanChatMember) add("only_if_banned", Boolean.valueOf(z));
    }
}
