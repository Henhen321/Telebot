package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendVoice extends AbstractMultipartRequest<SendVoice> {
    public String getContentType() {
        return ContentTypes.VOICE_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.VOICE_FILE_NAME;
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "voice";
    }

    public SendVoice(Object obj, String str) {
        super(obj, str);
    }

    public SendVoice(Object obj, File file) {
        super(obj, file);
    }

    public SendVoice(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendVoice caption(String str) {
        return (SendVoice) add("caption", str);
    }

    public SendVoice parseMode(ParseMode parseMode) {
        return (SendVoice) add("parse_mode", parseMode.name());
    }

    public SendVoice captionEntities(MessageEntity... messageEntityArr) {
        return (SendVoice) add("caption_entities", messageEntityArr);
    }

    public SendVoice duration(int i) {
        return (SendVoice) add("duration", Integer.valueOf(i));
    }
}
