package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetCustomEmojiStickersResponse;

public class GetCustomEmojiStickers extends BaseRequest<GetCustomEmojiStickers, GetCustomEmojiStickersResponse> {
    public GetCustomEmojiStickers(String... strArr) {
        super(GetCustomEmojiStickersResponse.class);
        add("custom_emoji_ids", strArr);
    }
}
