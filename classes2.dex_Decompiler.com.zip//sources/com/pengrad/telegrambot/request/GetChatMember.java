package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.GetChatMemberResponse;

public class GetChatMember extends BaseRequest<GetChatMember, GetChatMemberResponse> {
    public GetChatMember(Object obj, long j) {
        super(GetChatMemberResponse.class);
        ((GetChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }
}
