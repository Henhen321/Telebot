package com.pengrad.telegrambot.request;

public class SendLocation extends AbstractSendRequest<SendLocation> {
    public SendLocation(Object obj, float f, float f2) {
        super(obj);
        add("latitude", Float.valueOf(f));
        add("longitude", Float.valueOf(f2));
    }

    public SendLocation horizontalAccuracy(float f) {
        return (SendLocation) add("horizontal_accuracy", Float.valueOf(f));
    }

    public SendLocation livePeriod(int i) {
        return (SendLocation) add("live_period", Integer.valueOf(i));
    }

    public SendLocation heading(int i) {
        return (SendLocation) add("heading", Integer.valueOf(i));
    }

    public SendLocation proximityAlertRadius(int i) {
        return (SendLocation) add("proximity_alert_radius", Integer.valueOf(i));
    }
}
