package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.request.InlineQueryResult;
import com.pengrad.telegrambot.response.BaseResponse;

public class AnswerInlineQuery extends BaseRequest<AnswerInlineQuery, BaseResponse> {
    public AnswerInlineQuery(String str, InlineQueryResult<?>... inlineQueryResultArr) {
        super(BaseResponse.class);
        ((AnswerInlineQuery) add("inline_query_id", str)).add("results", inlineQueryResultArr);
    }

    public AnswerInlineQuery cacheTime(int i) {
        return (AnswerInlineQuery) add("cache_time", Integer.valueOf(i));
    }

    public AnswerInlineQuery isPersonal(boolean z) {
        return (AnswerInlineQuery) add("is_personal", Boolean.valueOf(z));
    }

    public AnswerInlineQuery nextOffset(String str) {
        return (AnswerInlineQuery) add("next_offset", str);
    }

    public AnswerInlineQuery switchPmText(String str) {
        return (AnswerInlineQuery) add("switch_pm_text", str);
    }

    public AnswerInlineQuery switchPmParameter(String str) {
        return (AnswerInlineQuery) add("switch_pm_parameter", str);
    }
}
