package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.ChatPermissions;
import com.pengrad.telegrambot.response.BaseResponse;

public class RestrictChatMember extends BaseRequest<RestrictChatMember, BaseResponse> {
    public RestrictChatMember(Object obj, long j) {
        super(BaseResponse.class);
        ((RestrictChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j));
    }

    public RestrictChatMember(Object obj, long j, ChatPermissions chatPermissions) {
        super(BaseResponse.class);
        ((RestrictChatMember) ((RestrictChatMember) add("chat_id", obj)).add("user_id", Long.valueOf(j))).add("permissions", chatPermissions);
    }

    public RestrictChatMember untilDate(int i) {
        return (RestrictChatMember) add("until_date", Integer.valueOf(i));
    }

    public RestrictChatMember canSendMessages(boolean z) {
        return (RestrictChatMember) add("can_send_messages", Boolean.valueOf(z));
    }

    public RestrictChatMember canSendMediaMessages(boolean z) {
        return (RestrictChatMember) add("can_send_media_messages", Boolean.valueOf(z));
    }

    public RestrictChatMember canSendOtherMessages(boolean z) {
        return (RestrictChatMember) add("can_send_other_messages", Boolean.valueOf(z));
    }

    public RestrictChatMember canAddWebPagePreviews(boolean z) {
        return (RestrictChatMember) add("can_add_web_page_previews", Boolean.valueOf(z));
    }
}
