package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.response.BaseResponse;

public class AnswerPreCheckoutQuery extends BaseRequest<AnswerPreCheckoutQuery, BaseResponse> {
    public AnswerPreCheckoutQuery(String str) {
        super(BaseResponse.class);
        ((AnswerPreCheckoutQuery) add("pre_checkout_query_id", str)).add("ok", true);
    }

    public AnswerPreCheckoutQuery(String str, String str2) {
        super(BaseResponse.class);
        ((AnswerPreCheckoutQuery) ((AnswerPreCheckoutQuery) add("pre_checkout_query_id", str)).add("ok", false)).add("error_message", str2);
    }
}
