package com.pengrad.telegrambot.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.ParseMode;
import java.io.File;

public class SendDocument extends AbstractMultipartRequest<SendDocument> {
    public String getContentType() {
        return ContentTypes.DOC_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return "file.txt";
    }

    /* access modifiers changed from: protected */
    public String getFileParamName() {
        return "document";
    }

    public SendDocument(Object obj, String str) {
        super(obj, str);
    }

    public SendDocument(Object obj, File file) {
        super(obj, file);
    }

    public SendDocument(Object obj, byte[] bArr) {
        super(obj, bArr);
    }

    public SendDocument thumb(byte[] bArr) {
        return (SendDocument) super.thumb(bArr);
    }

    public SendDocument thumb(File file) {
        return (SendDocument) super.thumb(file);
    }

    public SendDocument caption(String str) {
        return (SendDocument) add("caption", str);
    }

    public SendDocument parseMode(ParseMode parseMode) {
        return (SendDocument) add("parse_mode", parseMode.name());
    }

    public SendDocument captionEntities(MessageEntity... messageEntityArr) {
        return (SendDocument) add("caption_entities", messageEntityArr);
    }

    public SendDocument disableContentTypeDetection(boolean z) {
        return (SendDocument) add("disable_content_type_detection", Boolean.valueOf(z));
    }
}
