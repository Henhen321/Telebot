package com.pengrad.telegrambot;

import com.google.gson.Gson;
import com.pengrad.telegrambot.model.Update;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import okhttp3.internal.http2.Settings;

public class BotUtils {
    private static final Gson gson = new Gson();

    private BotUtils() {
    }

    public static Update parseUpdate(String str) {
        return (Update) gson.fromJson(str, Update.class);
    }

    public static Update parseUpdate(Reader reader) {
        return (Update) gson.fromJson(reader, Update.class);
    }

    static byte[] getBytesFromInputStream(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[Settings.DEFAULT_INITIAL_WINDOW_SIZE];
        while (true) {
            int read = inputStream.read(bArr);
            if (read == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            byteArrayOutputStream.write(bArr, 0, read);
        }
    }

    public static <R> R fromJson(String str, Class<R> cls) {
        return gson.fromJson(str, cls);
    }

    public static String toJson(Object obj) {
        return gson.toJson(obj);
    }
}
