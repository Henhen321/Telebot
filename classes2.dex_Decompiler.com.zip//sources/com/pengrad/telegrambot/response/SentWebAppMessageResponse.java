package com.pengrad.telegrambot.response;

public class SentWebAppMessageResponse extends BaseResponse {
    private String inline_message_id;

    public String inlineMessageId() {
        return this.inline_message_id;
    }

    public String toString() {
        return "SentWebAppMessageResponse{inline_message_id=" + this.inline_message_id + '}';
    }
}
