package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.GameHighScore;
import java.util.Arrays;

public class GetGameHighScoresResponse extends BaseResponse {
    private GameHighScore[] result;

    public GameHighScore[] result() {
        return this.result;
    }

    public String toString() {
        return "GetGameHighScoresResponse{result=" + Arrays.toString(this.result) + '}';
    }
}
