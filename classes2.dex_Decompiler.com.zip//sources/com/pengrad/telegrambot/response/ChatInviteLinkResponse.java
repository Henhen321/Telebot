package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.ChatInviteLink;

public class ChatInviteLinkResponse extends BaseResponse {
    private ChatInviteLink result;

    public ChatInviteLink chatInviteLink() {
        return this.result;
    }

    public String toString() {
        return "ChatInviteLinkResponse{result=" + this.result + '}';
    }
}
