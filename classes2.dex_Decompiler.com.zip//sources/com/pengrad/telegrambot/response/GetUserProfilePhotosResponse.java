package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.UserProfilePhotos;

public class GetUserProfilePhotosResponse extends BaseResponse {
    private UserProfilePhotos result;

    GetUserProfilePhotosResponse() {
    }

    public UserProfilePhotos photos() {
        return this.result;
    }

    public String toString() {
        return "GetUserProfilePhotosResponse{result=" + this.result + '}';
    }
}
