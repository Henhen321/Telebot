package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Message;

public class SendResponse extends BaseResponse {
    private Message result;

    SendResponse() {
    }

    public Message message() {
        return this.result;
    }

    public String toString() {
        return "SendResponse{result=" + this.result + '}';
    }
}
