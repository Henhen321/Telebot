package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Chat;

public class GetChatResponse extends BaseResponse {
    private Chat result;

    public Chat chat() {
        return this.result;
    }

    public String toString() {
        return "GetChatResponse{result=" + this.result + '}';
    }
}
