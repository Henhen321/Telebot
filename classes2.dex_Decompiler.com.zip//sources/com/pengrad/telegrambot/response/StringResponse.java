package com.pengrad.telegrambot.response;

public class StringResponse extends BaseResponse {
    private String result;

    public String result() {
        return this.result;
    }

    public String toString() {
        return "StringResponse{result='" + this.result + '\'' + ", base=" + super.toString() + '}';
    }
}
