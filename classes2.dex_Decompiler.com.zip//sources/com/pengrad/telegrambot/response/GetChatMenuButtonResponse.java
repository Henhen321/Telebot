package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.MenuButton;

public class GetChatMenuButtonResponse extends BaseResponse {
    private MenuButton result;

    public MenuButton result() {
        return this.result;
    }

    public String toString() {
        return "GetChatMenuButtonResponse{result=" + this.result + '}';
    }
}
