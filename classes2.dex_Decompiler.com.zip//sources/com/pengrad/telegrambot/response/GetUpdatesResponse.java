package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Update;
import java.util.List;

public class GetUpdatesResponse extends BaseResponse {
    private List<Update> result;

    GetUpdatesResponse() {
    }

    public List<Update> updates() {
        return this.result;
    }

    public String toString() {
        return "GetUpdatesResponse{result=" + this.result + '}';
    }
}
