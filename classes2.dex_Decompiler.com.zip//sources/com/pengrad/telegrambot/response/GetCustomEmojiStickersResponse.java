package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Sticker;
import java.util.Arrays;

public class GetCustomEmojiStickersResponse extends BaseResponse {
    private Sticker[] result;

    public Sticker[] result() {
        return this.result;
    }

    public String toString() {
        return "GetCustomEmojiStickersResponse{result=" + Arrays.toString(this.result) + '}';
    }
}
