package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.ChatAdministratorRights;

public class GetMyDefaultAdministratorRightsResponse extends BaseResponse {
    private ChatAdministratorRights result;

    public ChatAdministratorRights result() {
        return this.result;
    }

    public String toString() {
        return "GetMyDefaultAdministratorRightsResponse{result=" + this.result + '}';
    }
}
