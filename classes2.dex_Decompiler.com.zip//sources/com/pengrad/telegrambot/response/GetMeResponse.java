package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.User;

public class GetMeResponse extends BaseResponse {
    private User result;

    GetMeResponse() {
    }

    public User user() {
        return this.result;
    }

    public String toString() {
        return "GetMeResponse{result=" + this.result + '}';
    }
}
