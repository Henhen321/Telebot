package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.ChatMember;
import java.util.List;

public class GetChatAdministratorsResponse extends BaseResponse {
    private List<ChatMember> result;

    public List<ChatMember> administrators() {
        return this.result;
    }

    public String toString() {
        return "GetChatAdministratorsResponse{result=" + this.result + '}';
    }
}
