package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.StickerSet;

public class GetStickerSetResponse extends BaseResponse {
    private StickerSet result;

    public StickerSet stickerSet() {
        return this.result;
    }

    public String toString() {
        return "GetStickerSetResponse{result=" + this.result + '}';
    }
}
