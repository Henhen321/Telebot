package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Message;
import java.util.Arrays;

public class MessagesResponse extends BaseResponse {
    private Message[] result;

    MessagesResponse() {
    }

    public Message[] messages() {
        return this.result;
    }

    public String toString() {
        return "MessagesResponse{result=" + Arrays.toString(this.result) + '}';
    }
}
