package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.ResponseParameters;

public class BaseResponse {
    private String description;
    private int error_code;
    private boolean ok;
    private ResponseParameters parameters;

    BaseResponse() {
    }

    public boolean isOk() {
        return this.ok;
    }

    public int errorCode() {
        return this.error_code;
    }

    public String description() {
        return this.description;
    }

    public ResponseParameters parameters() {
        return this.parameters;
    }

    public String toString() {
        return "BaseResponse{ok=" + this.ok + ", error_code=" + this.error_code + ", description='" + this.description + '\'' + ", parameters=" + this.parameters + '}';
    }
}
