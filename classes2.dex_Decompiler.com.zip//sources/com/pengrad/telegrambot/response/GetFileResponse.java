package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.File;

public class GetFileResponse extends BaseResponse {
    private File result;

    GetFileResponse() {
    }

    public File file() {
        return this.result;
    }

    public String toString() {
        return "GetFileResponse{result=" + this.result + '}';
    }
}
