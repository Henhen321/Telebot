package com.pengrad.telegrambot.response;

@Deprecated
public class GetChatMembersCountResponse extends BaseResponse {
    private int result;

    public int count() {
        return this.result;
    }

    public String toString() {
        return "GetChatMembersCountResponse{result=" + this.result + '}';
    }
}
