package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.BotCommand;
import java.util.Arrays;

public class GetMyCommandsResponse extends BaseResponse {
    private BotCommand[] result;

    public BotCommand[] commands() {
        return this.result;
    }

    public String toString() {
        return "GetMyCommandsResponse{result=" + Arrays.toString(this.result) + '}';
    }
}
