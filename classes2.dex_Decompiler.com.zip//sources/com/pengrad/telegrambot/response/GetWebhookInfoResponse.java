package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.WebhookInfo;

public class GetWebhookInfoResponse extends BaseResponse {
    private WebhookInfo result;

    public WebhookInfo webhookInfo() {
        return this.result;
    }

    public String toString() {
        return "GetWebhookInfoResponse{result=" + this.result + '}';
    }
}
