package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.ChatMember;

public class GetChatMemberResponse extends BaseResponse {
    private ChatMember result;

    public ChatMember chatMember() {
        return this.result;
    }

    public String toString() {
        return "GetChatMemberResponse{result=" + this.result + '}';
    }
}
