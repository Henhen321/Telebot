package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.Poll;

public class PollResponse extends BaseResponse {
    private Poll result;

    public Poll poll() {
        return this.result;
    }

    public String toString() {
        return "PollResponse{result=" + this.result + '}';
    }
}
