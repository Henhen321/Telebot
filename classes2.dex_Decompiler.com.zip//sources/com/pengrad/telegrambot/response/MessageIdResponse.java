package com.pengrad.telegrambot.response;

import com.pengrad.telegrambot.model.MessageId;

public class MessageIdResponse extends BaseResponse {
    private MessageId result;

    public MessageId result() {
        return this.result;
    }

    public Integer messageId() {
        return this.result.messageId();
    }

    public String toString() {
        return "MessageIdResponse{result=" + this.result + '}';
    }
}
