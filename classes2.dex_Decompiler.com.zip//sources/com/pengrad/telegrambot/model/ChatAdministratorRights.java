package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ChatAdministratorRights implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean can_change_info;
    private Boolean can_delete_messages;
    private Boolean can_edit_messages;
    private Boolean can_invite_users;
    private Boolean can_manage_chat;
    private Boolean can_manage_video_chats;
    private Boolean can_pin_messages;
    private Boolean can_post_messages;
    private Boolean can_promote_members;
    private Boolean can_restrict_members;
    private Boolean is_anonymous;

    public Boolean isAnonymous() {
        return this.is_anonymous;
    }

    public Boolean canManageChat() {
        return this.can_manage_chat;
    }

    public Boolean canDeleteMessages() {
        return this.can_delete_messages;
    }

    public Boolean canManageVideoChats() {
        return this.can_manage_video_chats;
    }

    public Boolean canRestrictMembers() {
        return this.can_restrict_members;
    }

    public Boolean canPromoteMembers() {
        return this.can_promote_members;
    }

    public Boolean canChangeInfo() {
        return this.can_change_info;
    }

    public Boolean canInviteUsers() {
        return this.can_invite_users;
    }

    public Boolean canPostMessages() {
        return this.can_post_messages;
    }

    public Boolean canEditMessages() {
        return this.can_edit_messages;
    }

    public Boolean canPinMessages() {
        return this.can_pin_messages;
    }

    public ChatAdministratorRights canManageChat(boolean z) {
        this.can_manage_chat = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canDeleteMessages(boolean z) {
        this.can_delete_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canManageVideoChats(boolean z) {
        this.can_manage_video_chats = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canRestrictMembers(boolean z) {
        this.can_restrict_members = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canPromoteMembers(boolean z) {
        this.can_promote_members = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canChangeInfo(boolean z) {
        this.can_change_info = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canInviteUsers(boolean z) {
        this.can_invite_users = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canPostMessages(boolean z) {
        this.can_post_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canEditMessages(boolean z) {
        this.can_edit_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatAdministratorRights canPinMessages(boolean z) {
        this.can_pin_messages = Boolean.valueOf(z);
        return this;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatAdministratorRights chatAdministratorRights = (ChatAdministratorRights) obj;
        if (!Objects.equals(this.is_anonymous, chatAdministratorRights.is_anonymous) || !Objects.equals(this.can_manage_chat, chatAdministratorRights.can_manage_chat) || !Objects.equals(this.can_delete_messages, chatAdministratorRights.can_delete_messages) || !Objects.equals(this.can_manage_video_chats, chatAdministratorRights.can_manage_video_chats) || !Objects.equals(this.can_restrict_members, chatAdministratorRights.can_restrict_members) || !Objects.equals(this.can_promote_members, chatAdministratorRights.can_promote_members) || !Objects.equals(this.can_change_info, chatAdministratorRights.can_change_info) || !Objects.equals(this.can_invite_users, chatAdministratorRights.can_invite_users) || !Objects.equals(this.can_post_messages, chatAdministratorRights.can_post_messages) || !Objects.equals(this.can_edit_messages, chatAdministratorRights.can_edit_messages) || !Objects.equals(this.can_pin_messages, chatAdministratorRights.can_pin_messages)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.is_anonymous, this.can_manage_chat, this.can_delete_messages, this.can_manage_video_chats, this.can_restrict_members, this.can_promote_members, this.can_change_info, this.can_invite_users, this.can_post_messages, this.can_edit_messages, this.can_pin_messages});
    }

    public String toString() {
        return "ChatAdministratorRights{is_anonymous=" + this.is_anonymous + ", can_manage_chat=" + this.can_manage_chat + ", can_delete_messages='" + this.can_delete_messages + '\'' + ", can_manage_video_chats=" + this.can_manage_video_chats + ", can_restrict_members=" + this.can_restrict_members + ", can_promote_members=" + this.can_promote_members + ", can_change_info=" + this.can_change_info + ", can_invite_users=" + this.can_invite_users + ", can_post_messages=" + this.can_post_messages + ", can_edit_messages=" + this.can_edit_messages + ", can_pin_messages=" + this.can_pin_messages + '}';
    }
}
