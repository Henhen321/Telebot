package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class MessageEntity implements Serializable {
    private static final long serialVersionUID = 0;
    private String custom_emoji_id;
    private String language;
    private Integer length;
    private Integer offset;
    private Type type;
    private String url;
    private User user;

    public enum Type {
        mention,
        hashtag,
        cashtag,
        bot_command,
        url,
        email,
        phone_number,
        bold,
        italic,
        code,
        pre,
        text_link,
        text_mention,
        underline,
        strikethrough,
        spoiler,
        custom_emoji
    }

    private MessageEntity() {
    }

    public MessageEntity(Type type2, Integer num, Integer num2) {
        this.type = type2;
        this.offset = num;
        this.length = num2;
    }

    public Type type() {
        return this.type;
    }

    public Integer offset() {
        return this.offset;
    }

    public Integer length() {
        return this.length;
    }

    public String url() {
        return this.url;
    }

    public User user() {
        return this.user;
    }

    public String language() {
        return this.language;
    }

    public String customEmojiId() {
        return this.custom_emoji_id;
    }

    public MessageEntity url(String str) {
        this.url = str;
        return this;
    }

    public MessageEntity user(User user2) {
        this.user = user2;
        return this;
    }

    public MessageEntity language(String str) {
        this.language = str;
        return this;
    }

    public MessageEntity customEmojiId(String str) {
        this.custom_emoji_id = str;
        return this;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        MessageEntity messageEntity = (MessageEntity) obj;
        if (this.type != messageEntity.type || !Objects.equals(this.offset, messageEntity.offset) || !Objects.equals(this.length, messageEntity.length) || !Objects.equals(this.url, messageEntity.url) || !Objects.equals(this.user, messageEntity.user) || !Objects.equals(this.language, messageEntity.language) || !Objects.equals(this.custom_emoji_id, messageEntity.custom_emoji_id)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.type, this.offset, this.length, this.url, this.user, this.language, this.custom_emoji_id});
    }

    public String toString() {
        return "MessageEntity{type=" + this.type + ", offset=" + this.offset + ", length=" + this.length + ", url='" + this.url + '\'' + ", user=" + this.user + ", language='" + this.language + '\'' + ", custom_emoji_id='" + this.custom_emoji_id + '\'' + '}';
    }
}
