package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class User implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean added_to_attachment_menu;
    private Boolean can_join_groups;
    private Boolean can_read_all_group_messages;
    private String first_name;
    private Long id;
    private Boolean is_bot;
    private Boolean is_premium;
    private String language_code;
    private String last_name;
    private Boolean supports_inline_queries;
    private String username;

    private User() {
    }

    public User(Long l) {
        this.id = l;
    }

    public Long id() {
        return this.id;
    }

    public Boolean isBot() {
        return this.is_bot;
    }

    public String firstName() {
        return this.first_name;
    }

    public String lastName() {
        return this.last_name;
    }

    public String username() {
        return this.username;
    }

    public String languageCode() {
        return this.language_code;
    }

    public Boolean isPremium() {
        Boolean bool = this.is_premium;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Boolean addedToAttachmentMenu() {
        Boolean bool = this.added_to_attachment_menu;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Boolean canJoinGroups() {
        return this.can_join_groups;
    }

    public Boolean canReadAllGroupMessages() {
        return this.can_read_all_group_messages;
    }

    public Boolean supportsInlineQueries() {
        return this.supports_inline_queries;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        User user = (User) obj;
        if (!Objects.equals(this.id, user.id) || !Objects.equals(this.is_bot, user.is_bot) || !Objects.equals(this.first_name, user.first_name) || !Objects.equals(this.last_name, user.last_name) || !Objects.equals(this.username, user.username) || !Objects.equals(this.language_code, user.language_code) || !Objects.equals(this.is_premium, user.is_premium) || !Objects.equals(this.added_to_attachment_menu, user.added_to_attachment_menu) || !Objects.equals(this.can_join_groups, user.can_join_groups) || !Objects.equals(this.can_read_all_group_messages, user.can_read_all_group_messages) || !Objects.equals(this.supports_inline_queries, user.supports_inline_queries)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        Long l = this.id;
        if (l != null) {
            return l.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "User{id=" + this.id + ", is_bot=" + this.is_bot + ", first_name='" + this.first_name + '\'' + ", last_name='" + this.last_name + '\'' + ", username='" + this.username + '\'' + ", language_code='" + this.language_code + '\'' + ", is_premium='" + this.is_premium + '\'' + ", added_to_attachment_menu='" + this.added_to_attachment_menu + '\'' + ", can_join_groups=" + this.can_join_groups + ", can_read_all_group_messages=" + this.can_read_all_group_messages + ", supports_inline_queries=" + this.supports_inline_queries + '}';
    }
}
