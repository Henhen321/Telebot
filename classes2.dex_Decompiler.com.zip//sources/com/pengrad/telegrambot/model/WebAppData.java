package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class WebAppData implements Serializable {
    private static final long serialVersionUID = 0;
    private String button_text;
    private String data;

    public String data() {
        return this.data;
    }

    public String buttonText() {
        return this.button_text;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        WebAppData webAppData = (WebAppData) obj;
        if (!Objects.equals(this.data, webAppData.data) || !Objects.equals(this.button_text, webAppData.button_text)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.data, this.button_text});
    }

    public String toString() {
        return "WebAppData{data=" + this.data + ", button_text=" + this.button_text + '}';
    }
}
