package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class MenuButtonCommands extends MenuButton implements Serializable {
    private static final long serialVersionUID = 0;

    public MenuButtonCommands() {
        super("commands");
    }
}
