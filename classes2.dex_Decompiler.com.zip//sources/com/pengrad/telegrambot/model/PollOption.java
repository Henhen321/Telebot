package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class PollOption implements Serializable {
    private static final long serialVersionUID = 0;
    private String text;
    private Integer voter_count;

    public String text() {
        return this.text;
    }

    public Integer voterCount() {
        return this.voter_count;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PollOption pollOption = (PollOption) obj;
        String str = this.text;
        if (str == null ? pollOption.text != null : !str.equals(pollOption.text)) {
            return false;
        }
        Integer num = this.voter_count;
        Integer num2 = pollOption.voter_count;
        if (num != null) {
            return num.equals(num2);
        }
        if (num2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.text;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Integer num = this.voter_count;
        if (num != null) {
            i = num.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "PollOption{text='" + this.text + '\'' + ", voter_count=" + this.voter_count + '}';
    }
}
