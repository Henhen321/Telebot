package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class MenuButton implements Serializable {
    private static final long serialVersionUID = 0;
    private String type;

    public MenuButton(String str) {
        this.type = str;
    }

    MenuButton() {
    }

    public String type() {
        return this.type;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.type, ((MenuButton) obj).type);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.type});
    }

    public String toString() {
        return "MenuButton{type='" + this.type + '\'' + '}';
    }
}
