package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Arrays;

public class Game implements Serializable {
    private static final long serialVersionUID = 0;
    private Animation animation;
    private String description;
    private PhotoSize[] photo;
    private String text;
    private MessageEntity[] text_entities;
    private String title;

    public String title() {
        return this.title;
    }

    public String description() {
        return this.description;
    }

    public PhotoSize[] photo() {
        return this.photo;
    }

    public String text() {
        return this.text;
    }

    public MessageEntity[] textEntities() {
        return this.text_entities;
    }

    public Animation animation() {
        return this.animation;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Game game = (Game) obj;
        String str = this.title;
        if (str == null ? game.title != null : !str.equals(game.title)) {
            return false;
        }
        String str2 = this.description;
        if (str2 == null ? game.description != null : !str2.equals(game.description)) {
            return false;
        }
        if (!Arrays.equals(this.photo, game.photo)) {
            return false;
        }
        String str3 = this.text;
        if (str3 == null ? game.text != null : !str3.equals(game.text)) {
            return false;
        }
        if (!Arrays.equals(this.text_entities, game.text_entities)) {
            return false;
        }
        Animation animation2 = this.animation;
        Animation animation3 = game.animation;
        if (animation2 != null) {
            return animation2.equals(animation3);
        }
        if (animation3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.title;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.description;
        int hashCode2 = (((hashCode + (str2 != null ? str2.hashCode() : 0)) * 31) + Arrays.hashCode(this.photo)) * 31;
        String str3 = this.text;
        int hashCode3 = (((hashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31) + Arrays.hashCode(this.text_entities)) * 31;
        Animation animation2 = this.animation;
        if (animation2 != null) {
            i = animation2.hashCode();
        }
        return hashCode3 + i;
    }

    public String toString() {
        return "Game{title='" + this.title + '\'' + ", description='" + this.description + '\'' + ", photo=" + Arrays.toString(this.photo) + ", text='" + this.text + '\'' + ", text_entities=" + Arrays.toString(this.text_entities) + ", animation=" + this.animation + '}';
    }
}
