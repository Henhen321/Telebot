package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Audio implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private String file_id;
    private String file_name;
    private Long file_size;
    private String file_unique_id;
    private String mime_type;
    private String performer;
    private PhotoSize thumb;
    private String title;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Integer duration() {
        return this.duration;
    }

    public String performer() {
        return this.performer;
    }

    public String title() {
        return this.title;
    }

    public String fileName() {
        return this.file_name;
    }

    public String mimeType() {
        return this.mime_type;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Audio audio = (Audio) obj;
        if (!Objects.equals(this.file_id, audio.file_id) || !Objects.equals(this.file_unique_id, audio.file_unique_id) || !Objects.equals(this.duration, audio.duration) || !Objects.equals(this.performer, audio.performer) || !Objects.equals(this.title, audio.title) || !Objects.equals(this.file_name, audio.file_name) || !Objects.equals(this.mime_type, audio.mime_type) || !Objects.equals(this.file_size, audio.file_size) || !Objects.equals(this.thumb, audio.thumb)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Audio{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", duration=" + this.duration + ", performer='" + this.performer + '\'' + ", title='" + this.title + '\'' + ", file_name='" + this.file_name + '\'' + ", mime_type='" + this.mime_type + '\'' + ", file_size=" + this.file_size + ", thumb=" + this.thumb + '}';
    }
}
