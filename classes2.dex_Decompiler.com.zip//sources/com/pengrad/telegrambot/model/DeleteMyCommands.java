package com.pengrad.telegrambot.model;

import com.pengrad.telegrambot.model.botcommandscope.BotCommandScope;
import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;

public class DeleteMyCommands extends BaseRequest<DeleteMyCommands, BaseResponse> {
    public DeleteMyCommands() {
        super(BaseResponse.class);
    }

    public DeleteMyCommands scope(BotCommandScope botCommandScope) {
        add("scope", botCommandScope);
        return this;
    }

    public DeleteMyCommands languageCode(String str) {
        add("language_code", str);
        return this;
    }
}
