package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ChatMemberUpdated implements Serializable {
    private static final long serialVersionUID = 0;
    private Chat chat;
    private Integer date;
    private User from;
    private ChatInviteLink invite_link;
    private ChatMember new_chat_member;
    private ChatMember old_chat_member;

    public Chat chat() {
        return this.chat;
    }

    public User from() {
        return this.from;
    }

    public Integer date() {
        return this.date;
    }

    public ChatMember oldChatMember() {
        return this.old_chat_member;
    }

    public ChatMember newChatMember() {
        return this.new_chat_member;
    }

    public ChatInviteLink inviteLink() {
        return this.invite_link;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatMemberUpdated chatMemberUpdated = (ChatMemberUpdated) obj;
        if (!Objects.equals(this.chat, chatMemberUpdated.chat) || !Objects.equals(this.from, chatMemberUpdated.from) || !Objects.equals(this.date, chatMemberUpdated.date) || !Objects.equals(this.old_chat_member, chatMemberUpdated.old_chat_member) || !Objects.equals(this.new_chat_member, chatMemberUpdated.new_chat_member) || !Objects.equals(this.invite_link, chatMemberUpdated.invite_link)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.chat, this.from, this.date, this.old_chat_member, this.new_chat_member, this.invite_link});
    }

    public String toString() {
        return "ChatMemberUpdated{chat=" + this.chat + ", from=" + this.from + ", date=" + this.date + ", old_chat_member=" + this.old_chat_member + ", new_chat_member=" + this.new_chat_member + ", invite_link=" + this.invite_link + '}';
    }
}
