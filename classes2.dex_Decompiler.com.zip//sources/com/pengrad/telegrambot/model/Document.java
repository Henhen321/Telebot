package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class Document implements Serializable {
    private static final long serialVersionUID = 0;
    private String file_id;
    private String file_name;
    private Long file_size;
    private String file_unique_id;
    private String mime_type;
    private PhotoSize thumb;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public String fileName() {
        return this.file_name;
    }

    public String mimeType() {
        return this.mime_type;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Document document = (Document) obj;
        String str = this.file_id;
        if (str == null ? document.file_id != null : !str.equals(document.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? document.file_unique_id != null : !str2.equals(document.file_unique_id)) {
            return false;
        }
        PhotoSize photoSize = this.thumb;
        if (photoSize == null ? document.thumb != null : !photoSize.equals(document.thumb)) {
            return false;
        }
        String str3 = this.file_name;
        if (str3 == null ? document.file_name != null : !str3.equals(document.file_name)) {
            return false;
        }
        String str4 = this.mime_type;
        if (str4 == null ? document.mime_type != null : !str4.equals(document.mime_type)) {
            return false;
        }
        Long l = this.file_size;
        Long l2 = document.file_size;
        if (l != null) {
            return l.equals(l2);
        }
        if (l2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Document{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", thumb=" + this.thumb + ", file_name='" + this.file_name + '\'' + ", mime_type='" + this.mime_type + '\'' + ", file_size=" + this.file_size + '}';
    }
}
