package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class CallbackQuery implements Serializable {
    private static final long serialVersionUID = 0;
    private String chat_instance;
    private String data;
    private User from;
    private String game_short_name;
    private String id;
    private String inline_message_id;
    private Message message;

    public String id() {
        return this.id;
    }

    public User from() {
        return this.from;
    }

    public Message message() {
        return this.message;
    }

    public String inlineMessageId() {
        return this.inline_message_id;
    }

    public String chatInstance() {
        return this.chat_instance;
    }

    public String data() {
        return this.data;
    }

    public String gameShortName() {
        return this.game_short_name;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        CallbackQuery callbackQuery = (CallbackQuery) obj;
        String str = this.id;
        if (str == null ? callbackQuery.id != null : !str.equals(callbackQuery.id)) {
            return false;
        }
        User user = this.from;
        if (user == null ? callbackQuery.from != null : !user.equals(callbackQuery.from)) {
            return false;
        }
        Message message2 = this.message;
        if (message2 == null ? callbackQuery.message != null : !message2.equals(callbackQuery.message)) {
            return false;
        }
        String str2 = this.inline_message_id;
        if (str2 == null ? callbackQuery.inline_message_id != null : !str2.equals(callbackQuery.inline_message_id)) {
            return false;
        }
        String str3 = this.chat_instance;
        if (str3 == null ? callbackQuery.chat_instance != null : !str3.equals(callbackQuery.chat_instance)) {
            return false;
        }
        String str4 = this.data;
        if (str4 == null ? callbackQuery.data != null : !str4.equals(callbackQuery.data)) {
            return false;
        }
        String str5 = this.game_short_name;
        String str6 = callbackQuery.game_short_name;
        if (str5 != null) {
            return str5.equals(str6);
        }
        if (str6 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "CallbackQuery{id='" + this.id + '\'' + ", from=" + this.from + ", message=" + this.message + ", inline_message_id='" + this.inline_message_id + '\'' + ", chat_instance='" + this.chat_instance + '\'' + ", data='" + this.data + '\'' + ", game_short_name='" + this.game_short_name + '\'' + '}';
    }
}
