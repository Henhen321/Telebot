package com.pengrad.telegrambot.model;

import com.pengrad.telegrambot.model.request.InlineKeyboardMarkup;
import com.pengrad.telegrambot.passport.PassportData;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

public class Message implements Serializable {
    private static final long serialVersionUID = 0;
    private Animation animation;
    private Audio audio;
    private String author_signature;
    private String caption;
    private MessageEntity[] caption_entities;
    private Boolean channel_chat_created;
    private Chat chat;
    private String connected_website;
    private Contact contact;
    private Integer date;
    private Boolean delete_chat_photo;
    private Dice dice;
    private Document document;
    private Integer edit_date;
    private MessageEntity[] entities;
    private Integer forward_date;
    private User forward_from;
    private Chat forward_from_chat;
    private Integer forward_from_message_id;
    private String forward_sender_name;
    private String forward_signature;
    private User from;
    private Game game;
    private Boolean group_chat_created;
    private Boolean has_protected_content;
    private Invoice invoice;
    private Boolean is_automatic_forward;
    private User left_chat_member;
    private Location location;
    private String media_group_id;
    private MessageAutoDeleteTimerChanged message_auto_delete_timer_changed;
    private Integer message_id;
    private Long migrate_from_chat_id;
    private Long migrate_to_chat_id;
    private User[] new_chat_members;
    private PhotoSize[] new_chat_photo;
    private String new_chat_title;
    private PassportData passport_data;
    private PhotoSize[] photo;
    private Message pinned_message;
    private Poll poll;
    private ProximityAlertTriggered proximity_alert_triggered;
    private InlineKeyboardMarkup reply_markup;
    private Message reply_to_message;
    private Chat sender_chat;
    private Sticker sticker;
    private SuccessfulPayment successful_payment;
    private Boolean supergroup_chat_created;
    private String text;
    private Venue venue;
    private User via_bot;
    private Video video;
    private VideoChatEnded video_chat_ended;
    private VideoChatParticipantsInvited video_chat_participants_invited;
    private VideoChatScheduled video_chat_scheduled;
    private VideoChatStarted video_chat_started;
    private VideoNote video_note;
    private Voice voice;
    private WebAppData web_app_data;

    public Integer messageId() {
        return this.message_id;
    }

    public User from() {
        return this.from;
    }

    public Chat senderChat() {
        return this.sender_chat;
    }

    public Integer date() {
        return this.date;
    }

    public Chat chat() {
        return this.chat;
    }

    public User forwardFrom() {
        return this.forward_from;
    }

    public Chat forwardFromChat() {
        return this.forward_from_chat;
    }

    public Integer forwardFromMessageId() {
        return this.forward_from_message_id;
    }

    public String forwardSignature() {
        return this.forward_signature;
    }

    public String forwardSenderName() {
        return this.forward_sender_name;
    }

    public Integer forwardDate() {
        return this.forward_date;
    }

    public Boolean isAutomaticForward() {
        return this.is_automatic_forward;
    }

    public Message replyToMessage() {
        return this.reply_to_message;
    }

    public User viaBot() {
        return this.via_bot;
    }

    public Integer editDate() {
        return this.edit_date;
    }

    public Boolean hasProtectedContent() {
        return this.has_protected_content;
    }

    public String mediaGroupId() {
        return this.media_group_id;
    }

    public String authorSignature() {
        return this.author_signature;
    }

    public String text() {
        return this.text;
    }

    public MessageEntity[] entities() {
        return this.entities;
    }

    public MessageEntity[] captionEntities() {
        return this.caption_entities;
    }

    public Audio audio() {
        return this.audio;
    }

    public Document document() {
        return this.document;
    }

    public Animation animation() {
        return this.animation;
    }

    public Game game() {
        return this.game;
    }

    public PhotoSize[] photo() {
        return this.photo;
    }

    public Sticker sticker() {
        return this.sticker;
    }

    public Video video() {
        return this.video;
    }

    public Voice voice() {
        return this.voice;
    }

    public VideoNote videoNote() {
        return this.video_note;
    }

    public String caption() {
        return this.caption;
    }

    public Contact contact() {
        return this.contact;
    }

    public Location location() {
        return this.location;
    }

    public Venue venue() {
        return this.venue;
    }

    public Poll poll() {
        return this.poll;
    }

    public Dice dice() {
        return this.dice;
    }

    public User[] newChatMembers() {
        return this.new_chat_members;
    }

    public User leftChatMember() {
        return this.left_chat_member;
    }

    public String newChatTitle() {
        return this.new_chat_title;
    }

    public PhotoSize[] newChatPhoto() {
        return this.new_chat_photo;
    }

    public Boolean deleteChatPhoto() {
        return this.delete_chat_photo;
    }

    public Boolean groupChatCreated() {
        return this.group_chat_created;
    }

    public Boolean supergroupChatCreated() {
        return this.supergroup_chat_created;
    }

    public Boolean channelChatCreated() {
        return this.channel_chat_created;
    }

    public MessageAutoDeleteTimerChanged messageAutoDeleteTimerChanged() {
        return this.message_auto_delete_timer_changed;
    }

    public Long migrateToChatId() {
        return this.migrate_to_chat_id;
    }

    public Long migrateFromChatId() {
        return this.migrate_from_chat_id;
    }

    public Message pinnedMessage() {
        return this.pinned_message;
    }

    public Invoice invoice() {
        return this.invoice;
    }

    public SuccessfulPayment successfulPayment() {
        return this.successful_payment;
    }

    public String connectedWebsite() {
        return this.connected_website;
    }

    public PassportData passportData() {
        return this.passport_data;
    }

    public ProximityAlertTriggered proximityAlertTriggered() {
        return this.proximity_alert_triggered;
    }

    public VideoChatStarted videoChatStarted() {
        return this.video_chat_started;
    }

    public VideoChatEnded videoChatEnded() {
        return this.video_chat_ended;
    }

    public VideoChatParticipantsInvited videoChatParticipantsInvited() {
        return this.video_chat_participants_invited;
    }

    public VideoChatScheduled videoChatScheduled() {
        return this.video_chat_scheduled;
    }

    public InlineKeyboardMarkup replyMarkup() {
        return this.reply_markup;
    }

    public WebAppData webAppData() {
        return this.web_app_data;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Message message = (Message) obj;
        if (!Objects.equals(this.message_id, message.message_id) || !Objects.equals(this.from, message.from) || !Objects.equals(this.sender_chat, message.sender_chat) || !Objects.equals(this.date, message.date) || !Objects.equals(this.chat, message.chat) || !Objects.equals(this.forward_from, message.forward_from) || !Objects.equals(this.forward_from_chat, message.forward_from_chat) || !Objects.equals(this.forward_from_message_id, message.forward_from_message_id) || !Objects.equals(this.forward_signature, message.forward_signature) || !Objects.equals(this.forward_sender_name, message.forward_sender_name) || !Objects.equals(this.forward_date, message.forward_date) || !Objects.equals(this.is_automatic_forward, message.is_automatic_forward) || !Objects.equals(this.reply_to_message, message.reply_to_message) || !Objects.equals(this.via_bot, message.via_bot) || !Objects.equals(this.edit_date, message.edit_date) || !Objects.equals(this.has_protected_content, message.has_protected_content) || !Objects.equals(this.media_group_id, message.media_group_id) || !Objects.equals(this.author_signature, message.author_signature) || !Objects.equals(this.text, message.text) || !Arrays.equals(this.entities, message.entities) || !Arrays.equals(this.caption_entities, message.caption_entities) || !Objects.equals(this.audio, message.audio) || !Objects.equals(this.document, message.document) || !Objects.equals(this.animation, message.animation) || !Objects.equals(this.game, message.game) || !Arrays.equals(this.photo, message.photo) || !Objects.equals(this.sticker, message.sticker) || !Objects.equals(this.video, message.video) || !Objects.equals(this.voice, message.voice) || !Objects.equals(this.video_note, message.video_note) || !Objects.equals(this.caption, message.caption) || !Objects.equals(this.contact, message.contact) || !Objects.equals(this.location, message.location) || !Objects.equals(this.venue, message.venue) || !Objects.equals(this.poll, message.poll) || !Objects.equals(this.dice, message.dice) || !Arrays.equals(this.new_chat_members, message.new_chat_members) || !Objects.equals(this.left_chat_member, message.left_chat_member) || !Objects.equals(this.new_chat_title, message.new_chat_title) || !Arrays.equals(this.new_chat_photo, message.new_chat_photo) || !Objects.equals(this.delete_chat_photo, message.delete_chat_photo) || !Objects.equals(this.group_chat_created, message.group_chat_created) || !Objects.equals(this.supergroup_chat_created, message.supergroup_chat_created) || !Objects.equals(this.channel_chat_created, message.channel_chat_created) || !Objects.equals(this.message_auto_delete_timer_changed, message.message_auto_delete_timer_changed) || !Objects.equals(this.migrate_to_chat_id, message.migrate_to_chat_id) || !Objects.equals(this.migrate_from_chat_id, message.migrate_from_chat_id) || !Objects.equals(this.pinned_message, message.pinned_message) || !Objects.equals(this.invoice, message.invoice) || !Objects.equals(this.successful_payment, message.successful_payment) || !Objects.equals(this.connected_website, message.connected_website) || !Objects.equals(this.passport_data, message.passport_data) || !Objects.equals(this.proximity_alert_triggered, message.proximity_alert_triggered) || !Objects.equals(this.video_chat_started, message.video_chat_started) || !Objects.equals(this.video_chat_ended, message.video_chat_ended) || !Objects.equals(this.video_chat_participants_invited, message.video_chat_participants_invited) || !Objects.equals(this.video_chat_scheduled, message.video_chat_scheduled) || !Objects.equals(this.reply_markup, message.reply_markup) || !Objects.equals(this.web_app_data, message.web_app_data)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        Integer num = this.message_id;
        if (num != null) {
            return num.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Message{message_id=" + this.message_id + ", from=" + this.from + ", sender_chat=" + this.sender_chat + ", date=" + this.date + ", chat=" + this.chat + ", forward_from=" + this.forward_from + ", forward_from_chat=" + this.forward_from_chat + ", forward_from_message_id=" + this.forward_from_message_id + ", forward_signature='" + this.forward_signature + '\'' + ", forward_sender_name='" + this.forward_sender_name + '\'' + ", forward_date=" + this.forward_date + ", is_automatic_forward=" + this.is_automatic_forward + ", reply_to_message=" + this.reply_to_message + ", via_bot=" + this.via_bot + ", edit_date=" + this.edit_date + ", has_protected_content=" + this.has_protected_content + ", media_group_id='" + this.media_group_id + '\'' + ", author_signature='" + this.author_signature + '\'' + ", text='" + this.text + '\'' + ", entities=" + Arrays.toString(this.entities) + ", caption_entities=" + Arrays.toString(this.caption_entities) + ", audio=" + this.audio + ", document=" + this.document + ", animation=" + this.animation + ", game=" + this.game + ", photo=" + Arrays.toString(this.photo) + ", sticker=" + this.sticker + ", video=" + this.video + ", voice=" + this.voice + ", video_note=" + this.video_note + ", caption='" + this.caption + '\'' + ", contact=" + this.contact + ", location=" + this.location + ", venue=" + this.venue + ", poll=" + this.poll + ", dice=" + this.dice + ", new_chat_members=" + Arrays.toString(this.new_chat_members) + ", left_chat_member=" + this.left_chat_member + ", new_chat_title='" + this.new_chat_title + '\'' + ", new_chat_photo=" + Arrays.toString(this.new_chat_photo) + ", delete_chat_photo=" + this.delete_chat_photo + ", group_chat_created=" + this.group_chat_created + ", supergroup_chat_created=" + this.supergroup_chat_created + ", channel_chat_created=" + this.channel_chat_created + ", message_auto_delete_timer_changed=" + this.message_auto_delete_timer_changed + ", migrate_to_chat_id=" + this.migrate_to_chat_id + ", migrate_from_chat_id=" + this.migrate_from_chat_id + ", pinned_message=" + this.pinned_message + ", invoice=" + this.invoice + ", successful_payment=" + this.successful_payment + ", connected_website='" + this.connected_website + '\'' + ", passport_data=" + this.passport_data + ", proximity_alert_triggered=" + this.proximity_alert_triggered + ", video_chat_started=" + this.video_chat_started + ", video_chat_ended=" + this.video_chat_ended + ", video_chat_participants_invited=" + this.video_chat_participants_invited + ", video_chat_scheduled=" + this.video_chat_scheduled + ", reply_markup=" + this.reply_markup + ", web_app_data=" + this.web_app_data + '}';
    }
}
