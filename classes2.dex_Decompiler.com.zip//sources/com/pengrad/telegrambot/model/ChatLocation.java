package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ChatLocation implements Serializable {
    private static final long serialVersionUID = 0;
    private String address;
    private Location location;

    public Location location() {
        return this.location;
    }

    public String address() {
        return this.address;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatLocation chatLocation = (ChatLocation) obj;
        if (!Objects.equals(this.location, chatLocation.location) || !Objects.equals(this.address, chatLocation.address)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.location, this.address});
    }

    public String toString() {
        return "ChatLocation{location=" + this.location + ", address='" + this.address + '\'' + '}';
    }
}
