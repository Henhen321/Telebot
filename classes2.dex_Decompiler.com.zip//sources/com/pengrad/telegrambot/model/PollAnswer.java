package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Arrays;

public class PollAnswer implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer[] option_ids;
    private String poll_id;
    private User user;

    public String pollId() {
        return this.poll_id;
    }

    public User user() {
        return this.user;
    }

    public Integer[] optionIds() {
        return this.option_ids;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PollAnswer pollAnswer = (PollAnswer) obj;
        String str = this.poll_id;
        if (str == null ? pollAnswer.poll_id != null : !str.equals(pollAnswer.poll_id)) {
            return false;
        }
        User user2 = this.user;
        if (user2 == null ? pollAnswer.user == null : user2.equals(pollAnswer.user)) {
            return Arrays.equals(this.option_ids, pollAnswer.option_ids);
        }
        return false;
    }

    public int hashCode() {
        String str = this.poll_id;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        User user2 = this.user;
        if (user2 != null) {
            i = user2.hashCode();
        }
        return ((hashCode + i) * 31) + Arrays.hashCode(this.option_ids);
    }

    public String toString() {
        return "PollAnswer{poll_id='" + this.poll_id + '\'' + ", user=" + this.user + ", option_ids=" + Arrays.toString(this.option_ids) + '}';
    }
}
