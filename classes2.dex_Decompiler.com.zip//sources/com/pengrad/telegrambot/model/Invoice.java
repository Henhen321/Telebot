package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class Invoice implements Serializable {
    private static final long serialVersionUID = 0;
    private String currency;
    private String description;
    private String start_parameter;
    private String title;
    private Integer total_amount;

    public String title() {
        return this.title;
    }

    public String description() {
        return this.description;
    }

    public String startParameter() {
        return this.start_parameter;
    }

    public String currency() {
        return this.currency;
    }

    public Integer totalAmount() {
        return this.total_amount;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Invoice invoice = (Invoice) obj;
        String str = this.title;
        if (str == null ? invoice.title != null : !str.equals(invoice.title)) {
            return false;
        }
        String str2 = this.description;
        if (str2 == null ? invoice.description != null : !str2.equals(invoice.description)) {
            return false;
        }
        String str3 = this.start_parameter;
        if (str3 == null ? invoice.start_parameter != null : !str3.equals(invoice.start_parameter)) {
            return false;
        }
        String str4 = this.currency;
        if (str4 == null ? invoice.currency != null : !str4.equals(invoice.currency)) {
            return false;
        }
        Integer num = this.total_amount;
        Integer num2 = invoice.total_amount;
        if (num != null) {
            return num.equals(num2);
        }
        if (num2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.title;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.description;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.start_parameter;
        int hashCode3 = (hashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31;
        String str4 = this.currency;
        int hashCode4 = (hashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31;
        Integer num = this.total_amount;
        if (num != null) {
            i = num.hashCode();
        }
        return hashCode4 + i;
    }

    public String toString() {
        return "Invoice{title='" + this.title + '\'' + ", description='" + this.description + '\'' + ", start_parameter='" + this.start_parameter + '\'' + ", currency='" + this.currency + '\'' + ", total_amount=" + this.total_amount + '}';
    }
}
