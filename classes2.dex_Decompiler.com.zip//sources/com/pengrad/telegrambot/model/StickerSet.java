package com.pengrad.telegrambot.model;

import com.pengrad.telegrambot.model.Sticker;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

public class StickerSet implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean contains_masks;
    private Boolean is_animated;
    private Boolean is_video;
    private String name;
    private Sticker.Type sticker_type;
    private Sticker[] stickers;
    private PhotoSize thumb;
    private String title;

    public String name() {
        return this.name;
    }

    public String title() {
        return this.title;
    }

    public Sticker.Type stickerType() {
        return this.sticker_type;
    }

    public Boolean isAnimated() {
        return this.is_animated;
    }

    @Deprecated
    public Boolean containsMasks() {
        return this.contains_masks;
    }

    public Sticker[] stickers() {
        return this.stickers;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public Boolean isVideo() {
        return this.is_video;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        StickerSet stickerSet = (StickerSet) obj;
        if (!Objects.equals(this.name, stickerSet.name) || !Objects.equals(this.title, stickerSet.title) || !Objects.equals(this.sticker_type, stickerSet.sticker_type) || !Objects.equals(this.is_animated, stickerSet.is_animated) || !Objects.equals(this.is_video, stickerSet.is_video) || !Objects.equals(this.contains_masks, stickerSet.contains_masks) || !Arrays.equals(this.stickers, stickerSet.stickers) || !Objects.equals(this.thumb, stickerSet.thumb)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return (Objects.hash(new Object[]{this.name, this.title, this.sticker_type, this.is_animated, this.is_video, this.thumb}) * 31) + Arrays.hashCode(this.stickers);
    }

    public String toString() {
        return "StickerSet{name='" + this.name + '\'' + ", title='" + this.title + '\'' + ", sticker_type='" + this.sticker_type + '\'' + ", is_animated=" + this.is_animated + ", is_video=" + this.is_video + ", contains_masks=" + this.contains_masks + ", stickers=" + Arrays.toString(this.stickers) + ", thumb=" + this.thumb + '}';
    }
}
