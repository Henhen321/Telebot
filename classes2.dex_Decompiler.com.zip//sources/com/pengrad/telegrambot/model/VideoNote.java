package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class VideoNote implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private String file_id;
    private Long file_size;
    private String file_unique_id;
    private Integer length;
    private PhotoSize thumb;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Integer length() {
        return this.length;
    }

    public Integer duration() {
        return this.duration;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        VideoNote videoNote = (VideoNote) obj;
        String str = this.file_id;
        if (str == null ? videoNote.file_id != null : !str.equals(videoNote.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? videoNote.file_unique_id != null : !str2.equals(videoNote.file_unique_id)) {
            return false;
        }
        Integer num = this.length;
        if (num == null ? videoNote.length != null : !num.equals(videoNote.length)) {
            return false;
        }
        Integer num2 = this.duration;
        if (num2 == null ? videoNote.duration != null : !num2.equals(videoNote.duration)) {
            return false;
        }
        PhotoSize photoSize = this.thumb;
        if (photoSize == null ? videoNote.thumb != null : !photoSize.equals(videoNote.thumb)) {
            return false;
        }
        Long l = this.file_size;
        Long l2 = videoNote.file_size;
        if (l != null) {
            return l.equals(l2);
        }
        if (l2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "VideoNote{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", length=" + this.length + ", duration=" + this.duration + ", thumb=" + this.thumb + ", file_size=" + this.file_size + '}';
    }
}
