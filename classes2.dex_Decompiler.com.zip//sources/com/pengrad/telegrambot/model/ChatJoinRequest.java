package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ChatJoinRequest implements Serializable {
    private static final long serialVersionUID = 0;
    private String bio;
    private Chat chat;
    private Integer date;
    private User from;
    private ChatInviteLink invite_link;

    public Chat chat() {
        return this.chat;
    }

    public User from() {
        return this.from;
    }

    public Integer date() {
        return this.date;
    }

    public String bio() {
        return this.bio;
    }

    public ChatInviteLink inviteLink() {
        return this.invite_link;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatJoinRequest chatJoinRequest = (ChatJoinRequest) obj;
        if (!Objects.equals(this.chat, chatJoinRequest.chat) || !Objects.equals(this.from, chatJoinRequest.from) || !Objects.equals(this.date, chatJoinRequest.date) || !Objects.equals(this.bio, chatJoinRequest.bio) || !Objects.equals(this.invite_link, chatJoinRequest.invite_link)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.chat, this.from, this.date, this.bio, this.invite_link});
    }

    public String toString() {
        return "ChatJoinRequest{chat=" + this.chat + ", from=" + this.from + ", date=" + this.date + ", bio=" + this.bio + ", invite_link=" + this.invite_link + '}';
    }
}
