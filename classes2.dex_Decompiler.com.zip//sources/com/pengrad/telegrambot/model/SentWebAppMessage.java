package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class SentWebAppMessage implements Serializable {
    private static final long serialVersionUID = 0;
    private String inline_message_id;

    public SentWebAppMessage() {
        this.inline_message_id = null;
    }

    public SentWebAppMessage(String str) {
        this.inline_message_id = str;
    }

    public String inlineMessageId() {
        return this.inline_message_id;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.inline_message_id, ((SentWebAppMessage) obj).inline_message_id);
    }

    public int hashCode() {
        String str = this.inline_message_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "SentWebAppMessage{inline_message_id='" + this.inline_message_id + '\'' + '}';
    }
}
