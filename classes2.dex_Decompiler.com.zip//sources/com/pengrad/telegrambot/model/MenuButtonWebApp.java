package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class MenuButtonWebApp extends MenuButton implements Serializable {
    private static final long serialVersionUID = 0;
    private String text;
    private WebAppInfo web_app;

    public MenuButtonWebApp(String str, WebAppInfo webAppInfo) {
        super("web_app");
        this.text = str;
        this.web_app = webAppInfo;
    }

    MenuButtonWebApp() {
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass() || !super.equals(obj)) {
            return false;
        }
        MenuButtonWebApp menuButtonWebApp = (MenuButtonWebApp) obj;
        if (!Objects.equals(this.text, menuButtonWebApp.text) || !Objects.equals(this.web_app, menuButtonWebApp.web_app)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{Integer.valueOf(super.hashCode()), this.text, this.web_app});
    }

    public String toString() {
        return "MenuButtonWebApp{text='" + this.text + '\'' + ", web_app=" + this.web_app + '}';
    }
}
