package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Venue implements Serializable {
    private static final long serialVersionUID = 0;
    private String address;
    private String foursquare_id;
    private String foursquare_type;
    private String google_place_id;
    private String google_place_type;
    private Location location;
    private String title;

    public Location location() {
        return this.location;
    }

    public String title() {
        return this.title;
    }

    public String address() {
        return this.address;
    }

    public String foursquareId() {
        return this.foursquare_id;
    }

    public String foursquareType() {
        return this.foursquare_type;
    }

    public String googlePlaceId() {
        return this.google_place_id;
    }

    public String googlePlaceType() {
        return this.google_place_type;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Venue venue = (Venue) obj;
        if (!Objects.equals(this.location, venue.location) || !Objects.equals(this.title, venue.title) || !Objects.equals(this.address, venue.address) || !Objects.equals(this.foursquare_id, venue.foursquare_id) || !Objects.equals(this.foursquare_type, venue.foursquare_type) || !Objects.equals(this.google_place_id, venue.google_place_id) || !Objects.equals(this.google_place_type, venue.google_place_type)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.location, this.title, this.address, this.foursquare_id, this.foursquare_type, this.google_place_id, this.google_place_type});
    }

    public String toString() {
        return "Venue{location=" + this.location + ", title='" + this.title + '\'' + ", address='" + this.address + '\'' + ", foursquare_id='" + this.foursquare_id + '\'' + ", foursquare_type='" + this.foursquare_type + '\'' + ", google_place_id='" + this.google_place_id + '\'' + ", google_place_type='" + this.google_place_type + '\'' + '}';
    }
}
