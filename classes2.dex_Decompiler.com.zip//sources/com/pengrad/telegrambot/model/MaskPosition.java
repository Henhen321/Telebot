package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class MaskPosition implements Serializable {
    private static final long serialVersionUID = 0;
    private String point;
    private Float scale;
    private Float x_shift;
    private Float y_shift;

    public enum Point {
        forehead,
        eyes,
        mouth,
        chin
    }

    public MaskPosition() {
    }

    public MaskPosition(Point point2, Float f, Float f2, Float f3) {
        this(point2.name(), f, f2, f3);
    }

    public MaskPosition(String str, Float f, Float f2, Float f3) {
        this.point = str;
        this.x_shift = f;
        this.y_shift = f2;
        this.scale = f3;
    }

    public String point() {
        return this.point;
    }

    public Float xShift() {
        return this.x_shift;
    }

    public Float yShift() {
        return this.y_shift;
    }

    public Float scale() {
        return this.scale;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        MaskPosition maskPosition = (MaskPosition) obj;
        String str = this.point;
        if (str == null ? maskPosition.point != null : !str.equals(maskPosition.point)) {
            return false;
        }
        Float f = this.x_shift;
        if (f == null ? maskPosition.x_shift != null : !f.equals(maskPosition.x_shift)) {
            return false;
        }
        Float f2 = this.y_shift;
        if (f2 == null ? maskPosition.y_shift != null : !f2.equals(maskPosition.y_shift)) {
            return false;
        }
        Float f3 = this.scale;
        Float f4 = maskPosition.scale;
        if (f3 != null) {
            return f3.equals(f4);
        }
        if (f4 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.point;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Float f = this.x_shift;
        int hashCode2 = (hashCode + (f != null ? f.hashCode() : 0)) * 31;
        Float f2 = this.y_shift;
        int hashCode3 = (hashCode2 + (f2 != null ? f2.hashCode() : 0)) * 31;
        Float f3 = this.scale;
        if (f3 != null) {
            i = f3.hashCode();
        }
        return hashCode3 + i;
    }

    public String toString() {
        return "MaskPosition{point='" + this.point + '\'' + ", x_shift=" + this.x_shift + ", y_shift=" + this.y_shift + ", scale=" + this.scale + '}';
    }
}
