package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class VideoChatParticipantsInvited implements Serializable {
    private static final long serialVersionUID = 0;
    private List<User> users;

    public List<User> users() {
        return this.users;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.users, ((VideoChatParticipantsInvited) obj).users);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.users});
    }

    public String toString() {
        return "VideoChatParticipantsInvited{users=" + this.users + '}';
    }
}
