package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class MenuButtonDefault extends MenuButton implements Serializable {
    private static final long serialVersionUID = 0;

    public MenuButtonDefault() {
        super("default");
    }
}
