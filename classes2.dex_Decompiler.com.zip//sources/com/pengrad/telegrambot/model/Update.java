package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Update implements Serializable {
    private static final long serialVersionUID = 0;
    private CallbackQuery callback_query;
    private Message channel_post;
    private ChatJoinRequest chat_join_request;
    private ChatMemberUpdated chat_member;
    private ChosenInlineResult chosen_inline_result;
    private Message edited_channel_post;
    private Message edited_message;
    private InlineQuery inline_query;
    private Message message;
    private ChatMemberUpdated my_chat_member;
    private Poll poll;
    private PollAnswer poll_answer;
    private PreCheckoutQuery pre_checkout_query;
    private ShippingQuery shipping_query;
    private Integer update_id;

    public Integer updateId() {
        return this.update_id;
    }

    public Message message() {
        return this.message;
    }

    public Message editedMessage() {
        return this.edited_message;
    }

    public Message channelPost() {
        return this.channel_post;
    }

    public Message editedChannelPost() {
        return this.edited_channel_post;
    }

    public InlineQuery inlineQuery() {
        return this.inline_query;
    }

    public ChosenInlineResult chosenInlineResult() {
        return this.chosen_inline_result;
    }

    public CallbackQuery callbackQuery() {
        return this.callback_query;
    }

    public ShippingQuery shippingQuery() {
        return this.shipping_query;
    }

    public PreCheckoutQuery preCheckoutQuery() {
        return this.pre_checkout_query;
    }

    public Poll poll() {
        return this.poll;
    }

    public PollAnswer pollAnswer() {
        return this.poll_answer;
    }

    public ChatMemberUpdated myChatMember() {
        return this.my_chat_member;
    }

    public ChatMemberUpdated chatMember() {
        return this.chat_member;
    }

    public ChatJoinRequest chatJoinRequest() {
        return this.chat_join_request;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Update update = (Update) obj;
        if (!Objects.equals(this.update_id, update.update_id) || !Objects.equals(this.message, update.message) || !Objects.equals(this.edited_message, update.edited_message) || !Objects.equals(this.channel_post, update.channel_post) || !Objects.equals(this.edited_channel_post, update.edited_channel_post) || !Objects.equals(this.inline_query, update.inline_query) || !Objects.equals(this.chosen_inline_result, update.chosen_inline_result) || !Objects.equals(this.callback_query, update.callback_query) || !Objects.equals(this.shipping_query, update.shipping_query) || !Objects.equals(this.pre_checkout_query, update.pre_checkout_query) || !Objects.equals(this.poll, update.poll) || !Objects.equals(this.poll_answer, update.poll_answer) || !Objects.equals(this.my_chat_member, update.my_chat_member) || !Objects.equals(this.chat_member, update.chat_member) || !Objects.equals(this.chat_join_request, update.chat_join_request)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        Integer num = this.update_id;
        if (num != null) {
            return num.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Update{update_id=" + this.update_id + ", message=" + this.message + ", edited_message=" + this.edited_message + ", channel_post=" + this.channel_post + ", edited_channel_post=" + this.edited_channel_post + ", inline_query=" + this.inline_query + ", chosen_inline_result=" + this.chosen_inline_result + ", callback_query=" + this.callback_query + ", shipping_query=" + this.shipping_query + ", pre_checkout_query=" + this.pre_checkout_query + ", poll=" + this.poll + ", poll_answer=" + this.poll_answer + ", my_chat_member=" + this.my_chat_member + ", chat_member=" + this.chat_member + ", chat_join_request=" + this.chat_join_request + '}';
    }
}
