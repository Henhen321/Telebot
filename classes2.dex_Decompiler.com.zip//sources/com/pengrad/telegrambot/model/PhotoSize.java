package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class PhotoSize implements Serializable {
    private static final long serialVersionUID = 0;
    private String file_id;
    private Long file_size;
    private String file_unique_id;
    private Integer height;
    private Integer width;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Integer width() {
        return this.width;
    }

    public Integer height() {
        return this.height;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PhotoSize photoSize = (PhotoSize) obj;
        String str = this.file_id;
        if (str == null ? photoSize.file_id != null : !str.equals(photoSize.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? photoSize.file_unique_id != null : !str2.equals(photoSize.file_unique_id)) {
            return false;
        }
        Integer num = this.width;
        if (num == null ? photoSize.width != null : !num.equals(photoSize.width)) {
            return false;
        }
        Integer num2 = this.height;
        if (num2 == null ? photoSize.height != null : !num2.equals(photoSize.height)) {
            return false;
        }
        Long l = this.file_size;
        Long l2 = photoSize.file_size;
        if (l != null) {
            return l.equals(l2);
        }
        if (l2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "PhotoSize{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", width=" + this.width + ", height=" + this.height + ", file_size=" + this.file_size + '}';
    }
}
