package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class ResponseParameters implements Serializable {
    private static final long serialVersionUID = 0;
    private Long migrate_to_chat_id;
    private Integer retry_after;

    public Long migrateToChatId() {
        return this.migrate_to_chat_id;
    }

    public Integer retryAfter() {
        return this.retry_after;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ResponseParameters responseParameters = (ResponseParameters) obj;
        Long l = this.migrate_to_chat_id;
        if (l == null ? responseParameters.migrate_to_chat_id != null : !l.equals(responseParameters.migrate_to_chat_id)) {
            return false;
        }
        Integer num = this.retry_after;
        Integer num2 = responseParameters.retry_after;
        if (num != null) {
            return num.equals(num2);
        }
        if (num2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Long l = this.migrate_to_chat_id;
        int i = 0;
        int hashCode = (l != null ? l.hashCode() : 0) * 31;
        Integer num = this.retry_after;
        if (num != null) {
            i = num.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "ResponseParameters{migrate_to_chat_id=" + this.migrate_to_chat_id + ", retry_after=" + this.retry_after + '}';
    }
}
