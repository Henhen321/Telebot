package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Chat implements Serializable {
    private static final long serialVersionUID = 0;
    private String bio;
    private Boolean can_set_sticker_set;
    private String description;
    private String first_name;
    private Boolean has_private_forwards;
    private Boolean has_protected_content;
    private Boolean has_restricted_voice_and_video_messages;
    private Long id;
    private String invite_link;
    private Boolean join_by_request;
    private Boolean join_to_send_messages;
    private String last_name;
    private Long linked_chat_id;
    private ChatLocation location;
    private Integer message_auto_delete_time;
    private ChatPermissions permissions;
    private ChatPhoto photo;
    private Message pinned_message;
    private Integer slow_mode_delay;
    private String sticker_set_name;
    private String title;
    private Type type;
    private String username;

    public enum Type {
        Private,
        group,
        supergroup,
        channel
    }

    public Long id() {
        return this.id;
    }

    public Type type() {
        return this.type;
    }

    public String firstName() {
        return this.first_name;
    }

    public String lastName() {
        return this.last_name;
    }

    public String username() {
        return this.username;
    }

    public String title() {
        return this.title;
    }

    public ChatPhoto photo() {
        return this.photo;
    }

    public String bio() {
        return this.bio;
    }

    public Boolean hasPrivateForwards() {
        Boolean bool = this.has_private_forwards;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Boolean hasRestrictedVoiceAndVideoMessages() {
        Boolean bool = this.has_restricted_voice_and_video_messages;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Boolean joinToSendMessages() {
        Boolean bool = this.join_to_send_messages;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Boolean joinByRequest() {
        Boolean bool = this.join_by_request;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public String description() {
        return this.description;
    }

    public String inviteLink() {
        return this.invite_link;
    }

    public Message pinnedMessage() {
        return this.pinned_message;
    }

    public ChatPermissions permissions() {
        return this.permissions;
    }

    public Integer slowModeDelay() {
        return this.slow_mode_delay;
    }

    public Integer messageAutoDeleteTime() {
        return this.message_auto_delete_time;
    }

    public Boolean hasProtectedContent() {
        Boolean bool = this.has_protected_content;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public String stickerSetName() {
        return this.sticker_set_name;
    }

    public Boolean canSetStickerSet() {
        Boolean bool = this.can_set_sticker_set;
        return Boolean.valueOf(bool != null && bool.booleanValue());
    }

    public Long linkedChatId() {
        return this.linked_chat_id;
    }

    public ChatLocation location() {
        return this.location;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Chat chat = (Chat) obj;
        if (!Objects.equals(this.id, chat.id) || this.type != chat.type || !Objects.equals(this.first_name, chat.first_name) || !Objects.equals(this.last_name, chat.last_name) || !Objects.equals(this.username, chat.username) || !Objects.equals(this.title, chat.title) || !Objects.equals(this.photo, chat.photo) || !Objects.equals(this.bio, chat.bio) || !Objects.equals(this.has_private_forwards, chat.has_private_forwards) || !Objects.equals(this.has_restricted_voice_and_video_messages, chat.has_restricted_voice_and_video_messages) || !Objects.equals(this.join_to_send_messages, chat.join_to_send_messages) || !Objects.equals(this.join_by_request, chat.join_by_request) || !Objects.equals(this.description, chat.description) || !Objects.equals(this.invite_link, chat.invite_link) || !Objects.equals(this.pinned_message, chat.pinned_message) || !Objects.equals(this.permissions, chat.permissions) || !Objects.equals(this.slow_mode_delay, chat.slow_mode_delay) || !Objects.equals(this.message_auto_delete_time, chat.message_auto_delete_time) || !Objects.equals(this.has_protected_content, chat.has_protected_content) || !Objects.equals(this.sticker_set_name, chat.sticker_set_name) || !Objects.equals(this.can_set_sticker_set, chat.can_set_sticker_set) || !Objects.equals(this.linked_chat_id, chat.linked_chat_id) || !Objects.equals(this.location, chat.location)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        Long l = this.id;
        if (l != null) {
            return l.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Chat{id=" + this.id + ", type=" + this.type + ", first_name='" + this.first_name + '\'' + ", last_name='" + this.last_name + '\'' + ", username='" + this.username + '\'' + ", title='" + this.title + '\'' + ", photo=" + this.photo + ", bio='" + this.bio + '\'' + ", has_private_forwards=" + this.has_private_forwards + ", has_restricted_voice_and_video_messages=" + this.has_restricted_voice_and_video_messages + ", join_to_send_messages=" + this.join_to_send_messages + ", join_by_request=" + this.join_by_request + ", description='" + this.description + '\'' + ", invite_link='" + this.invite_link + '\'' + ", pinned_message=" + this.pinned_message + ", permissions=" + this.permissions + ", slow_mode_delay=" + this.slow_mode_delay + ", message_auto_delete_time=" + this.message_auto_delete_time + ", has_protected_content=" + this.has_protected_content + ", sticker_set_name='" + this.sticker_set_name + '\'' + ", can_set_sticker_set=" + this.can_set_sticker_set + ", linked_chat_id=" + this.linked_chat_id + ", location=" + this.location + '}';
    }
}
