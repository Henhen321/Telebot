package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class InlineQuery implements Serializable {
    private static final long serialVersionUID = 0;
    private String chat_type;
    private User from;
    private String id;
    private Location location;
    private String offset;
    private String query;

    public String id() {
        return this.id;
    }

    public User from() {
        return this.from;
    }

    public Location location() {
        return this.location;
    }

    public String query() {
        return this.query;
    }

    public String offset() {
        return this.offset;
    }

    public String chatType() {
        return this.chat_type;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        InlineQuery inlineQuery = (InlineQuery) obj;
        String str = this.id;
        if (str == null ? inlineQuery.id != null : !str.equals(inlineQuery.id)) {
            return false;
        }
        User user = this.from;
        if (user == null ? inlineQuery.from != null : !user.equals(inlineQuery.from)) {
            return false;
        }
        Location location2 = this.location;
        if (location2 == null ? inlineQuery.location != null : !location2.equals(inlineQuery.location)) {
            return false;
        }
        String str2 = this.query;
        if (str2 == null ? inlineQuery.query != null : !str2.equals(inlineQuery.query)) {
            return false;
        }
        String str3 = this.chat_type;
        if (str3 == null ? inlineQuery.chat_type != null : !str3.equals(inlineQuery.chat_type)) {
            return false;
        }
        String str4 = this.offset;
        String str5 = inlineQuery.offset;
        if (str4 != null) {
            return str4.equals(str5);
        }
        if (str5 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "InlineQuery{id='" + this.id + '\'' + ", from=" + this.from + ", location=" + this.location + ", query='" + this.query + '\'' + ", offset='" + this.offset + '\'' + ", chat_type='" + this.chat_type + '\'' + '}';
    }
}
