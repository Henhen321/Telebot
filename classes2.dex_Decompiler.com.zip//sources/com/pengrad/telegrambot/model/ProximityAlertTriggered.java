package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ProximityAlertTriggered implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer distance;
    private User traveler;
    private User watcher;

    public User traveler() {
        return this.traveler;
    }

    public User watcher() {
        return this.watcher;
    }

    public Integer distance() {
        return this.distance;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ProximityAlertTriggered proximityAlertTriggered = (ProximityAlertTriggered) obj;
        if (!Objects.equals(this.traveler, proximityAlertTriggered.traveler) || !Objects.equals(this.watcher, proximityAlertTriggered.watcher) || !Objects.equals(this.distance, proximityAlertTriggered.distance)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.traveler, this.watcher, this.distance});
    }

    public String toString() {
        return "ProximityAlertTriggered{traveler=" + this.traveler + ", watcher=" + this.watcher + ", distance=" + this.distance + '}';
    }
}
