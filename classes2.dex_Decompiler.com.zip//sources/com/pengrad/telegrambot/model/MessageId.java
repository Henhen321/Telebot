package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class MessageId implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer message_id;

    public Integer messageId() {
        return this.message_id;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.message_id, ((MessageId) obj).message_id);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.message_id});
    }

    public String toString() {
        return "MessageId{message_id=" + this.message_id + '}';
    }
}
