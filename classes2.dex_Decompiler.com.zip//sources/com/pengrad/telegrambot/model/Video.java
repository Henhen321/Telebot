package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Video implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private String file_id;
    private String file_name;
    private Long file_size;
    private String file_unique_id;
    private Integer height;
    private String mime_type;
    private PhotoSize thumb;
    private Integer width;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Integer width() {
        return this.width;
    }

    public Integer height() {
        return this.height;
    }

    public Integer duration() {
        return this.duration;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public String fileName() {
        return this.file_name;
    }

    public String mimeType() {
        return this.mime_type;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Video video = (Video) obj;
        if (!Objects.equals(this.file_id, video.file_id) || !Objects.equals(this.file_unique_id, video.file_unique_id) || !Objects.equals(this.width, video.width) || !Objects.equals(this.height, video.height) || !Objects.equals(this.duration, video.duration) || !Objects.equals(this.thumb, video.thumb) || !Objects.equals(this.file_name, video.file_name) || !Objects.equals(this.mime_type, video.mime_type) || !Objects.equals(this.file_size, video.file_size)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Video{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", width=" + this.width + ", height=" + this.height + ", duration=" + this.duration + ", thumb=" + this.thumb + ", file_name='" + this.file_name + '\'' + ", mime_type='" + this.mime_type + '\'' + ", file_size=" + this.file_size + '}';
    }
}
