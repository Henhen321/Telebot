package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class VideoChatStarted implements Serializable {
    private static final long serialVersionUID = 0;

    public int hashCode() {
        return 1;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return obj != null && getClass() == obj.getClass();
    }
}
