package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class BotCommand implements Serializable {
    private static final long serialVersionUID = 0;
    private String command;
    private String description;

    public BotCommand(String str, String str2) {
        this.command = str;
        this.description = str2;
    }

    BotCommand() {
    }

    public String command() {
        return this.command;
    }

    public String description() {
        return this.description;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        BotCommand botCommand = (BotCommand) obj;
        String str = this.command;
        if (str == null ? botCommand.command != null : !str.equals(botCommand.command)) {
            return false;
        }
        String str2 = this.description;
        String str3 = botCommand.description;
        if (str2 != null) {
            return str2.equals(str3);
        }
        if (str3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.command;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.description;
        if (str2 != null) {
            i = str2.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "BotCommand{command='" + this.command + '\'' + ", description='" + this.description + '\'' + '}';
    }
}
