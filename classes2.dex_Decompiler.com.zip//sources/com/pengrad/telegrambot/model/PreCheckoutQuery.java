package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class PreCheckoutQuery implements Serializable {
    private static final long serialVersionUID = 0;
    private String currency;
    private User from;
    private String id;
    private String invoice_payload;
    private OrderInfo order_info;
    private String shipping_option_id;
    private Integer total_amount;

    public String id() {
        return this.id;
    }

    public User from() {
        return this.from;
    }

    public String currency() {
        return this.currency;
    }

    public Integer totalAmount() {
        return this.total_amount;
    }

    public String invoicePayload() {
        return this.invoice_payload;
    }

    public String shippingOptionId() {
        return this.shipping_option_id;
    }

    public OrderInfo orderInfo() {
        return this.order_info;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PreCheckoutQuery preCheckoutQuery = (PreCheckoutQuery) obj;
        String str = this.id;
        if (str == null ? preCheckoutQuery.id != null : !str.equals(preCheckoutQuery.id)) {
            return false;
        }
        User user = this.from;
        if (user == null ? preCheckoutQuery.from != null : !user.equals(preCheckoutQuery.from)) {
            return false;
        }
        String str2 = this.currency;
        if (str2 == null ? preCheckoutQuery.currency != null : !str2.equals(preCheckoutQuery.currency)) {
            return false;
        }
        Integer num = this.total_amount;
        if (num == null ? preCheckoutQuery.total_amount != null : !num.equals(preCheckoutQuery.total_amount)) {
            return false;
        }
        String str3 = this.invoice_payload;
        if (str3 == null ? preCheckoutQuery.invoice_payload != null : !str3.equals(preCheckoutQuery.invoice_payload)) {
            return false;
        }
        String str4 = this.shipping_option_id;
        if (str4 == null ? preCheckoutQuery.shipping_option_id != null : !str4.equals(preCheckoutQuery.shipping_option_id)) {
            return false;
        }
        OrderInfo orderInfo = this.order_info;
        OrderInfo orderInfo2 = preCheckoutQuery.order_info;
        if (orderInfo != null) {
            return orderInfo.equals(orderInfo2);
        }
        if (orderInfo2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "PreCheckoutQuery{id='" + this.id + '\'' + ", from=" + this.from + ", currency='" + this.currency + '\'' + ", total_amount=" + this.total_amount + ", invoice_payload='" + this.invoice_payload + '\'' + ", shipping_option_id='" + this.shipping_option_id + '\'' + ", order_info=" + this.order_info + '}';
    }
}
