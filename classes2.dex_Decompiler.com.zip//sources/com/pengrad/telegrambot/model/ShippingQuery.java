package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class ShippingQuery implements Serializable {
    private static final long serialVersionUID = 0;
    private User from;
    private String id;
    private String invoice_payload;
    private ShippingAddress shipping_address;

    public String id() {
        return this.id;
    }

    public User from() {
        return this.from;
    }

    public String invoicePayload() {
        return this.invoice_payload;
    }

    public ShippingAddress shippingAddress() {
        return this.shipping_address;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ShippingQuery shippingQuery = (ShippingQuery) obj;
        String str = this.id;
        if (str == null ? shippingQuery.id != null : !str.equals(shippingQuery.id)) {
            return false;
        }
        User user = this.from;
        if (user == null ? shippingQuery.from != null : !user.equals(shippingQuery.from)) {
            return false;
        }
        String str2 = this.invoice_payload;
        if (str2 == null ? shippingQuery.invoice_payload != null : !str2.equals(shippingQuery.invoice_payload)) {
            return false;
        }
        ShippingAddress shippingAddress = this.shipping_address;
        ShippingAddress shippingAddress2 = shippingQuery.shipping_address;
        if (shippingAddress != null) {
            return shippingAddress.equals(shippingAddress2);
        }
        if (shippingAddress2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "ShippingQuery{id='" + this.id + '\'' + ", from=" + this.from + ", invoice_payload='" + this.invoice_payload + '\'' + ", shipping_address=" + this.shipping_address + '}';
    }
}
