package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class SuccessfulPayment implements Serializable {
    private static final long serialVersionUID = 0;
    private String currency;
    private String invoice_payload;
    private OrderInfo order_info;
    private String provider_payment_charge_id;
    private String shipping_option_id;
    private String telegram_payment_charge_id;
    private Integer total_amount;

    public String currency() {
        return this.currency;
    }

    public Integer totalAmount() {
        return this.total_amount;
    }

    public String invoicePayload() {
        return this.invoice_payload;
    }

    public String shippingOptionId() {
        return this.shipping_option_id;
    }

    public OrderInfo orderInfo() {
        return this.order_info;
    }

    public String telegramPaymentChargeId() {
        return this.telegram_payment_charge_id;
    }

    public String providerPaymentChargeId() {
        return this.provider_payment_charge_id;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        SuccessfulPayment successfulPayment = (SuccessfulPayment) obj;
        String str = this.currency;
        if (str == null ? successfulPayment.currency != null : !str.equals(successfulPayment.currency)) {
            return false;
        }
        Integer num = this.total_amount;
        if (num == null ? successfulPayment.total_amount != null : !num.equals(successfulPayment.total_amount)) {
            return false;
        }
        String str2 = this.invoice_payload;
        if (str2 == null ? successfulPayment.invoice_payload != null : !str2.equals(successfulPayment.invoice_payload)) {
            return false;
        }
        String str3 = this.shipping_option_id;
        if (str3 == null ? successfulPayment.shipping_option_id != null : !str3.equals(successfulPayment.shipping_option_id)) {
            return false;
        }
        OrderInfo orderInfo = this.order_info;
        if (orderInfo == null ? successfulPayment.order_info != null : !orderInfo.equals(successfulPayment.order_info)) {
            return false;
        }
        String str4 = this.telegram_payment_charge_id;
        if (str4 == null ? successfulPayment.telegram_payment_charge_id != null : !str4.equals(successfulPayment.telegram_payment_charge_id)) {
            return false;
        }
        String str5 = this.provider_payment_charge_id;
        String str6 = successfulPayment.provider_payment_charge_id;
        if (str5 != null) {
            return str5.equals(str6);
        }
        if (str6 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.currency;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Integer num = this.total_amount;
        int hashCode2 = (hashCode + (num != null ? num.hashCode() : 0)) * 31;
        String str2 = this.invoice_payload;
        int hashCode3 = (hashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.shipping_option_id;
        int hashCode4 = (hashCode3 + (str3 != null ? str3.hashCode() : 0)) * 31;
        OrderInfo orderInfo = this.order_info;
        int hashCode5 = (hashCode4 + (orderInfo != null ? orderInfo.hashCode() : 0)) * 31;
        String str4 = this.telegram_payment_charge_id;
        int hashCode6 = (hashCode5 + (str4 != null ? str4.hashCode() : 0)) * 31;
        String str5 = this.provider_payment_charge_id;
        if (str5 != null) {
            i = str5.hashCode();
        }
        return hashCode6 + i;
    }

    public String toString() {
        return "SuccessfulPayment{currency='" + this.currency + '\'' + ", total_amount=" + this.total_amount + ", invoice_payload='" + this.invoice_payload + '\'' + ", shipping_option_id='" + this.shipping_option_id + '\'' + ", order_info=" + this.order_info + ", telegram_payment_charge_id='" + this.telegram_payment_charge_id + '\'' + ", provider_payment_charge_id='" + this.provider_payment_charge_id + '\'' + '}';
    }
}
