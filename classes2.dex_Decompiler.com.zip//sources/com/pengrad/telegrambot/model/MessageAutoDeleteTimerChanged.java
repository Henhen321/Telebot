package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class MessageAutoDeleteTimerChanged implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer message_auto_delete_time;

    public Integer messageAutoDeleteTime() {
        return this.message_auto_delete_time;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.message_auto_delete_time, ((MessageAutoDeleteTimerChanged) obj).message_auto_delete_time);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.message_auto_delete_time});
    }

    public String toString() {
        return "MessageAutoDeleteTimerChanged{message_auto_delete_time=" + this.message_auto_delete_time + '}';
    }
}
