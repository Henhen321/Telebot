package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedPhoto extends InlineQueryResult<InlineQueryResultCachedPhoto> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String description;
    private String parse_mode;
    private String photo_file_id;
    private String title;

    public InlineQueryResultCachedPhoto(String str, String str2) {
        super("photo", str);
        this.photo_file_id = str2;
    }

    public InlineQueryResultCachedPhoto title(String str) {
        this.title = str;
        return this;
    }

    public InlineQueryResultCachedPhoto description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultCachedPhoto caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedPhoto parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
