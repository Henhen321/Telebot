package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.request.ContentTypes;
import java.io.File;
import java.io.Serializable;

public class InputMediaDocument extends InputMedia<InputMediaDocument> implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean disable_content_type_detection;

    public String getContentType() {
        return ContentTypes.DOC_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return "file.txt";
    }

    public InputMediaDocument(String str) {
        super("document", str);
    }

    public InputMediaDocument(File file) {
        super("document", file);
    }

    public InputMediaDocument(byte[] bArr) {
        super("document", bArr);
    }

    public InputMediaDocument disableContentTypeDetection(boolean z) {
        this.disable_content_type_detection = Boolean.valueOf(z);
        return this;
    }
}
