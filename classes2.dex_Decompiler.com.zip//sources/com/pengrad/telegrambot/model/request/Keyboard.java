package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public abstract class Keyboard implements Serializable {
    private static final long serialVersionUID = 0;
}
