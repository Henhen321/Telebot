package com.pengrad.telegrambot.model.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ReplyKeyboardMarkup extends Keyboard implements Serializable {
    private static final long serialVersionUID = 0;
    private String input_field_placeholder;
    private final List<List<KeyboardButton>> keyboard;
    private boolean one_time_keyboard;
    private boolean resize_keyboard;
    private boolean selective;

    public ReplyKeyboardMarkup(String[][] strArr, boolean z, boolean z2, String str, boolean z3) {
        this.keyboard = new ArrayList();
        this.resize_keyboard = z;
        this.one_time_keyboard = z2;
        this.input_field_placeholder = str;
        this.selective = z3;
        for (String[] addRow : strArr) {
            addRow(addRow);
        }
    }

    public ReplyKeyboardMarkup(String[][] strArr, boolean z, boolean z2, boolean z3) {
        this(strArr, z, z2, (String) null, z3);
    }

    public ReplyKeyboardMarkup(String[]... strArr) {
        this(strArr, false, false, false);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public ReplyKeyboardMarkup(KeyboardButton[]... keyboardButtonArr) {
        this(new String[0][]);
        for (KeyboardButton[] addRow : keyboardButtonArr) {
            addRow(addRow);
        }
    }

    public ReplyKeyboardMarkup(String... strArr) {
        this(strArr);
    }

    public ReplyKeyboardMarkup(KeyboardButton... keyboardButtonArr) {
        this(keyboardButtonArr);
    }

    public ReplyKeyboardMarkup addRow(KeyboardButton... keyboardButtonArr) {
        this.keyboard.add(Arrays.asList(keyboardButtonArr));
        return this;
    }

    public ReplyKeyboardMarkup addRow(String... strArr) {
        ArrayList arrayList = new ArrayList();
        for (String keyboardButton : strArr) {
            arrayList.add(new KeyboardButton(keyboardButton));
        }
        this.keyboard.add(arrayList);
        return this;
    }

    public ReplyKeyboardMarkup resizeKeyboard(boolean z) {
        this.resize_keyboard = z;
        return this;
    }

    public ReplyKeyboardMarkup oneTimeKeyboard(boolean z) {
        this.one_time_keyboard = z;
        return this;
    }

    public ReplyKeyboardMarkup inputFieldPlaceholder(String str) {
        this.input_field_placeholder = str;
        return this;
    }

    public ReplyKeyboardMarkup selective(boolean z) {
        this.selective = z;
        return this;
    }
}
