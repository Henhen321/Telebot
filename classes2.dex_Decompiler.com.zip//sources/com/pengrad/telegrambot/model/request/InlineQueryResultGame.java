package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultGame extends InlineQueryResult<InlineQueryResultGame> implements Serializable {
    private static final long serialVersionUID = 0;
    private String game_short_name;

    public InlineQueryResultGame(String str, String str2) {
        super("game", str);
        this.game_short_name = str2;
    }
}
