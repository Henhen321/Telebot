package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedVoice extends InlineQueryResult<InlineQueryResultCachedVoice> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String parse_mode;
    private String title;
    private String voice_file_id;

    public InlineQueryResultCachedVoice(String str, String str2, String str3) {
        super("voice", str);
        this.voice_file_id = str2;
        this.title = str3;
    }

    public InlineQueryResultCachedVoice caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedVoice parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
