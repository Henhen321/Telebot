package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.model.MessageEntity;
import java.io.Serializable;

public class InputTextMessageContent extends InputMessageContent implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean disable_web_page_preview;
    private MessageEntity[] entities;
    private String message_text;
    private String parse_mode;

    public InputTextMessageContent(String str) {
        this.message_text = str;
    }

    public InputTextMessageContent parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }

    public InputTextMessageContent entities(MessageEntity... messageEntityArr) {
        this.entities = messageEntityArr;
        return this;
    }

    public InputTextMessageContent disableWebPagePreview(Boolean bool) {
        this.disable_web_page_preview = bool;
        return this;
    }
}
