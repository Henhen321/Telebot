package com.pengrad.telegrambot.model.request;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class InlineKeyboardMarkup extends Keyboard implements Serializable {
    private static final long serialVersionUID = 0;
    private final List<List<InlineKeyboardButton>> inline_keyboard;

    public InlineKeyboardMarkup() {
        this.inline_keyboard = new ArrayList();
    }

    public InlineKeyboardMarkup(InlineKeyboardButton[]... inlineKeyboardButtonArr) {
        this();
        for (InlineKeyboardButton[] addRow : inlineKeyboardButtonArr) {
            addRow(addRow);
        }
    }

    public InlineKeyboardMarkup(InlineKeyboardButton... inlineKeyboardButtonArr) {
        this(inlineKeyboardButtonArr);
    }

    public InlineKeyboardMarkup addRow(InlineKeyboardButton... inlineKeyboardButtonArr) {
        this.inline_keyboard.add(Arrays.asList(inlineKeyboardButtonArr));
        return this;
    }

    public InlineKeyboardButton[][] inlineKeyboard() {
        InlineKeyboardButton[][] inlineKeyboardButtonArr = new InlineKeyboardButton[this.inline_keyboard.size()][];
        for (int i = 0; i < this.inline_keyboard.size(); i++) {
            inlineKeyboardButtonArr[i] = (InlineKeyboardButton[]) this.inline_keyboard.get(i).toArray(new InlineKeyboardButton[0]);
        }
        return inlineKeyboardButtonArr;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.inline_keyboard, ((InlineKeyboardMarkup) obj).inline_keyboard);
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.inline_keyboard});
    }

    public String toString() {
        return "InlineKeyboardMarkup{inline_keyboard=" + this.inline_keyboard + '}';
    }
}
