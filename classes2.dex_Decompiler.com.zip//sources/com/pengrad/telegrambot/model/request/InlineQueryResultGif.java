package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultGif extends InlineQueryResult<InlineQueryResultGif> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private Integer gif_duration;
    private Integer gif_height;
    private String gif_url;
    private Integer gif_width;
    private String parse_mode;
    private String thumb_mime_type;
    private String thumb_url;
    private String title;

    public InlineQueryResultGif(String str, String str2, String str3) {
        super("gif", str);
        this.gif_url = str2;
        this.thumb_url = str3;
    }

    public InlineQueryResultGif gifWidth(Integer num) {
        this.gif_width = num;
        return this;
    }

    public InlineQueryResultGif gifHeight(Integer num) {
        this.gif_height = num;
        return this;
    }

    public InlineQueryResultGif gifDuration(Integer num) {
        this.gif_duration = num;
        return this;
    }

    public InlineQueryResultGif thumbMimeType(String str) {
        this.thumb_mime_type = str;
        return this;
    }

    public InlineQueryResultGif title(String str) {
        this.title = str;
        return this;
    }

    public InlineQueryResultGif caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultGif parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
