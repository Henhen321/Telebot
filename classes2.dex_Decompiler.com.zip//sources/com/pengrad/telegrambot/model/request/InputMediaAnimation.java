package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.request.ContentTypes;
import java.io.File;
import java.io.Serializable;

public class InputMediaAnimation extends InputMedia<InputMediaAnimation> implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private Integer height;
    private Integer width;

    public String getContentType() {
        return ContentTypes.GIF_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.GIF_FILE_NAME;
    }

    public InputMediaAnimation(String str) {
        super("animation", str);
    }

    public InputMediaAnimation(File file) {
        super("animation", file);
    }

    public InputMediaAnimation(byte[] bArr) {
        super("animation", bArr);
    }

    public InputMediaAnimation width(Integer num) {
        this.width = num;
        return this;
    }

    public InputMediaAnimation height(Integer num) {
        this.height = num;
        return this;
    }

    public InputMediaAnimation duration(Integer num) {
        this.duration = num;
        return this;
    }
}
