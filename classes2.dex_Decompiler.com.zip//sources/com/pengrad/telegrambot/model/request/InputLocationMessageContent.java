package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InputLocationMessageContent extends InputMessageContent implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer heading;
    private Float horizontal_accuracy;
    private Float latitude;
    private Integer live_period;
    private Float longitude;
    private Integer proximity_alert_radius;

    public InputLocationMessageContent(Float f, Float f2) {
        this.latitude = f;
        this.longitude = f2;
    }

    public InputLocationMessageContent horizontalAccuracy(float f) {
        this.horizontal_accuracy = Float.valueOf(f);
        return this;
    }

    public InputLocationMessageContent livePeriod(Integer num) {
        this.live_period = num;
        return this;
    }

    public InputLocationMessageContent heading(int i) {
        this.heading = Integer.valueOf(i);
        return this;
    }

    public InputLocationMessageContent proximityAlertRadius(int i) {
        this.proximity_alert_radius = Integer.valueOf(i);
        return this;
    }
}
