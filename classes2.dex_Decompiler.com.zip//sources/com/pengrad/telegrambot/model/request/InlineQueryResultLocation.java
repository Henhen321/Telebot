package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultLocation extends InlineQueryResult<InlineQueryResultLocation> implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer heading;
    private Float horizontal_accuracy;
    private float latitude;
    private Integer live_period;
    private float longitude;
    private Integer proximity_alert_radius;
    private Integer thumb_height;
    private String thumb_url;
    private Integer thumb_width;
    private String title;

    public InlineQueryResultLocation(String str, float f, float f2, String str2) {
        super("location", str);
        this.latitude = f;
        this.longitude = f2;
        this.title = str2;
    }

    public InlineQueryResultLocation horizontalAccuracy(float f) {
        this.horizontal_accuracy = Float.valueOf(f);
        return this;
    }

    public InlineQueryResultLocation livePeriod(Integer num) {
        this.live_period = num;
        return this;
    }

    public InlineQueryResultLocation heading(int i) {
        this.heading = Integer.valueOf(i);
        return this;
    }

    public InlineQueryResultLocation proximityAlertRadius(int i) {
        this.proximity_alert_radius = Integer.valueOf(i);
        return this;
    }

    public InlineQueryResultLocation thumbUrl(String str) {
        this.thumb_url = str;
        return this;
    }

    public InlineQueryResultLocation thumbWidth(Integer num) {
        this.thumb_width = num;
        return this;
    }

    public InlineQueryResultLocation thumbHeight(Integer num) {
        this.thumb_height = num;
        return this;
    }
}
