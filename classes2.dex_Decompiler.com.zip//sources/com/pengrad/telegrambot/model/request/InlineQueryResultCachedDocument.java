package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedDocument extends InlineQueryResult<InlineQueryResultCachedDocument> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String description;
    private String document_file_id;
    private String parse_mode;
    private String title;

    public InlineQueryResultCachedDocument(String str, String str2, String str3) {
        super("document", str);
        this.document_file_id = str2;
        this.title = str3;
    }

    public InlineQueryResultCachedDocument description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultCachedDocument caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedDocument parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
