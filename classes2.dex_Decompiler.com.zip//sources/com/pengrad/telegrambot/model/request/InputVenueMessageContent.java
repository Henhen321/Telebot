package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InputVenueMessageContent extends InputMessageContent implements Serializable {
    private static final long serialVersionUID = 0;
    private String address;
    private String foursquare_id;
    private String foursquare_type;
    private String google_place_id;
    private String google_place_type;
    private Float latitude;
    private Float longitude;
    private String title;

    public InputVenueMessageContent(Float f, Float f2, String str, String str2) {
        this.latitude = f;
        this.longitude = f2;
        this.title = str;
        this.address = str2;
    }

    public InputVenueMessageContent foursquareId(String str) {
        this.foursquare_id = str;
        return this;
    }

    public InputVenueMessageContent foursquareType(String str) {
        this.foursquare_type = str;
        return this;
    }

    public InputVenueMessageContent googlePlaceId(String str) {
        this.google_place_id = str;
        return this;
    }

    public InputVenueMessageContent googlePlaceType(String str) {
        this.google_place_type = str;
        return this;
    }
}
