package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultVenue extends InlineQueryResult<InlineQueryResultVenue> implements Serializable {
    private static final long serialVersionUID = 0;
    private String address;
    private String foursquare_id;
    private String foursquare_type;
    private String google_place_id;
    private String google_place_type;
    private float latitude;
    private float longitude;
    private Integer thumb_height;
    private String thumb_url;
    private Integer thumb_width;
    private String title;

    public InlineQueryResultVenue(String str, float f, float f2, String str2, String str3) {
        super("venue", str);
        this.latitude = f;
        this.longitude = f2;
        this.title = str2;
        this.address = str3;
    }

    public InlineQueryResultVenue foursquareId(String str) {
        this.foursquare_id = str;
        return this;
    }

    public InlineQueryResultVenue foursquareType(String str) {
        this.foursquare_type = str;
        return this;
    }

    public InlineQueryResultVenue googlePlaceId(String str) {
        this.google_place_id = str;
        return this;
    }

    public InlineQueryResultVenue googlePlaceType(String str) {
        this.google_place_type = str;
        return this;
    }

    public InlineQueryResultVenue thumbUrl(String str) {
        this.thumb_url = str;
        return this;
    }

    public InlineQueryResultVenue thumbWidth(Integer num) {
        this.thumb_width = num;
        return this;
    }

    public InlineQueryResultVenue thumbHeight(Integer num) {
        this.thumb_height = num;
        return this;
    }
}
