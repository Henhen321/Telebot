package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedSticker extends InlineQueryResult<InlineQueryResultCachedSticker> implements Serializable {
    private static final long serialVersionUID = 0;
    private String sticker_file_id;

    public InlineQueryResultCachedSticker(String str, String str2) {
        super("sticker", str);
        this.sticker_file_id = str2;
    }
}
