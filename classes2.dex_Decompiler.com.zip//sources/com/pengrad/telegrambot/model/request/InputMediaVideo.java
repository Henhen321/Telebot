package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.request.ContentTypes;
import java.io.File;
import java.io.Serializable;

public class InputMediaVideo extends InputMedia<InputMediaVideo> implements Serializable {
    private static final long serialVersionUID = 1;
    private Integer duration;
    private Integer height;
    private Boolean supports_streaming;
    private Integer width;

    public String getContentType() {
        return "video/mp4";
    }

    public String getDefaultFileName() {
        return ContentTypes.VIDEO_FILE_NAME;
    }

    public InputMediaVideo(String str) {
        super("video", str);
    }

    public InputMediaVideo(File file) {
        super("video", file);
    }

    public InputMediaVideo(byte[] bArr) {
        super("video", bArr);
    }

    public InputMediaVideo width(Integer num) {
        this.width = num;
        return this;
    }

    public InputMediaVideo height(Integer num) {
        this.height = num;
        return this;
    }

    public InputMediaVideo duration(Integer num) {
        this.duration = num;
        return this;
    }

    public InputMediaVideo supportsStreaming(boolean z) {
        this.supports_streaming = Boolean.valueOf(z);
        return this;
    }
}
