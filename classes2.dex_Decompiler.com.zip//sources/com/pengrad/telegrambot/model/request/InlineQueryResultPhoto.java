package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultPhoto extends InlineQueryResult<InlineQueryResultPhoto> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String description;
    private String parse_mode;
    private Integer photo_height;
    private String photo_url;
    private Integer photo_width;
    private String thumb_url;
    private String title;

    public InlineQueryResultPhoto(String str, String str2, String str3) {
        super("photo", str);
        this.photo_url = str2;
        this.thumb_url = str3;
    }

    public InlineQueryResultPhoto photoWidth(Integer num) {
        this.photo_width = num;
        return this;
    }

    public InlineQueryResultPhoto photoHeight(Integer num) {
        this.photo_height = num;
        return this;
    }

    public InlineQueryResultPhoto title(String str) {
        this.title = str;
        return this;
    }

    public InlineQueryResultPhoto description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultPhoto caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultPhoto parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
