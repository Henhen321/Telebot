package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public abstract class InputMessageContent implements Serializable {
    private static final long serialVersionUID = 0;
}
