package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.model.WebAppInfo;
import java.io.Serializable;

public class KeyboardButton implements Serializable {
    private static final long serialVersionUID = 0;
    private boolean request_contact;
    private boolean request_location;
    private KeyboardButtonPollType request_poll;
    private String text;
    private WebAppInfo web_app;

    public KeyboardButton(String str) {
        this.text = str;
    }

    public KeyboardButton requestLocation(boolean z) {
        this.request_location = z;
        return this;
    }

    public KeyboardButton requestContact(boolean z) {
        this.request_contact = z;
        return this;
    }

    public KeyboardButton requestPoll(KeyboardButtonPollType keyboardButtonPollType) {
        this.request_poll = keyboardButtonPollType;
        return this;
    }

    public KeyboardButton webAppInfo(WebAppInfo webAppInfo) {
        this.web_app = webAppInfo;
        return this;
    }
}
