package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultArticle extends InlineQueryResult<InlineQueryResultArticle> implements Serializable {
    private static final long serialVersionUID = 0;
    private String description;
    private Boolean hide_url;
    private Integer thumb_height;
    private String thumb_url;
    private Integer thumb_width;
    private String title;
    private String url;

    public InlineQueryResultArticle(String str, String str2, String str3) {
        this(str, str2, (InputMessageContent) new InputTextMessageContent(str3));
    }

    public InlineQueryResultArticle(String str, String str2, InputMessageContent inputMessageContent) {
        super("article", str);
        this.title = str2;
        inputMessageContent(inputMessageContent);
    }

    public InlineQueryResultArticle url(String str) {
        this.url = str;
        return this;
    }

    public InlineQueryResultArticle hideUrl(Boolean bool) {
        this.hide_url = bool;
        return this;
    }

    public InlineQueryResultArticle description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultArticle thumbUrl(String str) {
        this.thumb_url = str;
        return this;
    }

    public InlineQueryResultArticle thumbWidth(Integer num) {
        this.thumb_width = num;
        return this;
    }

    public InlineQueryResultArticle thumbHeight(Integer num) {
        this.thumb_height = num;
        return this;
    }
}
