package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultDocument extends InlineQueryResult<InlineQueryResultDocument> implements Serializable {
    public static final String MIME_APP_PDFL = "application/pdf";
    public static final String MIME_APP_ZIP = "application/zip";
    private static final long serialVersionUID = 0;
    private String caption;
    private String description;
    private String document_url;
    private String mime_type;
    private String parse_mode;
    private Integer thumb_height;
    private String thumb_url;
    private Integer thumb_width;
    private String title;

    public InlineQueryResultDocument(String str, String str2, String str3, String str4) {
        super("document", str);
        this.document_url = str2;
        this.title = str3;
        this.mime_type = str4;
    }

    public InlineQueryResultDocument caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultDocument parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }

    public InlineQueryResultDocument description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultDocument thumbUrl(String str) {
        this.thumb_url = str;
        return this;
    }

    public InlineQueryResultDocument thumbWidth(Integer num) {
        this.thumb_width = num;
        return this;
    }

    public InlineQueryResultDocument thumbHeight(Integer num) {
        this.thumb_height = num;
        return this;
    }
}
