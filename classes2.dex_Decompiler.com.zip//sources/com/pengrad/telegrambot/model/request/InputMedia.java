package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.AttachName;
import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.InputMedia;
import java.io.File;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public abstract class InputMedia<T extends InputMedia<T>> implements Serializable {
    private static final long serialVersionUID = 0;
    private transient Map<String, Object> attachments = new HashMap();
    private String caption;
    private MessageEntity[] caption_entities;
    private transient String filename;
    private final String media;
    private String parse_mode;
    private final T thisAsT = this;
    private String thumb;
    private final String type;

    public abstract String getContentType();

    /* access modifiers changed from: protected */
    public abstract String getDefaultFileName();

    InputMedia(String str, Object obj) {
        this.type = str;
        if (obj instanceof String) {
            this.media = (String) obj;
            return;
        }
        String next = AttachName.next();
        this.media = "attach://" + next;
        this.attachments.put(next, obj);
        if (obj instanceof File) {
            this.filename = ((File) obj).getName();
        }
    }

    public Map<String, Object> getAttachments() {
        return this.attachments;
    }

    public T thumb(File file) {
        String next = AttachName.next();
        this.attachments.put(next, file);
        this.thumb = "attach://" + next;
        return this.thisAsT;
    }

    public T thumb(byte[] bArr) {
        String next = AttachName.next();
        this.attachments.put(next, bArr);
        this.thumb = "attach://" + next;
        return this.thisAsT;
    }

    public T caption(String str) {
        this.caption = str;
        return this.thisAsT;
    }

    public T parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this.thisAsT;
    }

    public T captionEntities(MessageEntity... messageEntityArr) {
        this.caption_entities = messageEntityArr;
        return this.thisAsT;
    }

    public String getFileName() {
        String str = this.filename;
        return str != null ? str : getDefaultFileName();
    }
}
