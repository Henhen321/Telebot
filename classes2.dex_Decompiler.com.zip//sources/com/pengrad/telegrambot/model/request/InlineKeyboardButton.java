package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.model.WebAppInfo;
import java.io.Serializable;
import java.util.Objects;

public class InlineKeyboardButton implements Serializable {
    private static final long serialVersionUID = 0;
    private String callback_data;
    private CallbackGame callback_game;
    private LoginUrl login_url;
    private Boolean pay;
    private String switch_inline_query;
    private String switch_inline_query_current_chat;
    private String text;
    private String url;
    private WebAppInfo web_app;

    private InlineKeyboardButton() {
    }

    public InlineKeyboardButton(String str) {
        this.text = str;
    }

    public InlineKeyboardButton url(String str) {
        this.url = str;
        return this;
    }

    public InlineKeyboardButton loginUrl(LoginUrl loginUrl) {
        this.login_url = loginUrl;
        return this;
    }

    public InlineKeyboardButton callbackData(String str) {
        this.callback_data = str;
        return this;
    }

    public InlineKeyboardButton switchInlineQuery(String str) {
        this.switch_inline_query = str;
        return this;
    }

    public InlineKeyboardButton switchInlineQueryCurrentChat(String str) {
        this.switch_inline_query_current_chat = str;
        return this;
    }

    public InlineKeyboardButton callbackGame(String str) {
        this.callback_game = new CallbackGame();
        return this;
    }

    public InlineKeyboardButton pay() {
        this.pay = true;
        return this;
    }

    public InlineKeyboardButton webApp(WebAppInfo webAppInfo) {
        this.web_app = webAppInfo;
        return this;
    }

    public String text() {
        return this.text;
    }

    public String url() {
        return this.url;
    }

    public String callbackData() {
        return this.callback_data;
    }

    public String switchInlineQuery() {
        return this.switch_inline_query;
    }

    public String switchInlineQueryCurrentChat() {
        return this.switch_inline_query_current_chat;
    }

    public CallbackGame callbackGame() {
        return this.callback_game;
    }

    public boolean isPay() {
        Boolean bool = this.pay;
        if (bool != null) {
            return bool.booleanValue();
        }
        return false;
    }

    public WebAppInfo webApp() {
        return this.web_app;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        InlineKeyboardButton inlineKeyboardButton = (InlineKeyboardButton) obj;
        if (!Objects.equals(this.text, inlineKeyboardButton.text) || !Objects.equals(this.url, inlineKeyboardButton.url) || !Objects.equals(this.login_url, inlineKeyboardButton.login_url) || !Objects.equals(this.callback_data, inlineKeyboardButton.callback_data) || !Objects.equals(this.switch_inline_query, inlineKeyboardButton.switch_inline_query) || !Objects.equals(this.switch_inline_query_current_chat, inlineKeyboardButton.switch_inline_query_current_chat) || !Objects.equals(this.callback_game, inlineKeyboardButton.callback_game) || !Objects.equals(this.pay, inlineKeyboardButton.pay) || !Objects.equals(this.web_app, inlineKeyboardButton.web_app)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.text, this.url, this.login_url, this.callback_data, this.switch_inline_query, this.switch_inline_query_current_chat, this.callback_game, this.pay, this.web_app});
    }

    public String toString() {
        return "InlineKeyboardButton{text='" + this.text + '\'' + ", url='" + this.url + '\'' + ", login_url=" + this.login_url + ", callback_data='" + this.callback_data + '\'' + ", switch_inline_query='" + this.switch_inline_query + '\'' + ", switch_inline_query_current_chat='" + this.switch_inline_query_current_chat + '\'' + ", callback_game=" + this.callback_game + ", pay=" + this.pay + ", web_app=" + this.web_app + '}';
    }
}
