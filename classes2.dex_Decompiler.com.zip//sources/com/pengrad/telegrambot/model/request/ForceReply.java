package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class ForceReply extends Keyboard implements Serializable {
    private static final long serialVersionUID = 0;
    private final boolean force_reply;
    private String input_field_placeholder;
    private boolean selective;

    public ForceReply() {
        this(false);
    }

    public ForceReply(boolean z) {
        this.force_reply = true;
        this.selective = z;
    }

    public ForceReply inputFieldPlaceholder(String str) {
        this.input_field_placeholder = str;
        return this;
    }

    public ForceReply selective(boolean z) {
        this.selective = z;
        return this;
    }
}
