package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.request.ContentTypes;
import java.io.File;
import java.io.Serializable;

public class InputMediaPhoto extends InputMedia<InputMediaPhoto> implements Serializable {
    private static final long serialVersionUID = 1;

    public String getContentType() {
        return ContentTypes.PHOTO_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.PHOTO_FILE_NAME;
    }

    public InputMediaPhoto(String str) {
        super("photo", str);
    }

    public InputMediaPhoto(File file) {
        super("photo", file);
    }

    public InputMediaPhoto(byte[] bArr) {
        super("photo", bArr);
    }
}
