package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultAudio extends InlineQueryResult<InlineQueryResultAudio> implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer audio_duration;
    private String audio_url;
    private String caption;
    private String parse_mode;
    private String performer;
    private String title;

    public InlineQueryResultAudio(String str, String str2, String str3) {
        super("audio", str);
        this.audio_url = str2;
        this.title = str3;
    }

    public InlineQueryResultAudio caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultAudio parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }

    public InlineQueryResultAudio performer(String str) {
        this.performer = str;
        return this;
    }

    public InlineQueryResultAudio audioDuration(Integer num) {
        this.audio_duration = num;
        return this;
    }
}
