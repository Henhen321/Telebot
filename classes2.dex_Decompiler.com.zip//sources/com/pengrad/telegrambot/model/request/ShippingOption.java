package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class ShippingOption implements Serializable {
    private static final long serialVersionUID = 0;
    private String id;
    private LabeledPrice[] prices;
    private String title;

    public ShippingOption(String str, String str2, LabeledPrice... labeledPriceArr) {
        this.id = str;
        this.title = str2;
        this.prices = labeledPriceArr;
    }
}
