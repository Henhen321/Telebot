package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InputContactMessageContent extends InputMessageContent implements Serializable {
    private static final long serialVersionUID = 0;
    private String first_name;
    private String last_name;
    private String phone_number;
    private String vcard;

    public InputContactMessageContent(String str, String str2) {
        this.phone_number = str;
        this.first_name = str2;
    }

    public InputContactMessageContent lastName(String str) {
        this.last_name = str;
        return this;
    }

    public InputContactMessageContent vcard(String str) {
        this.vcard = str;
        return this;
    }
}
