package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class LabeledPrice implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer amount;
    private String label;

    public LabeledPrice(String str, Integer num) {
        this.label = str;
        this.amount = num;
    }
}
