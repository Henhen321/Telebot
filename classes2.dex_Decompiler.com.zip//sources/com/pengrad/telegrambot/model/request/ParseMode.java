package com.pengrad.telegrambot.model.request;

public enum ParseMode {
    Markdown,
    MarkdownV2,
    HTML
}
