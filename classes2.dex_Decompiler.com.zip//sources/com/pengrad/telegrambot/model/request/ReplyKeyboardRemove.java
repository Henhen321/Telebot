package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class ReplyKeyboardRemove extends Keyboard implements Serializable {
    private static final long serialVersionUID = 0;
    private final boolean remove_keyboard;
    private final boolean selective;

    public ReplyKeyboardRemove() {
        this(false);
    }

    public ReplyKeyboardRemove(boolean z) {
        this.remove_keyboard = true;
        this.selective = z;
    }
}
