package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedGif extends InlineQueryResult<InlineQueryResultCachedGif> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String gif_file_id;
    private String parse_mode;
    private String title;

    public InlineQueryResultCachedGif(String str, String str2) {
        super("gif", str);
        this.gif_file_id = str2;
    }

    public InlineQueryResultCachedGif title(String str) {
        this.title = str;
        return this;
    }

    public InlineQueryResultCachedGif caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedGif parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
