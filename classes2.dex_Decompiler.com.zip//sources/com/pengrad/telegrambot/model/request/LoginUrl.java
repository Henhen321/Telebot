package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class LoginUrl implements Serializable {
    private static final long serialVersionUID = 0;
    private String bot_username;
    private String forward_text;
    private Boolean request_write_access;
    private String url;

    public LoginUrl(String str) {
        this.url = str;
    }

    public LoginUrl forwardText(String str) {
        this.forward_text = str;
        return this;
    }

    public LoginUrl botUsername(String str) {
        this.bot_username = str;
        return this;
    }

    public LoginUrl requestWriteAccess(boolean z) {
        this.request_write_access = Boolean.valueOf(z);
        return this;
    }
}
