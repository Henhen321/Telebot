package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedAudio extends InlineQueryResult<InlineQueryResultCachedAudio> implements Serializable {
    private static final long serialVersionUID = 0;
    private String audio_file_id;
    private String caption;
    private String parse_mode;

    public InlineQueryResultCachedAudio(String str, String str2) {
        super("audio", str);
        this.audio_file_id = str2;
    }

    public InlineQueryResultCachedAudio caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedAudio parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
