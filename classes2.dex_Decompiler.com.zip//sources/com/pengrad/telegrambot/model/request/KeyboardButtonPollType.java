package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.model.Poll;
import java.io.Serializable;

public class KeyboardButtonPollType implements Serializable {
    private static final long serialVersionUID = 0;
    private String type;

    public KeyboardButtonPollType() {
    }

    public KeyboardButtonPollType(String str) {
        this.type = str;
    }

    public KeyboardButtonPollType(Poll.Type type2) {
        this(type2.name());
    }
}
