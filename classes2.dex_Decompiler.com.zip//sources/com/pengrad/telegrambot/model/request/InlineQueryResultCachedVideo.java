package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultCachedVideo extends InlineQueryResult<InlineQueryResultCachedVideo> implements Serializable {
    private static final long serialVersionUID = 0;
    private String caption;
    private String description;
    private String parse_mode;
    private String title;
    private String video_file_id;

    public InlineQueryResultCachedVideo(String str, String str2, String str3) {
        super("video", str);
        this.video_file_id = str2;
        this.title = str3;
    }

    public InlineQueryResultCachedVideo description(String str) {
        this.description = str;
        return this;
    }

    public InlineQueryResultCachedVideo caption(String str) {
        this.caption = str;
        return this;
    }

    public InlineQueryResultCachedVideo parseMode(ParseMode parseMode) {
        this.parse_mode = parseMode.name();
        return this;
    }
}
