package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.request.ContentTypes;
import java.io.File;
import java.io.Serializable;

public class InputMediaAudio extends InputMedia<InputMediaAudio> implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private String performer;
    private String title;

    public String getContentType() {
        return ContentTypes.AUDIO_MIME_TYPE;
    }

    public String getDefaultFileName() {
        return ContentTypes.AUDIO_FILE_NAME;
    }

    public InputMediaAudio(String str) {
        super("audio", str);
    }

    public InputMediaAudio(File file) {
        super("audio", file);
    }

    public InputMediaAudio(byte[] bArr) {
        super("audio", bArr);
    }

    public InputMediaAudio duration(Integer num) {
        this.duration = num;
        return this;
    }

    public InputMediaAudio performer(String str) {
        this.performer = str;
        return this;
    }

    public InputMediaAudio title(String str) {
        this.title = str;
        return this;
    }
}
