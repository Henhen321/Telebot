package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

public class InlineQueryResultContact extends InlineQueryResult<InlineQueryResultContact> implements Serializable {
    private static final long serialVersionUID = 0;
    private String first_name;
    private String last_name;
    private String phone_number;
    private Integer thumb_height;
    private String thumb_url;
    private Integer thumb_width;
    private String vcard;

    public InlineQueryResultContact(String str, String str2, String str3) {
        super("contact", str);
        this.phone_number = str2;
        this.first_name = str3;
    }

    public InlineQueryResultContact lastName(String str) {
        this.last_name = str;
        return this;
    }

    public InlineQueryResultContact vcard(String str) {
        this.vcard = str;
        return this;
    }

    public InlineQueryResultContact thumbUrl(String str) {
        this.thumb_url = str;
        return this;
    }

    public InlineQueryResultContact thumbWidth(Integer num) {
        this.thumb_width = num;
        return this;
    }

    public InlineQueryResultContact thumbHeight(Integer num) {
        this.thumb_height = num;
        return this;
    }
}
