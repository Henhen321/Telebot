package com.pengrad.telegrambot.model.request;

import com.pengrad.telegrambot.model.MessageEntity;
import com.pengrad.telegrambot.model.request.InlineQueryResult;
import java.io.Serializable;

public abstract class InlineQueryResult<T extends InlineQueryResult<T>> implements Serializable {
    private static final long serialVersionUID = 0;
    private MessageEntity[] caption_entities;
    private String id;
    private InputMessageContent input_message_content;
    private InlineKeyboardMarkup reply_markup;
    private final T thisAsT = this;
    private String type;

    public InlineQueryResult(String str, String str2) {
        this.type = str;
        this.id = str2;
    }

    public T captionEntities(MessageEntity... messageEntityArr) {
        this.caption_entities = messageEntityArr;
        return this.thisAsT;
    }

    public T inputMessageContent(InputMessageContent inputMessageContent) {
        this.input_message_content = inputMessageContent;
        return this.thisAsT;
    }

    public T replyMarkup(InlineKeyboardMarkup inlineKeyboardMarkup) {
        this.reply_markup = inlineKeyboardMarkup;
        return this.thisAsT;
    }
}
