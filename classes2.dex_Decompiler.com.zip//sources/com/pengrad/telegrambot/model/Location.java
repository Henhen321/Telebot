package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class Location implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer heading;
    private Float horizontal_accuracy;
    private Float latitude;
    private Integer live_period;
    private Float longitude;
    private Integer proximity_alert_radius;

    public Float longitude() {
        return this.longitude;
    }

    public Float latitude() {
        return this.latitude;
    }

    public Float horizontalAccuracy() {
        return this.horizontal_accuracy;
    }

    public Integer livePeriod() {
        return this.live_period;
    }

    public Integer heading() {
        return this.heading;
    }

    public Integer proximityAlertRadius() {
        return this.proximity_alert_radius;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Location location = (Location) obj;
        if (!Objects.equals(this.longitude, location.longitude) || !Objects.equals(this.latitude, location.latitude) || !Objects.equals(this.horizontal_accuracy, location.horizontal_accuracy) || !Objects.equals(this.live_period, location.live_period) || !Objects.equals(this.heading, location.heading) || !Objects.equals(this.proximity_alert_radius, location.proximity_alert_radius)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.longitude, this.latitude, this.horizontal_accuracy, this.live_period, this.heading, this.proximity_alert_radius});
    }

    public String toString() {
        return "Location{longitude=" + this.longitude + ", latitude=" + this.latitude + ", horizontal_accuracy=" + this.horizontal_accuracy + ", live_period=" + this.live_period + ", heading=" + this.heading + ", proximity_alert_radius=" + this.proximity_alert_radius + '}';
    }
}
