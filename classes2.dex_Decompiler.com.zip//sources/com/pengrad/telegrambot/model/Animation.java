package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class Animation implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer duration;
    private String file_id;
    private String file_name;
    private Long file_size;
    private String file_unique_id;
    private Integer height;
    private String mime_type;
    private PhotoSize thumb;
    private Integer width;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Integer width() {
        return this.width;
    }

    public Integer height() {
        return this.height;
    }

    public Integer duration() {
        return this.duration;
    }

    public PhotoSize thumb() {
        return this.thumb;
    }

    public String fileName() {
        return this.file_name;
    }

    public String mimeType() {
        return this.mime_type;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Animation animation = (Animation) obj;
        String str = this.file_id;
        if (str == null ? animation.file_id != null : !str.equals(animation.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? animation.file_unique_id != null : !str2.equals(animation.file_unique_id)) {
            return false;
        }
        Integer num = this.width;
        if (num == null ? animation.width != null : !num.equals(animation.width)) {
            return false;
        }
        Integer num2 = this.height;
        if (num2 == null ? animation.height != null : !num2.equals(animation.height)) {
            return false;
        }
        Integer num3 = this.duration;
        if (num3 == null ? animation.duration != null : !num3.equals(animation.duration)) {
            return false;
        }
        PhotoSize photoSize = this.thumb;
        if (photoSize == null ? animation.thumb != null : !photoSize.equals(animation.thumb)) {
            return false;
        }
        String str3 = this.file_name;
        if (str3 == null ? animation.file_name != null : !str3.equals(animation.file_name)) {
            return false;
        }
        String str4 = this.mime_type;
        if (str4 == null ? animation.mime_type != null : !str4.equals(animation.mime_type)) {
            return false;
        }
        Long l = this.file_size;
        Long l2 = animation.file_size;
        if (l != null) {
            return l.equals(l2);
        }
        if (l2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Animation{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", width=" + this.width + ", height=" + this.height + ", duration=" + this.duration + ", thumb=" + this.thumb + ", file_name='" + this.file_name + '\'' + ", mime_type='" + this.mime_type + '\'' + ", file_size=" + this.file_size + '}';
    }
}
