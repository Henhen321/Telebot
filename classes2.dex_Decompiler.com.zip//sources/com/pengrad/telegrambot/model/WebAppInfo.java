package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class WebAppInfo implements Serializable {
    private static final long serialVersionUID = 0;
    private String url;

    public WebAppInfo(String str) {
        this.url = str;
    }

    WebAppInfo() {
    }

    public String url() {
        return this.url;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        String str = this.url;
        String str2 = ((WebAppInfo) obj).url;
        if (str != null) {
            return str.equals(str2);
        }
        if (str2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.url;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "WebAppInfo{url='" + this.url + '\'' + '}';
    }
}
