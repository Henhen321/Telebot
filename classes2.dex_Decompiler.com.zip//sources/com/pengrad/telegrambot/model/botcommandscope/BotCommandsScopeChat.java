package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandsScopeChat extends BotCommandScope {
    private Object chat_id;

    public BotCommandsScopeChat(Object obj) {
        this.type = "chat";
        this.chat_id = obj;
    }
}
