package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandScopeAllPrivateChats extends BotCommandScope {
    public BotCommandScopeAllPrivateChats() {
        this.type = "all_private_chats";
    }
}
