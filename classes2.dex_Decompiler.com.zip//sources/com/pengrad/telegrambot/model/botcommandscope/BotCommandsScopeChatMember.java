package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandsScopeChatMember extends BotCommandScope {
    private Object chat_id;
    private long user_id;

    public BotCommandsScopeChatMember(Object obj, long j) {
        this.type = "chat_member";
        this.chat_id = obj;
        this.user_id = j;
    }
}
