package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandScopeDefault extends BotCommandScope {
    public BotCommandScopeDefault() {
        this.type = "default";
    }
}
