package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandScopeAllGroupChats extends BotCommandScope {
    public BotCommandScopeAllGroupChats() {
        this.type = "all_group_chats";
    }
}
