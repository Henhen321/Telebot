package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandsScopeChatAdministrators extends BotCommandScope {
    private Object chat_id;

    public BotCommandsScopeChatAdministrators(Object obj) {
        this.type = "chat_administrators";
        this.chat_id = obj;
    }
}
