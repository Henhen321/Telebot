package com.pengrad.telegrambot.model.botcommandscope;

public class BotCommandScopeAllChatAdministrators extends BotCommandScope {
    public BotCommandScopeAllChatAdministrators() {
        this.type = "all_chat_administrators";
    }
}
