package com.pengrad.telegrambot.model.botcommandscope;

import java.io.Serializable;

public abstract class BotCommandScope implements Serializable {
    private static final long serialVersionUID = 0;
    protected String type = "default";
}
