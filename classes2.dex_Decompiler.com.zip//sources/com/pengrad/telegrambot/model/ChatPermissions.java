package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class ChatPermissions implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean can_add_web_page_previews;
    private Boolean can_change_info;
    private Boolean can_invite_users;
    private Boolean can_pin_messages;
    private Boolean can_send_media_messages;
    private Boolean can_send_messages;
    private Boolean can_send_other_messages;
    private Boolean can_send_polls;

    public Boolean canSendMessages() {
        return this.can_send_messages;
    }

    public Boolean canSendMediaMessages() {
        return this.can_send_media_messages;
    }

    public Boolean canSendPolls() {
        return this.can_send_polls;
    }

    public Boolean canSendOtherMessages() {
        return this.can_send_other_messages;
    }

    public Boolean canAddWebPagePreviews() {
        return this.can_add_web_page_previews;
    }

    public Boolean canChangeInfo() {
        return this.can_change_info;
    }

    public Boolean canInviteUsers() {
        return this.can_invite_users;
    }

    public Boolean canPinMessages() {
        return this.can_pin_messages;
    }

    public ChatPermissions canSendMessages(boolean z) {
        this.can_send_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canSendMediaMessages(boolean z) {
        this.can_send_media_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canSendPolls(boolean z) {
        this.can_send_polls = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canSendOtherMessages(boolean z) {
        this.can_send_other_messages = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canAddWebPagePreviews(boolean z) {
        this.can_add_web_page_previews = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canChangeInfo(boolean z) {
        this.can_change_info = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canInviteUsers(boolean z) {
        this.can_invite_users = Boolean.valueOf(z);
        return this;
    }

    public ChatPermissions canPinMessages(boolean z) {
        this.can_pin_messages = Boolean.valueOf(z);
        return this;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatPermissions chatPermissions = (ChatPermissions) obj;
        Boolean bool = this.can_send_messages;
        if (bool == null ? chatPermissions.can_send_messages != null : !bool.equals(chatPermissions.can_send_messages)) {
            return false;
        }
        Boolean bool2 = this.can_send_media_messages;
        if (bool2 == null ? chatPermissions.can_send_media_messages != null : !bool2.equals(chatPermissions.can_send_media_messages)) {
            return false;
        }
        Boolean bool3 = this.can_send_polls;
        if (bool3 == null ? chatPermissions.can_send_polls != null : !bool3.equals(chatPermissions.can_send_polls)) {
            return false;
        }
        Boolean bool4 = this.can_send_other_messages;
        if (bool4 == null ? chatPermissions.can_send_other_messages != null : !bool4.equals(chatPermissions.can_send_other_messages)) {
            return false;
        }
        Boolean bool5 = this.can_add_web_page_previews;
        if (bool5 == null ? chatPermissions.can_add_web_page_previews != null : !bool5.equals(chatPermissions.can_add_web_page_previews)) {
            return false;
        }
        Boolean bool6 = this.can_change_info;
        if (bool6 == null ? chatPermissions.can_change_info != null : !bool6.equals(chatPermissions.can_change_info)) {
            return false;
        }
        Boolean bool7 = this.can_invite_users;
        if (bool7 == null ? chatPermissions.can_invite_users != null : !bool7.equals(chatPermissions.can_invite_users)) {
            return false;
        }
        Boolean bool8 = this.can_pin_messages;
        Boolean bool9 = chatPermissions.can_pin_messages;
        if (bool8 != null) {
            return bool8.equals(bool9);
        }
        if (bool9 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Boolean bool = this.can_send_messages;
        int i = 0;
        int hashCode = (bool != null ? bool.hashCode() : 0) * 31;
        Boolean bool2 = this.can_send_media_messages;
        int hashCode2 = (hashCode + (bool2 != null ? bool2.hashCode() : 0)) * 31;
        Boolean bool3 = this.can_send_polls;
        int hashCode3 = (hashCode2 + (bool3 != null ? bool3.hashCode() : 0)) * 31;
        Boolean bool4 = this.can_send_other_messages;
        int hashCode4 = (hashCode3 + (bool4 != null ? bool4.hashCode() : 0)) * 31;
        Boolean bool5 = this.can_add_web_page_previews;
        int hashCode5 = (hashCode4 + (bool5 != null ? bool5.hashCode() : 0)) * 31;
        Boolean bool6 = this.can_change_info;
        int hashCode6 = (hashCode5 + (bool6 != null ? bool6.hashCode() : 0)) * 31;
        Boolean bool7 = this.can_invite_users;
        int hashCode7 = (hashCode6 + (bool7 != null ? bool7.hashCode() : 0)) * 31;
        Boolean bool8 = this.can_pin_messages;
        if (bool8 != null) {
            i = bool8.hashCode();
        }
        return hashCode7 + i;
    }

    public String toString() {
        return "ChatPermissions{can_send_messages=" + this.can_send_messages + ", can_send_media_messages=" + this.can_send_media_messages + ", can_send_polls=" + this.can_send_polls + ", can_send_other_messages=" + this.can_send_other_messages + ", can_add_web_page_previews=" + this.can_add_web_page_previews + ", can_change_info=" + this.can_change_info + ", can_invite_users=" + this.can_invite_users + ", can_pin_messages=" + this.can_pin_messages + '}';
    }
}
