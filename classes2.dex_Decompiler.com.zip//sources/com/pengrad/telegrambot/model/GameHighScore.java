package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class GameHighScore implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer position;
    private Integer score;
    private User user;

    public Integer position() {
        return this.position;
    }

    public User user() {
        return this.user;
    }

    public Integer score() {
        return this.score;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        GameHighScore gameHighScore = (GameHighScore) obj;
        Integer num = this.position;
        if (num == null ? gameHighScore.position != null : !num.equals(gameHighScore.position)) {
            return false;
        }
        User user2 = this.user;
        if (user2 == null ? gameHighScore.user != null : !user2.equals(gameHighScore.user)) {
            return false;
        }
        Integer num2 = this.score;
        Integer num3 = gameHighScore.score;
        if (num2 != null) {
            return num2.equals(num3);
        }
        if (num3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Integer num = this.position;
        int i = 0;
        int hashCode = (num != null ? num.hashCode() : 0) * 31;
        User user2 = this.user;
        int hashCode2 = (hashCode + (user2 != null ? user2.hashCode() : 0)) * 31;
        Integer num2 = this.score;
        if (num2 != null) {
            i = num2.hashCode();
        }
        return hashCode2 + i;
    }

    public String toString() {
        return "GameHighScore{position=" + this.position + ", user=" + this.user + ", score=" + this.score + '}';
    }
}
