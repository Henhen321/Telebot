package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class Contact implements Serializable {
    private static final long serialVersionUID = 0;
    private String first_name;
    private String last_name;
    private String phone_number;
    private Long user_id;
    private String vcard;

    public String phoneNumber() {
        return this.phone_number;
    }

    public String firstName() {
        return this.first_name;
    }

    public String lastName() {
        return this.last_name;
    }

    public Long userId() {
        return this.user_id;
    }

    public String vcard() {
        return this.vcard;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Contact contact = (Contact) obj;
        String str = this.phone_number;
        if (str == null ? contact.phone_number != null : !str.equals(contact.phone_number)) {
            return false;
        }
        String str2 = this.first_name;
        if (str2 == null ? contact.first_name != null : !str2.equals(contact.first_name)) {
            return false;
        }
        String str3 = this.last_name;
        if (str3 == null ? contact.last_name != null : !str3.equals(contact.last_name)) {
            return false;
        }
        Long l = this.user_id;
        if (l == null ? contact.user_id != null : !l.equals(contact.user_id)) {
            return false;
        }
        String str4 = this.vcard;
        String str5 = contact.vcard;
        if (str4 != null) {
            return str4.equals(str5);
        }
        if (str5 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.phone_number;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "Contact{phone_number='" + this.phone_number + '\'' + ", first_name='" + this.first_name + '\'' + ", last_name='" + this.last_name + '\'' + ", user_id=" + this.user_id + ", vcard='" + this.vcard + '\'' + '}';
    }
}
