package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class Dice implements Serializable {
    private static final long serialVersionUID = 0;
    private String emoji;
    private Integer value;

    public String emoji() {
        return this.emoji;
    }

    public Integer value() {
        return this.value;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Dice dice = (Dice) obj;
        String str = this.emoji;
        if (str == null ? dice.emoji != null : !str.equals(dice.emoji)) {
            return false;
        }
        Integer num = this.value;
        Integer num2 = dice.value;
        if (num != null) {
            return num.equals(num2);
        }
        if (num2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.emoji;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Integer num = this.value;
        if (num != null) {
            i = num.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "Dice{emoji='" + this.emoji + '\'' + ", value=" + this.value + '}';
    }
}
