package com.pengrad.telegrambot.model;

import java.io.Serializable;
import java.util.Objects;

public class ChatMember implements Serializable {
    private static final long serialVersionUID = 0;
    private Boolean can_add_web_page_previews;
    private Boolean can_be_edited;
    private Boolean can_change_info;
    private Boolean can_delete_messages;
    private Boolean can_edit_messages;
    private Boolean can_invite_users;
    private Boolean can_manage_chat;
    private Boolean can_manage_video_chats;
    private Boolean can_pin_messages;
    private Boolean can_post_messages;
    private Boolean can_promote_members;
    private Boolean can_restrict_members;
    private Boolean can_send_media_messages;
    private Boolean can_send_messages;
    private Boolean can_send_other_messages;
    private Boolean can_send_polls;
    private String custom_title;
    private Boolean is_anonymous;
    private Boolean is_member;
    private Status status;
    private Integer until_date;
    private User user;

    public enum Status {
        creator,
        administrator,
        member,
        restricted,
        left,
        kicked
    }

    public User user() {
        return this.user;
    }

    public Status status() {
        return this.status;
    }

    public String customTitle() {
        return this.custom_title;
    }

    public Boolean isAnonymous() {
        return this.is_anonymous;
    }

    public Integer untilDate() {
        return this.until_date;
    }

    public Boolean canBeEdited() {
        return this.can_be_edited;
    }

    public Boolean canManageChat() {
        return this.can_manage_chat;
    }

    public Boolean canPostMessages() {
        return this.can_post_messages;
    }

    public Boolean canEditMessages() {
        return this.can_edit_messages;
    }

    public Boolean canDeleteMessages() {
        return this.can_delete_messages;
    }

    public Boolean canManageVoiceChats() {
        return this.can_manage_video_chats;
    }

    public Boolean canManageVideoChats() {
        return this.can_manage_video_chats;
    }

    public Boolean canRestrictMembers() {
        return this.can_restrict_members;
    }

    public Boolean canPromoteMembers() {
        return this.can_promote_members;
    }

    public Boolean canChangeInfo() {
        return this.can_change_info;
    }

    public Boolean canInviteUsers() {
        return this.can_invite_users;
    }

    public Boolean canPinMessages() {
        return this.can_pin_messages;
    }

    public Boolean isMember() {
        return this.is_member;
    }

    public Boolean canSendMessages() {
        return this.can_send_messages;
    }

    public Boolean canSendMediaMessages() {
        return this.can_send_media_messages;
    }

    public Boolean canSendPolls() {
        return this.can_send_polls;
    }

    public Boolean canSendOtherMessages() {
        return this.can_send_other_messages;
    }

    public Boolean canAddWebPagePreviews() {
        return this.can_add_web_page_previews;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ChatMember chatMember = (ChatMember) obj;
        if (!Objects.equals(this.user, chatMember.user) || this.status != chatMember.status || !Objects.equals(this.custom_title, chatMember.custom_title) || !Objects.equals(this.is_anonymous, chatMember.is_anonymous) || !Objects.equals(this.until_date, chatMember.until_date) || !Objects.equals(this.can_be_edited, chatMember.can_be_edited) || !Objects.equals(this.can_manage_chat, chatMember.can_manage_chat) || !Objects.equals(this.can_post_messages, chatMember.can_post_messages) || !Objects.equals(this.can_edit_messages, chatMember.can_edit_messages) || !Objects.equals(this.can_delete_messages, chatMember.can_delete_messages) || !Objects.equals(this.can_manage_video_chats, chatMember.can_manage_video_chats) || !Objects.equals(this.can_restrict_members, chatMember.can_restrict_members) || !Objects.equals(this.can_promote_members, chatMember.can_promote_members) || !Objects.equals(this.can_change_info, chatMember.can_change_info) || !Objects.equals(this.can_invite_users, chatMember.can_invite_users) || !Objects.equals(this.can_pin_messages, chatMember.can_pin_messages) || !Objects.equals(this.is_member, chatMember.is_member) || !Objects.equals(this.can_send_messages, chatMember.can_send_messages) || !Objects.equals(this.can_send_media_messages, chatMember.can_send_media_messages) || !Objects.equals(this.can_send_polls, chatMember.can_send_polls) || !Objects.equals(this.can_send_other_messages, chatMember.can_send_other_messages) || !Objects.equals(this.can_add_web_page_previews, chatMember.can_add_web_page_previews)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Objects.hash(new Object[]{this.user, this.status, this.custom_title, this.is_anonymous, this.until_date, this.can_be_edited, this.can_manage_chat, this.can_post_messages, this.can_edit_messages, this.can_delete_messages, this.can_manage_video_chats, this.can_restrict_members, this.can_promote_members, this.can_change_info, this.can_invite_users, this.can_pin_messages, this.is_member, this.can_send_messages, this.can_send_media_messages, this.can_send_polls, this.can_send_other_messages, this.can_add_web_page_previews});
    }

    public String toString() {
        return "ChatMember{user=" + this.user + ", status=" + this.status + ", custom_title='" + this.custom_title + '\'' + ", is_anonymous=" + this.is_anonymous + ", until_date=" + this.until_date + ", can_be_edited=" + this.can_be_edited + ", can_manage_chat=" + this.can_manage_chat + ", can_post_messages=" + this.can_post_messages + ", can_edit_messages=" + this.can_edit_messages + ", can_delete_messages=" + this.can_delete_messages + ", can_manage_video_chats=" + this.can_manage_video_chats + ", can_restrict_members=" + this.can_restrict_members + ", can_promote_members=" + this.can_promote_members + ", can_change_info=" + this.can_change_info + ", can_invite_users=" + this.can_invite_users + ", can_pin_messages=" + this.can_pin_messages + ", is_member=" + this.is_member + ", can_send_messages=" + this.can_send_messages + ", can_send_media_messages=" + this.can_send_media_messages + ", can_send_polls=" + this.can_send_polls + ", can_send_other_messages=" + this.can_send_other_messages + ", can_add_web_page_previews=" + this.can_add_web_page_previews + '}';
    }
}
