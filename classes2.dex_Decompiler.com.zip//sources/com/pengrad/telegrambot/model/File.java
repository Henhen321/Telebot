package com.pengrad.telegrambot.model;

import java.io.Serializable;

public class File implements Serializable {
    private static final long serialVersionUID = 0;
    private String file_id;
    private String file_path;
    private Long file_size;
    private String file_unique_id;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public String filePath() {
        return this.file_path;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        File file = (File) obj;
        String str = this.file_id;
        if (str == null ? file.file_id != null : !str.equals(file.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? file.file_unique_id != null : !str2.equals(file.file_unique_id)) {
            return false;
        }
        Long l = this.file_size;
        if (l == null ? file.file_size != null : !l.equals(file.file_size)) {
            return false;
        }
        String str3 = this.file_path;
        String str4 = file.file_path;
        if (str3 != null) {
            return str3.equals(str4);
        }
        if (str4 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "File{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", file_size=" + this.file_size + ", file_path='" + this.file_path + '\'' + '}';
    }
}
