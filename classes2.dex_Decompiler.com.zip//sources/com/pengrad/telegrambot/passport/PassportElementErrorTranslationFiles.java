package com.pengrad.telegrambot.passport;

public class PassportElementErrorTranslationFiles extends PassportElementError {
    private static final long serialVersionUID = 0;
    private String[] file_hashes;

    public PassportElementErrorTranslationFiles(String str, String[] strArr, String str2) {
        super("translation_files", str, str2);
        this.file_hashes = strArr;
    }
}
