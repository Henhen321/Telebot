package com.pengrad.telegrambot.passport;

abstract class PassportElementErrorAbstractFile extends PassportElementError {
    private static final long serialVersionUID = 0;
    private final String file_hash;

    public PassportElementErrorAbstractFile(String str, String str2, String str3, String str4) {
        super(str, str2, str4);
        this.file_hash = str3;
    }
}
