package com.pengrad.telegrambot.passport;

import java.io.Serializable;
import java.util.Arrays;

public class PassportData implements Serializable {
    private static final long serialVersionUID = 0;
    private EncryptedCredentials credentials;
    private EncryptedPassportElement[] data;

    public EncryptedPassportElement[] data() {
        return this.data;
    }

    public EncryptedCredentials credentials() {
        return this.credentials;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PassportData passportData = (PassportData) obj;
        if (!Arrays.equals(this.data, passportData.data)) {
            return false;
        }
        EncryptedCredentials encryptedCredentials = this.credentials;
        EncryptedCredentials encryptedCredentials2 = passportData.credentials;
        if (encryptedCredentials != null) {
            return encryptedCredentials.equals(encryptedCredentials2);
        }
        if (encryptedCredentials2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int hashCode = Arrays.hashCode(this.data) * 31;
        EncryptedCredentials encryptedCredentials = this.credentials;
        return hashCode + (encryptedCredentials != null ? encryptedCredentials.hashCode() : 0);
    }

    public String toString() {
        return "PassportData{data=" + Arrays.toString(this.data) + ", credentials=" + this.credentials + '}';
    }
}
