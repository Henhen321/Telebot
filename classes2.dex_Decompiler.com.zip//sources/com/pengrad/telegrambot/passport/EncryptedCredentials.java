package com.pengrad.telegrambot.passport;

import com.pengrad.telegrambot.passport.decrypt.Decrypt;
import java.io.Serializable;

public class EncryptedCredentials implements Serializable {
    private static final long serialVersionUID = 0;
    private String data;
    private String hash;
    private String secret;

    public Credentials decrypt(String str) throws Exception {
        return Decrypt.decryptCredentials(str, this.data, this.hash, this.secret);
    }

    public String data() {
        return this.data;
    }

    public String hash() {
        return this.hash;
    }

    public String secret() {
        return this.secret;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        EncryptedCredentials encryptedCredentials = (EncryptedCredentials) obj;
        String str = this.data;
        if (str == null ? encryptedCredentials.data != null : !str.equals(encryptedCredentials.data)) {
            return false;
        }
        String str2 = this.hash;
        if (str2 == null ? encryptedCredentials.hash != null : !str2.equals(encryptedCredentials.hash)) {
            return false;
        }
        String str3 = this.secret;
        String str4 = encryptedCredentials.secret;
        if (str3 != null) {
            return str3.equals(str4);
        }
        if (str4 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.data;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.hash;
        int hashCode2 = (hashCode + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.secret;
        if (str3 != null) {
            i = str3.hashCode();
        }
        return hashCode2 + i;
    }

    public String toString() {
        return "EncryptedCredentials{data='" + this.data + '\'' + ", hash='" + this.hash + '\'' + ", secret='" + this.secret + '\'' + '}';
    }
}
