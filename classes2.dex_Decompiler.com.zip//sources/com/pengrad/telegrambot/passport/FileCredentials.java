package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public class FileCredentials implements Serializable {
    private static final long serialVersionUID = 0;
    private String file_hash;
    private String secret;

    public String fileHash() {
        return this.file_hash;
    }

    public String secret() {
        return this.secret;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        FileCredentials fileCredentials = (FileCredentials) obj;
        String str = this.file_hash;
        if (str == null ? fileCredentials.file_hash != null : !str.equals(fileCredentials.file_hash)) {
            return false;
        }
        String str2 = this.secret;
        String str3 = fileCredentials.secret;
        if (str2 != null) {
            return str2.equals(str3);
        }
        if (str3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_hash;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.secret;
        if (str2 != null) {
            i = str2.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "FileCredentials{file_hash='" + this.file_hash + '\'' + ", secret='" + this.secret + '\'' + '}';
    }
}
