package com.pengrad.telegrambot.passport;

public class PassportElementErrorFile extends PassportElementErrorAbstractFile {
    private static final long serialVersionUID = 0;

    public PassportElementErrorFile(String str, String str2, String str3) {
        super("file", str, str2, str3);
    }
}
