package com.pengrad.telegrambot.passport;

import com.google.gson.Gson;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.passport.decrypt.Decrypt;
import com.pengrad.telegrambot.request.GetFile;
import com.pengrad.telegrambot.response.GetFileResponse;
import java.io.Serializable;
import java.util.Arrays;

public class EncryptedPassportElement implements Serializable {
    private static final long serialVersionUID = 0;
    private String data;
    private String email;
    private PassportFile[] files;
    private PassportFile front_side;
    private String hash;
    private String phone_number;
    private PassportFile reverse_side;
    private PassportFile selfie;
    private PassportFile[] translation;
    private Type type;

    public enum Type {
        personal_details,
        passport,
        driver_license,
        identity_card,
        internal_passport,
        address,
        utility_bill,
        bank_statement,
        rental_agreement,
        passport_registration,
        temporary_registration,
        phone_number,
        email
    }

    public DecryptedData decryptData(Credentials credentials) throws Exception {
        Class<? extends DecryptedData> dataClass = dataClass();
        if (dataClass == null || this.data == null) {
            return null;
        }
        DataCredentials data2 = credentials.secureData().ofType(this.type).data();
        return (DecryptedData) new Gson().fromJson(Decrypt.decryptData(this.data, data2.dataHash(), data2.secret()), dataClass);
    }

    public byte[] decryptFile(PassportFile passportFile, FileCredentials fileCredentials, TelegramBot telegramBot) throws Exception {
        return decryptFile(telegramBot.getFileContent(((GetFileResponse) telegramBot.execute(new GetFile(passportFile.fileId()))).file()), fileCredentials);
    }

    public byte[] decryptFile(PassportFile passportFile, Credentials credentials, TelegramBot telegramBot) throws Exception {
        FileCredentials findFileCredentials = findFileCredentials(passportFile, credentials);
        if (findFileCredentials != null) {
            return decryptFile(passportFile, findFileCredentials, telegramBot);
        }
        throw new IllegalArgumentException("Don't have file credentials for " + passportFile);
    }

    public byte[] decryptFile(byte[] bArr, FileCredentials fileCredentials) throws Exception {
        return Decrypt.decryptFile(bArr, fileCredentials.fileHash(), fileCredentials.secret());
    }

    private FileCredentials findFileCredentials(PassportFile passportFile, Credentials credentials) {
        SecureValue ofType = credentials.secureData().ofType(this.type);
        if (passportFile.equals(this.front_side)) {
            return ofType.frontSide();
        }
        if (passportFile.equals(this.reverse_side)) {
            return ofType.reverseSide();
        }
        if (passportFile.equals(this.selfie)) {
            return ofType.selfie();
        }
        int i = 0;
        if (this.files != null) {
            int i2 = 0;
            while (true) {
                PassportFile[] passportFileArr = this.files;
                if (i2 >= passportFileArr.length) {
                    break;
                } else if (passportFile.equals(passportFileArr[i2])) {
                    return ofType.files()[i2];
                } else {
                    i2++;
                }
            }
        }
        if (this.translation == null) {
            return null;
        }
        while (true) {
            PassportFile[] passportFileArr2 = this.translation;
            if (i >= passportFileArr2.length) {
                return null;
            }
            if (passportFile.equals(passportFileArr2[i])) {
                return ofType.translation()[i];
            }
            i++;
        }
    }

    private Class<? extends DecryptedData> dataClass() {
        if (Type.personal_details == this.type) {
            return PersonalDetails.class;
        }
        if (Type.passport == this.type || Type.internal_passport == this.type || Type.driver_license == this.type || Type.identity_card == this.type) {
            return IdDocumentData.class;
        }
        if (Type.address == this.type) {
            return ResidentialAddress.class;
        }
        return null;
    }

    public Type type() {
        return this.type;
    }

    public String data() {
        return this.data;
    }

    public String phoneNumber() {
        return this.phone_number;
    }

    public String email() {
        return this.email;
    }

    public PassportFile[] files() {
        return this.files;
    }

    public PassportFile frontSide() {
        return this.front_side;
    }

    public PassportFile reverseSide() {
        return this.reverse_side;
    }

    public PassportFile selfie() {
        return this.selfie;
    }

    public PassportFile[] translation() {
        return this.translation;
    }

    public String hash() {
        return this.hash;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        EncryptedPassportElement encryptedPassportElement = (EncryptedPassportElement) obj;
        if (this.type != encryptedPassportElement.type) {
            return false;
        }
        String str = this.data;
        if (str == null ? encryptedPassportElement.data != null : !str.equals(encryptedPassportElement.data)) {
            return false;
        }
        String str2 = this.phone_number;
        if (str2 == null ? encryptedPassportElement.phone_number != null : !str2.equals(encryptedPassportElement.phone_number)) {
            return false;
        }
        String str3 = this.email;
        if (str3 == null ? encryptedPassportElement.email != null : !str3.equals(encryptedPassportElement.email)) {
            return false;
        }
        if (!Arrays.equals(this.files, encryptedPassportElement.files)) {
            return false;
        }
        PassportFile passportFile = this.front_side;
        if (passportFile == null ? encryptedPassportElement.front_side != null : !passportFile.equals(encryptedPassportElement.front_side)) {
            return false;
        }
        PassportFile passportFile2 = this.reverse_side;
        if (passportFile2 == null ? encryptedPassportElement.reverse_side != null : !passportFile2.equals(encryptedPassportElement.reverse_side)) {
            return false;
        }
        PassportFile passportFile3 = this.selfie;
        if (passportFile3 == null ? encryptedPassportElement.selfie != null : !passportFile3.equals(encryptedPassportElement.selfie)) {
            return false;
        }
        if (!Arrays.equals(this.translation, encryptedPassportElement.translation)) {
            return false;
        }
        String str4 = this.hash;
        String str5 = encryptedPassportElement.hash;
        if (str4 != null) {
            return str4.equals(str5);
        }
        if (str5 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        Type type2 = this.type;
        int i = 0;
        int hashCode = (type2 != null ? type2.hashCode() : 0) * 31;
        String str = this.data;
        int hashCode2 = (hashCode + (str != null ? str.hashCode() : 0)) * 31;
        String str2 = this.phone_number;
        int hashCode3 = (hashCode2 + (str2 != null ? str2.hashCode() : 0)) * 31;
        String str3 = this.email;
        int hashCode4 = (((hashCode3 + (str3 != null ? str3.hashCode() : 0)) * 31) + Arrays.hashCode(this.files)) * 31;
        PassportFile passportFile = this.front_side;
        int hashCode5 = (hashCode4 + (passportFile != null ? passportFile.hashCode() : 0)) * 31;
        PassportFile passportFile2 = this.reverse_side;
        int hashCode6 = (hashCode5 + (passportFile2 != null ? passportFile2.hashCode() : 0)) * 31;
        PassportFile passportFile3 = this.selfie;
        int hashCode7 = (((hashCode6 + (passportFile3 != null ? passportFile3.hashCode() : 0)) * 31) + Arrays.hashCode(this.translation)) * 31;
        String str4 = this.hash;
        if (str4 != null) {
            i = str4.hashCode();
        }
        return hashCode7 + i;
    }

    public String toString() {
        return "EncryptedPassportElement{type=" + this.type + ", data='" + this.data + '\'' + ", phone_number='" + this.phone_number + '\'' + ", email='" + this.email + '\'' + ", files=" + Arrays.toString(this.files) + ", front_side=" + this.front_side + ", reverse_side=" + this.reverse_side + ", selfie=" + this.selfie + ", translation=" + Arrays.toString(this.translation) + ", hash='" + this.hash + '\'' + '}';
    }
}
