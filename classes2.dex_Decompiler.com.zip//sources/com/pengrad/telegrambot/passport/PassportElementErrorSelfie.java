package com.pengrad.telegrambot.passport;

public class PassportElementErrorSelfie extends PassportElementErrorAbstractFile {
    private static final long serialVersionUID = 0;

    public PassportElementErrorSelfie(String str, String str2, String str3) {
        super("selfie", str, str2, str3);
    }
}
