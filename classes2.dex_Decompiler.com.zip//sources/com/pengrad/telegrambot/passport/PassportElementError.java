package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public abstract class PassportElementError implements Serializable {
    private static final long serialVersionUID = 0;
    private final String message;
    private final String source;
    private final String type;

    public PassportElementError(String str, String str2, String str3) {
        this.source = str;
        this.type = str2;
        this.message = str3;
    }
}
