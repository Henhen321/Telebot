package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public class IdDocumentData extends DecryptedData implements Serializable {
    private static final long serialVersionUID = 0;
    private String document_no;
    private String expiry_date;

    public String documentNo() {
        return this.document_no;
    }

    public String expiryDate() {
        return this.expiry_date;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        IdDocumentData idDocumentData = (IdDocumentData) obj;
        String str = this.document_no;
        if (str == null ? idDocumentData.document_no != null : !str.equals(idDocumentData.document_no)) {
            return false;
        }
        String str2 = this.expiry_date;
        String str3 = idDocumentData.expiry_date;
        if (str2 != null) {
            return str2.equals(str3);
        }
        if (str3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.document_no;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.expiry_date;
        if (str2 != null) {
            i = str2.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "IdDocumentData{document_no='" + this.document_no + '\'' + ", expiry_date='" + this.expiry_date + '\'' + '}';
    }
}
