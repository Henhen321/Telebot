package com.pengrad.telegrambot.passport;

import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;

public class SetPassportDataErrors extends BaseRequest<SetPassportDataErrors, BaseResponse> {
    public SetPassportDataErrors(long j, PassportElementError... passportElementErrorArr) {
        super(BaseResponse.class);
        ((SetPassportDataErrors) add("user_id", Long.valueOf(j))).add("errors", passportElementErrorArr);
    }
}
