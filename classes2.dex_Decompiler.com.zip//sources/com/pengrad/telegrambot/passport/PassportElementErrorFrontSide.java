package com.pengrad.telegrambot.passport;

public class PassportElementErrorFrontSide extends PassportElementErrorAbstractFile {
    private static final long serialVersionUID = 0;

    public PassportElementErrorFrontSide(String str, String str2, String str3) {
        super("front_side", str, str2, str3);
    }
}
