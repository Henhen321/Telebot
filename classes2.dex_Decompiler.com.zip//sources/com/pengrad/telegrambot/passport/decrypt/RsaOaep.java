package com.pengrad.telegrambot.passport.decrypt;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.RSAPrivateCrtKeySpec;
import javax.crypto.Cipher;

class RsaOaep {
    RsaOaep() {
    }

    static byte[] decrypt(String str, byte[] bArr) throws Exception {
        PrivateKey generatePrivate = KeyFactory.getInstance("RSA").generatePrivate(getRSAKeySpec(Base64.decode(str.replace("-----BEGIN RSA PRIVATE KEY-----", "").replace("-----END RSA PRIVATE KEY-----", "").replaceAll("\\s+", ""), 0)));
        Cipher instance = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
        instance.init(2, generatePrivate);
        return instance.doFinal(bArr);
    }

    private static RSAPrivateCrtKeySpec getRSAKeySpec(byte[] bArr) throws IOException {
        Asn1Object read = new DerParser(bArr).read();
        if (read.getType() == 16) {
            DerParser parser = read.getParser();
            parser.read();
            return new RSAPrivateCrtKeySpec(parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger(), parser.read().getInteger());
        }
        throw new IOException("Invalid DER: not a sequence");
    }

    private static class DerParser {
        public static final int ANY = 0;
        public static final int APPLICATION = 64;
        public static final int BIT_STRING = 3;
        public static final int BMP_STRING = 30;
        public static final int BOOLEAN = 1;
        public static final int CONSTRUCTED = 32;
        public static final int CONTEXT = 128;
        public static final int ENUMERATED = 10;
        public static final int GENERALIZED_TIME = 24;
        public static final int GENERAL_STRING = 27;
        public static final int GRAPHIC_STRING = 25;
        public static final int IA5_STRING = 22;
        public static final int INTEGER = 2;
        public static final int ISO646_STRING = 26;
        public static final int NULL = 5;
        public static final int NUMERIC_STRING = 18;
        public static final int OBJECT_IDENTIFIER = 6;
        public static final int OCTET_STRING = 4;
        public static final int PRINTABLE_STRING = 19;
        public static final int PRIVATE = 192;
        public static final int REAL = 9;
        public static final int RELATIVE_OID = 13;
        public static final int SEQUENCE = 16;
        public static final int SET = 17;
        public static final int T61_STRING = 20;
        public static final int UNIVERSAL = 0;
        public static final int UNIVERSAL_STRING = 28;
        public static final int UTC_TIME = 23;
        public static final int UTF8_STRING = 12;
        public static final int VIDEOTEX_STRING = 21;
        protected InputStream in;

        public DerParser(InputStream inputStream) throws IOException {
            this.in = inputStream;
        }

        public DerParser(byte[] bArr) throws IOException {
            this((InputStream) new ByteArrayInputStream(bArr));
        }

        public Asn1Object read() throws IOException {
            int read = this.in.read();
            if (read != -1) {
                int length = getLength();
                byte[] bArr = new byte[length];
                if (this.in.read(bArr) >= length) {
                    return new Asn1Object(read, length, bArr);
                }
                throw new IOException("Invalid DER: stream too short, missing value");
            }
            throw new IOException("Invalid DER: stream too short, missing tag");
        }

        private int getLength() throws IOException {
            int read = this.in.read();
            if (read == -1) {
                throw new IOException("Invalid DER: length missing");
            } else if ((read & -128) == 0) {
                return read;
            } else {
                int i = read & 127;
                if (read >= 255 || i > 4) {
                    throw new IOException("Invalid DER: length field too big (" + read + ")");
                }
                byte[] bArr = new byte[i];
                if (this.in.read(bArr) >= i) {
                    return new BigInteger(1, bArr).intValue();
                }
                throw new IOException("Invalid DER: length too short");
            }
        }
    }

    private static class Asn1Object {
        protected final int length;
        protected final int tag;
        protected final int type;
        protected final byte[] value;

        public Asn1Object(int i, int i2, byte[] bArr) {
            this.tag = i;
            this.type = i & 31;
            this.length = i2;
            this.value = bArr;
        }

        public int getType() {
            return this.type;
        }

        public int getLength() {
            return this.length;
        }

        public byte[] getValue() {
            return this.value;
        }

        public boolean isConstructed() {
            return (this.tag & 32) == 32;
        }

        public DerParser getParser() throws IOException {
            if (isConstructed()) {
                return new DerParser(this.value);
            }
            throw new IOException("Invalid DER: can't parse primitive entity");
        }

        public BigInteger getInteger() throws IOException {
            if (this.type == 2) {
                return new BigInteger(this.value);
            }
            throw new IOException("Invalid DER: object is not integer");
        }
    }
}
