package com.pengrad.telegrambot.passport.decrypt;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

class SecretHash {
    private final byte[] secretHash;

    public SecretHash(byte[] bArr, byte[] bArr2) throws Exception {
        this.secretHash = sha512(concat(bArr, bArr2));
    }

    public byte[] key() {
        return Arrays.copyOfRange(this.secretHash, 0, 32);
    }

    public byte[] iv() {
        return Arrays.copyOfRange(this.secretHash, 32, 48);
    }

    private byte[] sha512(byte[] bArr) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance("SHA-512").digest(bArr);
    }

    private byte[] concat(byte[]... bArr) {
        int i = 0;
        for (byte[] length : bArr) {
            i += length.length;
        }
        byte[] bArr2 = new byte[i];
        int i2 = 0;
        for (byte[] bArr3 : bArr) {
            for (byte b : bArr[r3]) {
                bArr2[i2] = b;
                i2++;
            }
        }
        return bArr2;
    }
}
