package com.pengrad.telegrambot.passport.decrypt;

import com.google.gson.Gson;
import com.pengrad.telegrambot.passport.Credentials;
import java.util.Arrays;
import kotlin.UByte;

public class Decrypt {
    public static Credentials decryptCredentials(String str, String str2, String str3, String str4) throws Exception {
        SecretHash secretHash = new SecretHash(RsaOaep.decrypt(str, base64(str4)), base64(str3));
        return (Credentials) new Gson().fromJson(new String(decryptAes256Cbc(secretHash.key(), secretHash.iv(), base64(str2))), Credentials.class);
    }

    public static String decryptData(String str, String str2, String str3) throws Exception {
        return new String(decryptFile(base64(str), str2, str3));
    }

    public static byte[] decryptFile(byte[] bArr, String str, String str2) throws Exception {
        SecretHash secretHash = new SecretHash(base64(str2), base64(str));
        return decryptAes256Cbc(secretHash.key(), secretHash.iv(), bArr);
    }

    private static byte[] decryptAes256Cbc(byte[] bArr, byte[] bArr2, byte[] bArr3) throws Exception {
        byte[] decrypt = new Aes256Cbc(bArr, bArr2).decrypt(bArr3);
        return Arrays.copyOfRange(decrypt, decrypt[0] & UByte.MAX_VALUE, decrypt.length);
    }

    private static byte[] base64(String str) {
        return Base64.decode(str, 0);
    }
}
