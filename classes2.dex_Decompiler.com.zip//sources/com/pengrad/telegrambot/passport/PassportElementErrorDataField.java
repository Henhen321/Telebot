package com.pengrad.telegrambot.passport;

public class PassportElementErrorDataField extends PassportElementError {
    private static final long serialVersionUID = 0;
    private final String data_hash;
    private final String field_name;

    public PassportElementErrorDataField(String str, String str2, String str3, String str4) {
        super("data", str, str4);
        this.field_name = str2;
        this.data_hash = str3;
    }
}
