package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public class PassportFile implements Serializable {
    private static final long serialVersionUID = 0;
    private Integer file_date;
    private String file_id;
    private Long file_size;
    private String file_unique_id;

    public String fileId() {
        return this.file_id;
    }

    public String fileUniqueId() {
        return this.file_unique_id;
    }

    public Long fileSize() {
        return this.file_size;
    }

    public Integer fileDate() {
        return this.file_date;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        PassportFile passportFile = (PassportFile) obj;
        String str = this.file_id;
        if (str == null ? passportFile.file_id != null : !str.equals(passportFile.file_id)) {
            return false;
        }
        String str2 = this.file_unique_id;
        if (str2 == null ? passportFile.file_unique_id != null : !str2.equals(passportFile.file_unique_id)) {
            return false;
        }
        Long l = this.file_size;
        if (l == null ? passportFile.file_size != null : !l.equals(passportFile.file_size)) {
            return false;
        }
        Integer num = this.file_date;
        Integer num2 = passportFile.file_date;
        if (num != null) {
            return num.equals(num2);
        }
        if (num2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.file_id;
        if (str != null) {
            return str.hashCode();
        }
        return 0;
    }

    public String toString() {
        return "PassportFile{file_id='" + this.file_id + '\'' + ", file_unique_id='" + this.file_unique_id + '\'' + ", file_size=" + this.file_size + ", file_date=" + this.file_date + '}';
    }
}
