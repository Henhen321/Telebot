package com.pengrad.telegrambot.passport;

public abstract class DecryptedData {
}
