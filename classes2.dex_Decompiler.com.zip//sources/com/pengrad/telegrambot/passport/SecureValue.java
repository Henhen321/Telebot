package com.pengrad.telegrambot.passport;

import java.io.Serializable;
import java.util.Arrays;

public class SecureValue implements Serializable {
    private static final long serialVersionUID = 0;
    private DataCredentials data;
    private FileCredentials[] files;
    private FileCredentials front_side;
    private FileCredentials reverse_side;
    private FileCredentials selfie;
    private FileCredentials[] translation;

    public DataCredentials data() {
        return this.data;
    }

    public FileCredentials frontSide() {
        return this.front_side;
    }

    public FileCredentials reverseSide() {
        return this.reverse_side;
    }

    public FileCredentials selfie() {
        return this.selfie;
    }

    public FileCredentials[] translation() {
        return this.translation;
    }

    public FileCredentials[] files() {
        return this.files;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        SecureValue secureValue = (SecureValue) obj;
        DataCredentials dataCredentials = this.data;
        if (dataCredentials == null ? secureValue.data != null : !dataCredentials.equals(secureValue.data)) {
            return false;
        }
        FileCredentials fileCredentials = this.front_side;
        if (fileCredentials == null ? secureValue.front_side != null : !fileCredentials.equals(secureValue.front_side)) {
            return false;
        }
        FileCredentials fileCredentials2 = this.reverse_side;
        if (fileCredentials2 == null ? secureValue.reverse_side != null : !fileCredentials2.equals(secureValue.reverse_side)) {
            return false;
        }
        FileCredentials fileCredentials3 = this.selfie;
        if (fileCredentials3 == null ? secureValue.selfie != null : !fileCredentials3.equals(secureValue.selfie)) {
            return false;
        }
        if (!Arrays.equals(this.translation, secureValue.translation)) {
            return false;
        }
        return Arrays.equals(this.files, secureValue.files);
    }

    public int hashCode() {
        DataCredentials dataCredentials = this.data;
        int i = 0;
        int hashCode = (dataCredentials != null ? dataCredentials.hashCode() : 0) * 31;
        FileCredentials fileCredentials = this.front_side;
        int hashCode2 = (hashCode + (fileCredentials != null ? fileCredentials.hashCode() : 0)) * 31;
        FileCredentials fileCredentials2 = this.reverse_side;
        int hashCode3 = (hashCode2 + (fileCredentials2 != null ? fileCredentials2.hashCode() : 0)) * 31;
        FileCredentials fileCredentials3 = this.selfie;
        if (fileCredentials3 != null) {
            i = fileCredentials3.hashCode();
        }
        return ((((hashCode3 + i) * 31) + Arrays.hashCode(this.translation)) * 31) + Arrays.hashCode(this.files);
    }

    public String toString() {
        return "SecureValue{data=" + this.data + ", front_side=" + this.front_side + ", reverse_side=" + this.reverse_side + ", selfie=" + this.selfie + ", translation=" + Arrays.toString(this.translation) + ", files=" + Arrays.toString(this.files) + '}';
    }
}
