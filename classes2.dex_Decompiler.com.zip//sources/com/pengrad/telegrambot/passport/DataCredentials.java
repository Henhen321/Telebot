package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public class DataCredentials implements Serializable {
    private static final long serialVersionUID = 0;
    private String data_hash;
    private String secret;

    public String dataHash() {
        return this.data_hash;
    }

    public String secret() {
        return this.secret;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        DataCredentials dataCredentials = (DataCredentials) obj;
        String str = this.data_hash;
        if (str == null ? dataCredentials.data_hash != null : !str.equals(dataCredentials.data_hash)) {
            return false;
        }
        String str2 = this.secret;
        String str3 = dataCredentials.secret;
        if (str2 != null) {
            return str2.equals(str3);
        }
        if (str3 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        String str = this.data_hash;
        int i = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.secret;
        if (str2 != null) {
            i = str2.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "DataCredentials{data_hash='" + this.data_hash + '\'' + ", secret='" + this.secret + '\'' + '}';
    }
}
