package com.pengrad.telegrambot.passport;

public class PassportElementErrorUnspecified extends PassportElementError {
    private static final long serialVersionUID = 0;
    private String element_hash;

    public PassportElementErrorUnspecified(String str, String str2, String str3) {
        super("unspecified", str, str3);
        this.element_hash = str2;
    }
}
