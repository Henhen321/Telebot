package com.pengrad.telegrambot.passport;

import java.io.Serializable;

public class Credentials implements Serializable {
    private static final long serialVersionUID = 0;
    private String nonce;
    private SecureData secure_data;

    public SecureData secureData() {
        return this.secure_data;
    }

    public String nonce() {
        return this.nonce;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Credentials credentials = (Credentials) obj;
        SecureData secureData = this.secure_data;
        if (secureData == null ? credentials.secure_data != null : !secureData.equals(credentials.secure_data)) {
            return false;
        }
        String str = this.nonce;
        String str2 = credentials.nonce;
        if (str != null) {
            return str.equals(str2);
        }
        if (str2 == null) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        SecureData secureData = this.secure_data;
        int i = 0;
        int hashCode = (secureData != null ? secureData.hashCode() : 0) * 31;
        String str = this.nonce;
        if (str != null) {
            i = str.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        return "Credentials{secure_data=" + this.secure_data + ", nonce='" + this.nonce + '\'' + '}';
    }
}
