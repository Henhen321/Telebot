package com.pengrad.telegrambot.passport;

public class PassportElementErrorTranslationFile extends PassportElementErrorAbstractFile {
    private static final long serialVersionUID = 0;

    public PassportElementErrorTranslationFile(String str, String str2, String str3) {
        super("translation_file", str, str2, str3);
    }
}
