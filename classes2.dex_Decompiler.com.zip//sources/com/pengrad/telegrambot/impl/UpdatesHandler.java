package com.pengrad.telegrambot.impl;

import com.pengrad.telegrambot.Callback;
import com.pengrad.telegrambot.ExceptionHandler;
import com.pengrad.telegrambot.TelegramBot;
import com.pengrad.telegrambot.TelegramException;
import com.pengrad.telegrambot.UpdatesListener;
import com.pengrad.telegrambot.model.Update;
import com.pengrad.telegrambot.request.GetUpdates;
import com.pengrad.telegrambot.response.GetUpdatesResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UpdatesHandler {
    private TelegramBot bot;
    /* access modifiers changed from: private */
    public ExceptionHandler exceptionHandler;
    /* access modifiers changed from: private */
    public UpdatesListener listener;
    private final long sleepTimeout;

    public UpdatesHandler(long j) {
        this.sleepTimeout = j;
    }

    public void start(TelegramBot telegramBot, UpdatesListener updatesListener, ExceptionHandler exceptionHandler2, GetUpdates getUpdates) {
        this.bot = telegramBot;
        this.listener = updatesListener;
        this.exceptionHandler = exceptionHandler2;
        getUpdates(getUpdates);
    }

    public void stop() {
        this.bot = null;
        this.listener = null;
        this.exceptionHandler = null;
    }

    /* access modifiers changed from: private */
    public void getUpdates(GetUpdates getUpdates) {
        TelegramBot telegramBot = this.bot;
        if (telegramBot != null && this.listener != null) {
            telegramBot.execute(getUpdates, new Callback<GetUpdates, GetUpdatesResponse>() {
                public void onResponse(GetUpdates getUpdates, GetUpdatesResponse getUpdatesResponse) {
                    if (UpdatesHandler.this.listener != null) {
                        if (!getUpdatesResponse.isOk() || getUpdatesResponse.updates() == null || getUpdatesResponse.updates().size() <= 0) {
                            if (!getUpdatesResponse.isOk()) {
                                if (UpdatesHandler.this.exceptionHandler != null) {
                                    UpdatesHandler.this.exceptionHandler.onException(new TelegramException("GetUpdates failed with error_code " + getUpdatesResponse.errorCode() + " " + getUpdatesResponse.description(), getUpdatesResponse));
                                } else {
                                    Logger global = Logger.getGlobal();
                                    Level level = Level.INFO;
                                    global.log(level, "Update listener error for request " + getUpdates.toWebhookResponse() + " with response " + getUpdatesResponse.errorCode() + " " + getUpdatesResponse.description());
                                }
                            }
                            UpdatesHandler.this.sleep();
                            UpdatesHandler.this.getUpdates(getUpdates);
                            return;
                        }
                        List<Update> updates = getUpdatesResponse.updates();
                        if (updates == null) {
                            updates = Collections.emptyList();
                        }
                        int process = UpdatesHandler.this.listener.process(updates);
                        if (process != -2) {
                            getUpdates = getUpdates.offset(process == -1 ? UpdatesHandler.this.lastUpdateId(updates) + 1 : process + 1);
                        }
                        UpdatesHandler.this.getUpdates(getUpdates);
                    }
                }

                public void onFailure(GetUpdates getUpdates, IOException iOException) {
                    if (UpdatesHandler.this.exceptionHandler != null) {
                        UpdatesHandler.this.exceptionHandler.onException(new TelegramException(iOException));
                    } else {
                        Logger.getGlobal().log(Level.INFO, "Update listener failure", iOException);
                    }
                    UpdatesHandler.this.sleep();
                    UpdatesHandler.this.getUpdates(getUpdates);
                }
            });
        }
    }

    /* access modifiers changed from: private */
    public int lastUpdateId(List<Update> list) {
        return list.get(list.size() - 1).updateId().intValue();
    }

    /* access modifiers changed from: private */
    public void sleep() {
        long j = this.sleepTimeout;
        if (j > 0) {
            try {
                Thread.sleep(j);
            } catch (InterruptedException unused) {
            }
        }
    }
}
