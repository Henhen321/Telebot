package com.pengrad.telegrambot.impl;

import com.google.gson.Gson;
import com.pengrad.telegrambot.Callback;
import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class TelegramBotClient {
    private final String baseUrl;
    private final OkHttpClient client;
    private OkHttpClient clientWithTimeout;
    /* access modifiers changed from: private */
    public final Gson gson;

    public TelegramBotClient(OkHttpClient okHttpClient, Gson gson2, String str) {
        this.client = okHttpClient;
        this.gson = gson2;
        this.baseUrl = str;
        this.clientWithTimeout = okHttpClient;
    }

    public <T extends BaseRequest<T, R>, R extends BaseResponse> void send(final T t, final Callback<T, R> callback) {
        getOkHttpClient(t).newCall(createRequest(t)).enqueue(new okhttp3.Callback() {
            public void onResponse(Call call, Response response) {
                BaseResponse baseResponse = null;
                try {
                    BaseResponse baseResponse2 = (BaseResponse) TelegramBotClient.this.gson.fromJson(response.body().string(), t.getResponseType());
                    e = null;
                    baseResponse = baseResponse2;
                } catch (Exception e) {
                    e = e;
                }
                if (baseResponse != null) {
                    callback.onResponse(t, baseResponse);
                } else if (e != null) {
                    callback.onFailure(t, e instanceof IOException ? (IOException) e : new IOException(e));
                } else {
                    callback.onFailure(t, new IOException("Empty response"));
                }
            }

            public void onFailure(Call call, IOException iOException) {
                callback.onFailure(t, iOException);
            }
        });
    }

    public <T extends BaseRequest<T, R>, R extends BaseResponse> R send(BaseRequest<T, R> baseRequest) {
        try {
            return (BaseResponse) this.gson.fromJson(getOkHttpClient(baseRequest).newCall(createRequest(baseRequest)).execute().body().string(), baseRequest.getResponseType());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void shutdown() {
        this.client.dispatcher().executorService().shutdown();
    }

    private OkHttpClient getOkHttpClient(BaseRequest<?, ?> baseRequest) {
        int timeoutSeconds = baseRequest.getTimeoutSeconds() * 1000;
        if (this.client.readTimeoutMillis() == 0 || this.client.readTimeoutMillis() > timeoutSeconds) {
            return this.client;
        }
        if (this.clientWithTimeout.readTimeoutMillis() > timeoutSeconds) {
            return this.clientWithTimeout;
        }
        OkHttpClient build = this.client.newBuilder().readTimeout((long) (timeoutSeconds + 1000), TimeUnit.MILLISECONDS).build();
        this.clientWithTimeout = build;
        return build;
    }

    private Request createRequest(BaseRequest<?, ?> baseRequest) {
        Request.Builder builder = new Request.Builder();
        return builder.url(this.baseUrl + baseRequest.getMethod()).post(createRequestBody(baseRequest)).build();
    }

    private RequestBody createRequestBody(BaseRequest<?, ?> baseRequest) {
        if (baseRequest.isMultipart()) {
            MediaType parse = MediaType.parse(baseRequest.getContentType());
            MultipartBody.Builder type = new MultipartBody.Builder().setType(MultipartBody.FORM);
            for (Map.Entry next : baseRequest.getParameters().entrySet()) {
                String str = (String) next.getKey();
                Object value = next.getValue();
                if (value instanceof byte[]) {
                    type.addFormDataPart(str, baseRequest.getFileName(), RequestBody.create(parse, (byte[]) value));
                } else if (value instanceof File) {
                    type.addFormDataPart(str, baseRequest.getFileName(), RequestBody.create(parse, (File) value));
                } else {
                    type.addFormDataPart(str, toParamValue(value));
                }
            }
            return type.build();
        }
        FormBody.Builder builder = new FormBody.Builder();
        for (Map.Entry next2 : baseRequest.getParameters().entrySet()) {
            builder.add((String) next2.getKey(), toParamValue(next2.getValue()));
        }
        return builder.build();
    }

    private String toParamValue(Object obj) {
        if (obj.getClass().isPrimitive() || obj.getClass().isEnum() || obj.getClass().getName().startsWith("java.lang")) {
            return String.valueOf(obj);
        }
        return this.gson.toJson(obj);
    }
}
