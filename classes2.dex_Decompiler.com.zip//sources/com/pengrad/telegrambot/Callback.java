package com.pengrad.telegrambot;

import com.pengrad.telegrambot.request.BaseRequest;
import com.pengrad.telegrambot.response.BaseResponse;
import java.io.IOException;

public interface Callback<T extends BaseRequest<T, R>, R extends BaseResponse> {
    void onFailure(T t, IOException iOException);

    void onResponse(T t, R r);
}
