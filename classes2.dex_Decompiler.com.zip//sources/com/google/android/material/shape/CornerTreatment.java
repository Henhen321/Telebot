package com.google.android.material.shape;

public class CornerTreatment {
    public void getCornerPath(float f, float f2, ShapePath shapePath) {
    }
}
