package com.karumi.dexter.listener;

public interface PermissionRequestErrorListener {
    void onError(DexterError dexterError);
}
