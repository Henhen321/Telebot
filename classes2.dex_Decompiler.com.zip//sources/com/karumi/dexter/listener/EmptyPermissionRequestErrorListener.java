package com.karumi.dexter.listener;

public class EmptyPermissionRequestErrorListener implements PermissionRequestErrorListener {
    public void onError(DexterError dexterError) {
    }
}
