package com.karumi.dexter.listener;

public enum DexterError {
    REQUEST_ONGOING,
    NO_PERMISSIONS_REQUESTED
}
