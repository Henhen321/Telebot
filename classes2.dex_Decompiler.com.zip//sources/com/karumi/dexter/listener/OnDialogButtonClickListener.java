package com.karumi.dexter.listener;

public interface OnDialogButtonClickListener {
    void onClick();
}
