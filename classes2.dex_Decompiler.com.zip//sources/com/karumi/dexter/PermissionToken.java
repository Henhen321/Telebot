package com.karumi.dexter;

public interface PermissionToken {
    void cancelPermissionRequest();

    void continuePermissionRequest();
}
